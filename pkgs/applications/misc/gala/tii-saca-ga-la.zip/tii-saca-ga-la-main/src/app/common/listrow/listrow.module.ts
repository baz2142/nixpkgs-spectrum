import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { ListrowComponent } from './listrow.component';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [IonicModule, CommonModule],
  declarations: [ListrowComponent],
  exports: [ListrowComponent],
})
export class ListrowModule {}
