import { Component } from '@angular/core';
import { FingerprintAIO, FingerprintSecretOptions } from '@ionic-native/fingerprint-aio/ngx';

@Component({
  selector: 'app-toggle-fingerprint-login',
  templateUrl: './toggle-fingerprint-login.component.html',
  styleUrls: ['./toggle-fingerprint-login.component.css'],
})
export class ToggleFingerprintLoginComponent {
  public useBiometricLogin = false;

  constructor(private fingerprintAuth: FingerprintAIO) {
    this.useBiometricLogin = localStorage.getItem('biometricLogin') === 'true';
  }

  public toggleBiometricLogin() {
    if (!!this.useBiometricLogin) {
      localStorage.setItem('biometricLogin', 'false');
      this.useBiometricLogin = false;
    } else {
      this.fingerprintAuth
        .isAvailable()
        .then((result: any) => {
          const secret: FingerprintSecretOptions = {
            description: 'Register your biometrics',
            secret: 'my-super-secret', // what should this be? generate something?
            // secret: String secret to encrypt and save, use simple strings matching the regex [a-zA-Z0-9-]+
            invalidateOnEnrollment: true,
            disableBackup: true, // always disabled on Android
          };

          this.fingerprintAuth.registerBiometricSecret(secret).then((x) => {
            localStorage.setItem('biometricLogin', 'true');
            this.useBiometricLogin = true;
            console.log(x);
            alert('Successfully Authenticated!');
          });
        })
        .catch((error: any) => {
          console.log(error);
          alert('Match not found!');
        });
    }
  }
}
