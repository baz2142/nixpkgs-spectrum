export const VMINSTANCEAPI = {
  REGISTERCUSTOMER: 'registercustomer',
  UNREGISTERCUSTOMER: 'unregistercustomer',
  INFO: 'containerstatus',
  LISTDEVICES: 'listcontainers',
  LISTFREEDEVICES: 'listfreecontainers',
  LISTHOSTDEVICES: 'listhostcontainers',
  DELETEHOSTDEVICES: 'deletehostcontainers',
  ADD: 'addcontainer',
  REMOVE: 'removecontainer',
  SETTINGS: 'getsettings',
  POSTSETTINGS: 'postsettings',
  CONFIG: 'getenvconfigs',
  POSTCONFIG: 'postenvconfigs',
  DELETECONFIG: 'deleteenvconfig',
  LOGLEVEL: 'getlogginglevel',
  SETLOGLEVEL: 'setlogginglevel',
};

export const INSTANCEGROUPAPI = {
  LISTTEMPLATES: 'listinstancetemplates',
  LISTAOSPBUILDS: 'listaospbuilds',
  LISTGALABUILDS: 'listgalabuilds',
  LISTGROUPS: 'listgroups',
  GETGROUP: 'getgroup',
  ADDGROUP: 'addgroup',
  DELETEGROUP: 'deletegroup',
  LISTINSTANCES: 'listgroupinstances',
  SCALE: 'changegroupscaling',
  DOWNLOADGALABUILD: 'downloadgalabuild',
};

export const DEVICEAPI = {
  PREPARE: 'preparecvd',
  START: 'startcvd',
  STOP: 'stopcvd',
  STATUS: 'cvdstatus',
  GETLOGS: 'getlogs',
};

export const USERAPI = {
  LIST: 'listusers',
  LISTUNASSIGNED: 'listunassignedusers',
  UPSERT: 'upsertuser',
  DELETE: 'deleteuser',
  BATCHADD: 'batchaddusers',
  BATCHDELETE: 'batchdeleteusers',
  GET: 'getuser',
  DEFAULTDEVICE: 'getdefaultdevice',
  PASSWORDRESET: 'getpasswordreset',
  PASSWORDRESETFORUSER: 'getpasswordresetforuser',
};

export const ENVIRONMENTAPI = {
  VERSIONS: 'getversions',
};
