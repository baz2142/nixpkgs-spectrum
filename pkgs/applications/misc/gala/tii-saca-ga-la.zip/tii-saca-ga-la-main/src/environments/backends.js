const DEV_BACKEND = {
  ADDRESS: 'development-saca-backend-asvsrjxw5q-ew.a.run.app',
  PROTOCOL: 'https://',
  PORT: ':443',
};

const TEST_BACKEND = {
  ADDRESS: 'test-saca-backend-gcfiv4xhra-ew.a.run.app',
  PROTOCOL: 'https://',
  WSPROTOCOL: 'wss://',
  PORT: ':443',
};

const DEMO_BACKEND = {
  ADDRESS: 'demo-saca-backend-ynpjkh6lua-ew.a.run.app',
  PROTOCOL: 'https://',
  WSPROTOCOL: 'wss://',
  PORT: ':443',
};

module.exports = { DEV_BACKEND, TEST_BACKEND, DEMO_BACKEND };
