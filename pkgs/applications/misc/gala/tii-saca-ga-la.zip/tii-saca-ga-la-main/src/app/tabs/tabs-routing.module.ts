import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';
import { ReloadGuard } from '../common/reloadrouterguard';

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'user',
        loadChildren: () =>
          import('../user/user.module').then((m) => m.UserPageModule),
      },
      {
        path: 'device',
        loadChildren: () =>
          import('../device/device.module').then((m) => m.DevicePageModule),
      },
      {
        path: 'cuttle',
        loadChildren: () =>
          import('../cuttle/cuttle.module').then((m) => m.CuttlePageModule),
        canActivate: [ReloadGuard],
      },
      {
        path: 'admin',
        loadChildren: () =>
          import('../admin/admin.module').then((m) => m.AdminPageModule),
      },
      {
        path: 'test',
        loadChildren: () =>
          import('../test/test.module').then((m) => m.TestPageModule),
      },
      {
        path: '',
        redirectTo: '/tabs/device',
        pathMatch: 'full',
      },
    ],
  },
  {
    path: '',
    redirectTo: '/tabs/device',
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TabsPageRoutingModule {}
