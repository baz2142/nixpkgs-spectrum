// app/common/btn-cell-renderer.component.ts
import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'link-cell-renderer',
  template: `
    <span *ngIf="!noLink()" (click)="linkClickedHandler()"
      ><u>{{ getText() }}</u></span
    >
    <span *ngIf="noLink()">{{ getText() }}</span>
  `,
})
export class LinkCellRenderer implements ICellRendererAngularComp {
  public params: any;

  agInit(params: any): void {
    this.params = params;
  }

  linkClickedHandler() {
    if (this.params.clicked) {
      this.params.clicked(this.params.value);
    }
  }

  noLink(): boolean {
    return this.params.noLink ? this.params.noLink(this.params.value) : false;
  }

  getText(): string {
    return this.params.linkText ? this.params.linkText(this.params.value) : this.params.value;
  }

  refresh(params: ICellRendererParams): boolean {
    return false;
  }
}
