import { Component, OnInit } from '@angular/core';
import { AlertController, Platform, ToastController } from '@ionic/angular';
import { GridApi, GridOptions } from 'ag-grid-community';
import {
  AospBuild,
  AospBuildResponse,
  ContainerService,
  InstanceTemplate,
  InstanceTemplateResponse,
  RequestStatus,
  SacaConfig,
  SacaSettings,
} from '../../container.service';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-instancetemplates',
  templateUrl: 'instancetemplates.component.html',
  styleUrls: ['instancetemplates.component.scss'],
})
export class InstanceTemplatesComponent implements OnInit {
  public settings: SacaSettings = {} as SacaSettings;
  public activeConfig: SacaConfig = {} as SacaConfig;
  public activeConfigId: string = '';
  public configs: SacaConfig[] = [];
  public template: string;
  public groupName: string;
  public size: number;
  public groupForm: any;
  public aospGridApi: GridApi;
  public templatesGridApi: GridApi;

  aospGridOptions: GridOptions;
  templateGridOptions: GridOptions;

  aospColumnDefs = [
    {
      headerName: 'AOSP Build',
      field: 'AospBuild',
    },
    {
      headerName: 'Created',
      field: 'Created',
      valueFormatter: (params) => {
        return this.formatDate(params.value);
      },
    },
  ];

  templateColumnDefs = [
    {
      headerName: 'Name',
      field: 'Name',
    },
    {
      headerName: 'Created',
      field: 'Created',
      valueFormatter: (params) => {
        return this.formatDate(params.value);
      },
    },
    {
      headerName: 'Branch',
      field: 'Branch',
    },
  ];

  constructor(
    private platform: Platform,
    private toastController: ToastController,
    private containerService: ContainerService,
    private alertController: AlertController,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);

      if (authenticated) {
        this.getConfig();
        this.listInstanceTemplates();
        this.listAospBuilds();
      }
    });

    // this.imageGridOptions = this.generateGridOptions(this.onImageSelectionChanged, this.sortGrid, 'Created');
    this.aospGridOptions = this.generateGridOptions(
      true,
      this.onAospSelectionChanged,
      this.sortGrid,
      'Created'
    );
    this.templateGridOptions = this.generateGridOptions(
      false,
      this.onTemplateSelectionChanged,
      this.sortGrid,
      'Created'
    );
  }

  onAospSelectionChanged(event: any) {
    const selectedRows = event.api.getSelectedRows();
    // Single selection --> should be at max 1 row selected
    if (selectedRows.length > 0) {
      const aosp: AospBuild = selectedRows[0];
      this.settings.AospBuildId = aosp.AospBuild;
    }
  }

  onTemplateSelectionChanged(event: any) {
    const selectedRows = event.api.getSelectedRows();
    // Single selection --> should be at max 1 row selected
    if (selectedRows.length > 0) {
      const template: InstanceTemplate = selectedRows[0];
      this.template = template.SelfLink;
    }
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  get aospBuildsForGrid(): AospBuild[] {
    return this.containerService.getAospBuilds();
  }

  get instanceTemplatesForGrid(): InstanceTemplate[] {
    return this.containerService.getInstanceTemplates();
  }

  async presentToast(header: string, message: string, displaySecs: number = 2) {
    const toast = await this.toastController.create({
      message: header + ': ' + message,
      duration: displaySecs * 1000,
    });
    toast.present();
  }

  async presentConfirmation(question: string): Promise<boolean> {
    const alert = await this.alertController.create({
      header: 'Confirmation',
      message: question,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
        },
        {
          text: 'OK',
          role: 'ok',
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    return role === 'ok';
  }

  generateGridOptions(
    isAospGrid: boolean,
    selectionChangedCallback: any,
    gridSort: any,
    column: string
  ): GridOptions {
    return {
      onGridReady: (param) => {
        if (!!isAospGrid) {
          this.aospGridApi = param.api;
        } else {
          this.templatesGridApi = param.api;
        }
        param.api.sizeColumnsToFit();
        gridSort(param, column, 'desc');
      },

      onCellDoubleClicked: (param) => {
        param.api.sizeColumnsToFit();
      },

      onRowDataChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      onGridSizeChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      defaultColDef: {
        flex: 1,
        minWidth: 100,
        resizable: true,
        sortable: true,
        editable: true,
        filter: true,
      },
      rowSelection: 'single',
      onSelectionChanged: selectionChangedCallback.bind(this),
    } as GridOptions;
  }

  sortGrid(param, field, sortDir) {
    const columnState = {
      // https://www.ag-grid.com/javascript-grid-column-state/#column-state-interface
      state: [
        {
          colId: field,
          sort: sortDir,
        },
      ],
    };
    param.columnApi.applyColumnState(columnState);
  }

  listInstanceTemplates() {
    console.log('List instance templates');
    this.templateGridOptions.api?.showLoadingOverlay();
    this.containerService
      .refreshInstanceTemplates()
      .subscribe((result: InstanceTemplateResponse) => {
        this.templateGridOptions.api?.hideOverlay();
        console.log('List templates result', result);
      });
  }

  listAospBuilds() {
    this.aospGridOptions.api?.showLoadingOverlay();
    this.containerService
      .refreshAospBuilds()
      .subscribe((result: AospBuildResponse) => {
        this.aospGridOptions.api?.hideOverlay();
        console.log('List builds result', result);
      });
  }

  getSettings() {
    this.containerService.getSettings().subscribe((result: SacaSettings) => {
      console.log('Get settings result', result);

      if (result) {
        this.settings = result;
        this.settings.NumCvdInstances = this.activeConfig.NumCvdInstances;
      }
    });
  }

  sortConfigs(configs: SacaConfig[]): SacaConfig[] {
    return configs.sort((a, b) => {
      return a.ConfigName <= b.ConfigName ? -1 : 1;
    });
  }

  getConfig() {
    this.containerService.getConfigs().subscribe((result: SacaConfig[]) => {
      console.log('Get config result', result);
      if (result) {
        this.configs = this.sortConfigs(result);
      }
      this.getSettings();
    });
  }

  templateChanged($event: any) {
    this.template = $event.detail.value;
  }

  buildChanged($event: any) {
    this.settings.AospBuildId = $event.detail.value;
  }

  formatDate(date: string): string {
    const newDate = date.replace(' +0000 UTC', 'Z').replace(/ /, 'T');
    const parsed = new Date(Date.parse(newDate));
    return `${parsed.toLocaleString(navigator.language)}`;
  }

  onConfigurationChange(configId) {
    console.log('Config change', configId);
    const selectedConfig = this.configs
      .filter((config) => config.Id === configId)
      .pop();
    console.log(selectedConfig);
    this.activeConfig = selectedConfig;
    this.settings.NumCvdInstances = selectedConfig.NumCvdInstances;
  }

  submitForm(form: any) {
    this.presentConfirmation(
      `Do you want to create new instance group ${this.groupName}?`
    ).then((answer) => {
      if (answer) {
        this.containerService
          .postSettings(this.settings)
          .subscribe((result: SacaSettings) => {
            console.log('Post settings result', result);
            this.containerService
              .addInstanceGroup(
                this.groupName,
                this.template,
                this.size,
                this.activeConfigId
              )
              .subscribe((status: RequestStatus) => {
                console.log('Add instance group result', status);

                if (status.Status) {
                  this.presentToast(
                    this.groupName,
                    'Succesfully initiated instance group add'
                  );
                } else {
                  this.presentToast(
                    this.groupName,
                    'Error in group setup: ' + status.Message,
                    5
                  );
                }
              });
          });
      }
    });
  }

  public onModelUpdated() {
    this.aospGridApi?.sizeColumnsToFit();
    this.templatesGridApi?.sizeColumnsToFit();
  }
}
