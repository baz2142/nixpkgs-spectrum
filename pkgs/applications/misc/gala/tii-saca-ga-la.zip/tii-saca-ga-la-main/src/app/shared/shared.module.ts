import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { InvisibleDirective } from './invisible.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [InvisibleDirective],
  exports: [InvisibleDirective],
})
export class SharedModule {}
