import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Platform, ToastController } from '@ionic/angular';
import { CuttlefishMapping } from './container.service';
import { DeviceService } from './device.service';
import { ScreenshotPreventionService } from './screenshot-prevention.service';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  private isSuspend = false;
  private cameraStateDuringSuspend = false;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private deviceService: DeviceService,
    private userService: UserService,
    private router: Router,
    private toastController: ToastController,
    private screenshotService: ScreenshotPreventionService,
    private fingerprintAuth: FingerprintAIO
  ) {
    this.platform.ready().then(() => {
      this.splashScreen.show();
      this.statusBar.styleDefault();

      // Different logics for secure and unsecure
      if (localStorage.getItem('biometricLogin') === 'true' && !this.isDesktop()) {
        this.fingerprintAuth
          .isAvailable()
          .then((result: any) => {
            this.fingerprintAuth
              .show({
                cancelButtonTitle: 'Cancel',
                description: 'Use your fingerprint to verify your identity.',
                disableBackup: true,
                title: 'Verify your identity',
                fallbackButtonTitle: 'Back',
              })
              .then((result: any) => {
                this.initializeApp();
              })
              .catch((error: any) => {
                // We should maybe route the user to some "error page" or something? Maybe revamped login page, where user needs to login with his credentials again?
        this.splashScreen.hide();
                console.log(error);
                alert('Match not found!');
              });
          })
          .catch((error: any) => {
            console.log(error);
          });
      } else {
        this.initializeApp();
      }
    });
  }

  private initializeApp() {
      this.userService.authStateSubject.subscribe((authenticated) => {
        console.log('AUTH STATE CHANGED', authenticated);
        if (authenticated) {
          console.log('USER IS AUTHENTICATED');
          if (
            this.userService.isAdminUser() ||
            this.userService.isSuperUser()
          ) {
            this.splashScreen.hide();
          } else {
            console.log('Normal user authenticated --> autoconnect check');
            this.autoConnect();
          }
        } else {
          this.splashScreen.hide();
          this.router.navigateByUrl('/tabs/user');
        }
      });

      if (this.platform.is('android')) {
        this.screenshotService.disableScreenshots().then(() => {
          console.log('Android screenshots disabled');
        });
      }

      this.platform.resume.subscribe(() => {
        console.log('Application resume --> autoconnect check');
        this.autoConnect();
      });

      this.platform.pause.subscribe(() => {
        console.log(
          'Application pause --> disconnect WebRTC and disable camera if enabled'
        );
        this.isSuspend = true;
        this.cameraStateDuringSuspend = this.deviceService.cameraEnabled();
        if (this.deviceService.cameraEnabled()) {
          this.deviceService.enableCamera(false);
        }
        this.deviceService.disconnectFromDevice();
    });
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  // Automatic connecting to the previously selected CVD instance.
  autoConnect() {
    console.log(
      'Autoconnect: Authenticated', 
      this.deviceService.isActiveDevice(), 
      this.userService.userRole
    );
    this.userService
      .getDefaultDevice()
      .subscribe((defaultDevice: CuttlefishMapping) => {
        console.log('Autoconnect: Default device got', defaultDevice);

        if (defaultDevice.Emulator === 'running' && defaultDevice.CvdId) {
        this.splashScreen.show();
        // If for some reason the splashscreen is not removed, after 10 sec remove it
        setTimeout(() => {
          this.splashScreen.hide();
        }, 10000);

          if (!this.isSuspend) {
            this.presentToast('Have default running CVD --> connecting...', 5);
          }
          this.isSuspend = false;
          this.deviceService
            .connectToDevice(
              defaultDevice.CvdId,
              () => {
                this.router.navigateByUrl('/tabs/cuttle');
                if (this.cameraStateDuringSuspend) {
                  this.deviceService.enableCamera(true);
                }
                this.splashScreen.hide();
              },
              this.convertHttpsToWssEndpoint(defaultDevice.DnsAddress)
            )
            .catch((result) => {
              this.splashScreen.hide();
              if (result !== true) {
                this.presentToast('Autoconnect failed', 5);
              }
            });
        } else {
          console.log('Default device not running -- no autoconnect');
        }
      });
  }

  convertHttpsToWssEndpoint(httpsEndpoint: string): string {
    const delim = httpsEndpoint.indexOf(':');
    if (delim > 0) {
      const endUrl = httpsEndpoint.substr(delim);
      return 'wss' + endUrl;
    } else {
      return null;
    }
  }

  async presentToast(message: string, displaySecs: number = 2) {
    const toast = await this.toastController.create({
      message,
      duration: displaySecs * 1000,
    });
    toast.present();
  }
}
