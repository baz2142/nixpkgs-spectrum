import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UserService } from '../user.service';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(public userService: UserService, private toastController: ToastController, private router: Router) {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${this.userService.getToken()}`,
      },
    });
    return next.handle(request).pipe(
      catchError((err) => {
        console.log('*** INTERCEPTOR ERROR ***', err);
        const httpError = err.error.message || err.statusText;
        if (err.status === 401) {
          // auto logout if 401 response returned from api
          this.userService.logout();
          this.presentToast('Unauthorized - please login');
          this.router.navigateByUrl('/tabs/user');
        } else if (err.status === 0) {
          // TODO: Check what to do in other cases, if something reasonable can be done
          // RefreshToken here is not good, as it might loop here.
          // this.userService.refreshToken();
          throw new HttpErrorResponse({
            error: httpError,
            headers: request.headers,
            status: 500,
            statusText: 'Warning',
            url: request.url,
          });
        }

        return of(httpError);
      })
    );
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
    });
    toast.present();
  }
}
