/* tslint:disable:no-unused-variable */
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ToggleFingerprintLoginComponent } from './toggle-fingerprint-login.component';

describe('ToggleFingerprintLoginComponent', () => {
  let component: ToggleFingerprintLoginComponent;
  let fixture: ComponentFixture<ToggleFingerprintLoginComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ToggleFingerprintLoginComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToggleFingerprintLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
