module.exports = function(ctx) {
    const hashStr = process.env.GALA_CI_GIT_HASH;
    if (hashStr) {
        var fs = require('fs');
        
        const fileName = 'src/app/device/device.page.html';
        console.log('Set git hash ' + hashStr + ' to ' + fileName);
        var file = fs.readFileSync(fileName, 'utf8');
        var result = file.replace(/(Client version: )([a-fA-F0-9]+)/g, '$1' + hashStr);

        fs.writeFileSync(fileName, result);
    } else {
        console.log('GALA_CI_GIT_HASH undefined - probably non-CI build');
    }
};
