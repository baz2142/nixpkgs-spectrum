import { Component, EventEmitter, Output } from '@angular/core';
import { Platform, ToastController } from '@ionic/angular';
import { FooterService } from '../footer.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: 'user.page.html',
  styleUrls: ['user.page.scss'],
})
export class UserPage {
  private userName: string;
  private password: string;

  @Output() toggleTabsNotification: EventEmitter<any> = new EventEmitter();

  constructor(
    private footerService: FooterService,
    private userService: UserService,
    private platform: Platform,
    private toastController: ToastController
  ) {}

  ionViewDidEnter() {
    this.footerService.showFooter();
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  isAndroid(): boolean {
    return this.platform.is('android');
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
    });
    toast.present();
  }

  login() {
    this.userService.login(this.userName, this.password);
  }

  logout() {
    console.log('Logout');
    this.userService.logout();
    this.presentToast('User logged out');
  }

  isLoggedIn(): boolean {
    const token = this.userService.getToken();
    return token && token.length > 0;
  }

  get userEmail(): string {
    return this.userService.getUserEmail();
  }

  get autoConnect(): boolean {
    return this.userService.autoConnect;
  }

  set autoConnect(connect: boolean) {
    this.userService.autoConnect = connect;
  }

  /*toggleConnect($event: any) {
    this.userService.autoConnect = $event.detail.checked;
  }*/
}
