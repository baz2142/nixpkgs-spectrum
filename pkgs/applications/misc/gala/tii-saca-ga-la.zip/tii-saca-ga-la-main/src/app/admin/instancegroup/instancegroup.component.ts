import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController, Platform, ToastController } from '@ionic/angular';
import { GridApi, GridOptions } from 'ag-grid-community';
import { forkJoin, Observable } from 'rxjs';
import { DropDownEditor } from '../../common/dropdown/dropdown.editor';
import { LinkCellRenderer } from '../../common/link-cell-renderer.component';
import { SelectCellRenderer } from '../../common/select-cell-renderer.component';
import {
  ContainerService,
  InstanceGroupInfo,
  InstanceGroupInstanceResponse,
  InstanceInfo,
  RequestStatus,
} from '../../container.service';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-instancegroup',
  templateUrl: 'instancegroup.component.html',
  styleUrls: ['instancegroup.component.scss'],
})
export class InstanceGroupComponent implements OnInit {
  public instanceGroupInstances: InstanceInfo[];
  selectedGroupName: string;
  groupGridOptions: GridOptions;
  gridApi: GridApi;

  public frameworkComponents = {
    dropdownEditor: DropDownEditor,
    linkCellRenderer: LinkCellRenderer,
    selectCellRenderer: SelectCellRenderer,
  };

  groupColumnDefs = [
    {
      headerName: 'Instance name',
      field: 'Name',
      sortable: true,
      editable: false,
      cellRenderer: 'linkCellRenderer',
      cellRendererParams: {
        clicked: (Name: string) => {
          this.navigateToInstance(Name);
        },
      },
      minWidth: 400,
      maxWidth: 400,
    },
    {
      headerName: 'Created',
      field: 'Created',
      sortable: true,
      editable: false,
      valueFormatter: (param) => this.formatDate(param.value),
      flex: 1,
    },
    {
      headerName: 'Machine Type',
      field: 'MachineType',
      sortable: true,
      editable: false,
      valueFormatter: (param) => {
        const templateName = param.value;
        return templateName.substr(templateName.lastIndexOf('/') + 1);
      },
      flex: 1,
      tooltipField: 'MachineType',
      tooltip: (value: string): string => value,
    },
    {
      headerName: 'Endpoint',
      field: 'IpAddress',
      sortable: true,
      editable: false,
      flex: 1,
    },

    {
      headerName: 'Status',
      field: 'Status',
      sortable: true,
      editable: false,
      flex: 1,
    },
  ];

  constructor(
    private platform: Platform,
    private toastController: ToastController,
    private containerService: ContainerService,
    private userService: UserService,
    private alertController: AlertController,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);
      if (authenticated) {
        this.route.queryParams.subscribe((params) => {
          this.selectedGroupName = this.route.snapshot.paramMap.get('groupid');
          this.listGroupInstances();

          // Refresh groups in case of reloading
          const groups = this.containerService.getInstanceGroups();
          if (groups.length < 1) {
            this.containerService.refreshInstanceGroups();
          }
        });
      }
    });

    this.groupGridOptions = this.generateGridOptions(this.sortGrid, 'Created', 'desc');
  }

  generateGridOptions(gridSort: any, column: string, direction: string): GridOptions {
    return {
      onGridReady: (param) => {
        param.api.sizeColumnsToFit();
        gridSort(param, column, direction);
        this.gridApi = param.api;
      },

      onCellDoubleClicked: (param) => {
        param.api.sizeColumnsToFit();
      },

      onRowDataChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      onGridSizeChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      defaultColDef: {
        flex: 1,
        minWidth: 100,
        resizable: true,
        sortable: true,
        editable: true,
        filter: true,
      },
      tooltipShowDelay: 1000,
      rowSelection: 'single',
      enableCellTextSelection: true,
    } as GridOptions;
  }

  sortGrid(param, field, sortDir) {
    const columnState = {
      // https://www.ag-grid.com/javascript-grid-column-state/#column-state-interface
      state: [
        {
          colId: field,
          sort: sortDir,
        },
      ],
    };
    param.columnApi.applyColumnState(columnState);
  }

  formatDate(date: string): string {
    const parsed = new Date(Date.parse(date));
    return `${parsed.toLocaleString(navigator.language)}`;
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  async presentToast(messageText: string) {
    const toast = await this.toastController.create({
      message: messageText,
      duration: 2000,
    });
    toast.present();
  }

  async presentConfirmation(question: string): Promise<boolean> {
    const alert = await this.alertController.create({
      header: 'Confirmation',
      message: question,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
        },
        {
          text: 'OK',
          role: 'ok',
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    return role === 'ok';
  }

  navigateToInstance(instance: string) {
    this.router.navigateByUrl('/tabs/admin/instancegroups/' + this.selectedGroupName + '/' + instance);
  }

  listGroupInstances() {
    this.gridApi?.showLoadingOverlay();
    this.containerService
      .listGroupInstances(this.selectedGroupName)
      .subscribe((result: InstanceGroupInstanceResponse) => {
        console.log('List group instances result', result);
        this.gridApi?.hideOverlay();
        if (result.Status) {
          this.instanceGroupInstances = result.Instances;
        }
      });
  }

  instanceGroup(groups: InstanceGroupInfo[], name: string): InstanceGroupInfo {
    return groups
      .filter((group) => {
        return group.Name === name;
      })
      ?.pop();
  }

  instance(instanceName: string): InstanceInfo {
    return this.instanceGroupInstances
      .filter((instance) => {
        return instance.Name === instanceName;
      })
      ?.pop();
  }

  createMappings(instance: InstanceInfo) {
    this.presentConfirmation(`Do you want to create mapppings for the VM ${instance.Name}?`).then((answer) => {
      if (answer) {
        const observables = [];
        const groups = this.containerService.getInstanceGroups();
        const containerCount = this.instanceGroup(groups, this.selectedGroupName).Settings?.NumCvdInstances || 5;

        console.log('Container count for mappings', containerCount);

        this.eraseExistingInstanceMappings(instance.Name).subscribe(() => {
          console.log('Possible existing mappings erased --> moving to creation');
          this.createMappingObservables(observables, instance, containerCount);
          // Wait for all requests to finish
          forkJoin(observables).subscribe((t) => {
            console.log('All new mappings added');
            this.presentToast('New port mappings registered to database');
          });
        });
      }
    });
  }

  createAllMappingsForGroup() {
    this.presentConfirmation(
      `Do you want to create mapppings for the current instance group ${this.selectedGroupName}?`
    ).then((answer) => {
      if (answer) {
        const observables = [];

        const groups = this.containerService.getInstanceGroups();
        const containerCount = this.instanceGroup(groups, this.selectedGroupName).Settings?.NumCvdInstances || 5;
        console.log('Container count for mappings', containerCount);

        this.eraseExistingGroupMappings().subscribe(() => {
          console.log('Possible existing mappings erased --> moving to creation');
          this.instanceGroupInstances.forEach((instance) => {
            console.log('creating mappings for instance: ' + instance.Name);
            this.createMappingObservables(observables, instance, containerCount);
          });

          // Wait for all requests to finish
          forkJoin(observables).subscribe((t) => {
            console.log('All new mappings added');
            this.presentToast('New port mappings registered to database');
          });
        });
      }
    });
  }

  private eraseExistingGroupMappings(): Observable<any> {
    const observables = [];
    this.instanceGroupInstances.forEach((instance) => {
      observables.push(this.containerService.deleteHostContainers(instance.Name));
    });
    return forkJoin(observables);
  }

  private eraseExistingInstanceMappings(instanceName: string): Observable<RequestStatus> {
    return this.containerService.deleteHostContainers(instanceName);
  }

  private createMappingObservables(observables: any[], instance: InstanceInfo, mappingCount: number) {
    let port = 8080;
    for (port; port < 8080 + mappingCount; port++) {
      observables.push(this.containerService.addContainer(instance.Name, instance.IpAddress, port));
    }
  }
}
