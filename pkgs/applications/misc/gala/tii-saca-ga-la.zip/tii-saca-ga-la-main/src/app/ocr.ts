import { createWorker } from 'tesseract.js';

export class Ocr {
  private ocrWorker: Tesseract.Worker;

  public initialize() {
    if (this.ocrWorker) {
      console.warn('OCR already initialized');
      return;
    }
    this.ocrWorker = createWorker();
    this.ocrWorker
      .load()
      .then((res) => this.ocrWorker.loadLanguage())
      .then((res) => this.ocrWorker.initialize())
      .catch((e) => console.error('Cannot initialize OCR:', e.message));
  }

  public isInitialized(): boolean {
    return !!this.ocrWorker;
  }

  public deinitialize() {
    if (!this.ocrWorker) {
      console.warn('Cannot deinitialize uninitialized OCR');
      return;
    }
    this.ocrWorker
      .terminate()
      .then((result) => (this.ocrWorker = null))
      .catch((e) => console.error('Cannot terminate OCR worker:', e.message));
  }

  public recognize(source: HTMLVideoElement): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.ocrWorker) {
        reject(new Error('OCR worker not initialized'));
      }
      const canvas = document.createElement('canvas');
      const width = source.offsetWidth;
      const height = source.offsetHeight;
      canvas.width = width;
      canvas.height = height;
      canvas.getContext('2d').drawImage(source, 0, 0, width, height);
      this.ocrWorker
        .recognize(canvas)
        .then((result) => resolve(result.data.text));
    });
  }
}
