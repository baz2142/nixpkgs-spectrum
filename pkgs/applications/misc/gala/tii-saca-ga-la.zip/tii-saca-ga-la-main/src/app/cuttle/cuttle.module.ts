import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CuttlePage } from './cuttle.page';

import { CuttlePageRoutingModule } from './cuttle-routing.module';

@NgModule({
  imports: [IonicModule, CommonModule, FormsModule, CuttlePageRoutingModule],
  declarations: [CuttlePage],
})
export class CuttlePageModule {}
