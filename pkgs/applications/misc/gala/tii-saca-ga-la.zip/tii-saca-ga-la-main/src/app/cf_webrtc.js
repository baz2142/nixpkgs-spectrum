/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

function isApple() {
  const regex = /Apple Computer, Inc./
  return navigator.vendor && navigator.vendor.match(regex);
}

function isiOS() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent);
}

function* iceRestartTimeout() {
  const timeoutMs = [300, 700, 1500, 3100, 6300];
  for (let i = 0; i < timeoutMs.length; i++) {
    yield timeoutMs[i];
  }
}

function createDataChannel(pc, label, onMessage) {
  console.debug('creating data channel: ' + label);
  let dataChannel = pc.createDataChannel(label);
  // Return an object with a send function like that of the dataChannel, but
  // that only actually sends over the data channel once it has connected.
  return {
    channelPromise: new Promise((resolve, reject) => {
      dataChannel.onopen = (event) => {
        resolve(dataChannel);
      };
      dataChannel.onclose = () => {
        console.debug(
            'Data channel=' + label + ' state=' + dataChannel.readyState);
      };
      dataChannel.onmessage = onMessage ? onMessage : (msg) => {
        console.debug('Data channel=' + label + ' data="' + msg.data + '"');
      };
      dataChannel.onerror = err => {
        reject(err);
      };
    }),
    send: function(msg) {
      this.channelPromise = this.channelPromise.then(channel => {
        channel.send(msg);
        return channel;
      })
    },
    close: function() {
      dataChannel.close();
    }
  };
}

function awaitDataChannel(pc, label, onMessage, onOpen) {
  console.debug('expecting data channel: ' + label);
  // Return an object with a send function like that of the dataChannel, but
  // that only actually sends over the data channel once it has connected.
  return {
    channelPromise: new Promise((resolve, reject) => {
      let prev_ondatachannel = pc.ondatachannel;
      pc.ondatachannel = ev => {
        let dataChannel = ev.channel;
        if (dataChannel.label == label) {
          dataChannel.onopen = (event) => {
            if (onOpen) {
              onOpen(dataChannel)
            }
            resolve(dataChannel);
          };
          dataChannel.onclose = () => {
            console.debug(
                'Data channel=' + label + ' state=' + dataChannel.readyState);
          };
          dataChannel.onmessage = onMessage ? onMessage : (msg) => {
            console.debug('Data channel=' + label + ' data="' + msg.data + '"');
          };
          dataChannel.onerror = err => {
            reject(err);
          };
        } else if (prev_ondatachannel) {
          prev_ondatachannel(ev);
        }
      };
    }),
    send: function(msg) {
      this.channelPromise = this.channelPromise.then(channel => {
        channel.send(msg);
        return channel;
      })
    },
  };
}

async function ajaxPostJson(url, data) {
  const response = await fetch(url, {
    method: 'POST',
    cache: 'no-cache',
    headers: {'Content-Type': 'application/json'},
    redirect: 'follow',
    body: JSON.stringify(data),
  });
  return response.json();
}

class DeviceConnection {
  _pc;
  _control;
  _description;

  _cameraDataChannel;
  _cameraInputQueue;
  _controlChannel;
  _controlDataChannel;
  _inputChannel;
  _adbChannel;
  _bluetoothChannel;

  _streams;
  _streamPromiseResolvers;
  _streamChangeCallback;
  _micTransceivers = [];
  _cameraTransceivers = [];
  _localCameraStream;
  _camera_res_x;
  _camera_res_y;
  _adbEnabled;

  _onAdbMessage;
  _onControlMessage;
  _onBluetoothMessage;

  connectionChangeCallback;

  constructor(pc, control, adb_enabled) {
    this._pc = pc;
    this._control = control;
    this._pc.getTransceivers().forEach(transceiver => {
      if (transceiver.sender.track.kind == 'audio') {
        this._micTransceivers.push(transceiver);
      }
    });

    this._cameraDataChannel = pc.createDataChannel('camera-data-channel');
    this._cameraDataChannel.binaryType = 'arraybuffer';
    this._cameraInputQueue = new Array();
    var self = this;
    this._cameraDataChannel.onbufferedamountlow = () => {
      if (self._cameraInputQueue.length > 0) {
        self.sendCameraData(self._cameraInputQueue.shift());
      }
    };
    this._inputChannel = createDataChannel(pc, 'input-channel');
    this._inputChannel.onclose = () => {
      console.log("INPUT CHANNEL CLOSE");
    }
    this._adbEnabled = adb_enabled;
    if (adb_enabled) {
      this._adbChannel = createDataChannel(pc, 'adb-channel', (msg) => {
        if (this._onAdbMessage) {
          this._onAdbMessage(msg.data);
        } else {
          console.error('Received unexpected ADB message');
        }
      });
    }
    this._controlChannel = awaitDataChannel(pc, 'device-control', (msg) => {
        if (this._onControlMessage) {
          this._onControlMessage(msg);
        } else {
          console.error('Received unexpected Control message');
        }
      },
      (openedChannel) => this._controlDataChannel = openedChannel
    );
    this._bluetoothChannel =
        createDataChannel(pc, 'bluetooth-channel', (msg) => {
          if (this._onBluetoothMessage) {
            this._onBluetoothMessage(msg.data);
          } else {
            console.error('Received unexpected Bluetooth message');
          }
        });
    this._streams = {};
    this._streamPromiseResolvers = {};

    pc.addEventListener('track', e => {
      console.debug('Got remote stream: ', e);
      for (const stream of e.streams) {
        this._streams[stream.id] = stream;
        if (this._streamPromiseResolvers[stream.id]) {
          for (let resolver of this._streamPromiseResolvers[stream.id]) {
            resolver(stream);
          }
          delete this._streamPromiseResolvers[stream.id];
        }
        if (this._streamChangeCallback) {
          this._streamChangeCallback(stream);
        }
      }
    });
  }

  set description(desc) {
    this._description = desc;
  }

  get description() {
    return this._description;
  }

  get isAdbEnabled() {
    return typeof this._adbChannel !== 'undefined';
  }

  get imageCapture() {
    if (this.cameraEnabled && !isApple()) {
      let track = this._cameraTransceivers[0].sender.track;
      return new ImageCapture(track);
    }
    return undefined;
  }

  get cameraStream() {
    return this._localCameraStream;
  }

  get streamResolution() {
    if (this.cameraEnabled) {
      const settings = this._cameraTransceivers[0].sender.track.getSettings();
      return {
        width: settings.width,
        height: settings.height
      };
    }
    return undefined;
  }

  get landscapeStreamResolution() {
    const resolution = this.streamResolution;
    if (resolution) {
      return (resolution.height > resolution.width)
        ? {width: resolution.height, height: resolution.width}
        : resolution;
    }
    return undefined;
  }

  async photoResolution(capture, strict = false) {
    if (capture && this.cameraEnabled) {
      let width = this.streamResolution.width;
      let height = this.streamResolution.height;
      const { imageWidth, imageHeight } = await capture.getPhotoCapabilities();
      if (imageWidth && imageHeight && imageWidth.step && imageHeight.step) {
        const steps = width < height
          ? Math.round(width / imageWidth.step)
          : Math.round(height / imageHeight.step);
        width = steps * imageWidth.step;
        height = steps * imageHeight.step;
      } else {
        console.warn('Cannot get photo capabilities - using video resolution');
      }
      const request_square = true;
      if (request_square) {
        width = Math.min(width, height);
        height = Math.min(width, height);
      }
      if (strict && imageWidth && imageHeight &&
          imageWidth.max && imageHeight.max) {
        width = Math.max(imageWidth.min, Math.min(width, imageWidth.max));
        height = Math.max(imageHeight.min, Math.min(height, imageHeight.max));
      }
      return {
        width: width,
        height: height
      }
    } else if (!capture) {
      console.warn('Cannot get photo resolution without ImageCapture - use video resolution');
      return this.landscapeStreamResolution;
    } else if (!this.cameraEnabled) {
      console.warn('Cannot get photo resolution because camera is disabled');
    }
    return undefined;
  }

  get cameraEnabled() {
    return this._cameraTransceivers && this._cameraTransceivers.length > 0;
  }

  getStream(stream_id) {
    if (stream_id in this._streams) {
      return this._streams[stream_id];
    }
    return null;
  }

  onStream(stream_id) {
    return new Promise((resolve, reject) => {
      if (this._streams[stream_id]) {
        resolve(this._streams[stream_id]);
      } else {
        console.debug('pending stream:', stream_id)
        if (!this._streamPromiseResolvers[stream_id]) {
          this._streamPromiseResolvers[stream_id] = [];
        }
        this._streamPromiseResolvers[stream_id].push(resolve);
      }
    });
  }

  enableTrack(enable, kind) {
    this._pc.getSenders().forEach(sender => {
      if (sender.track && sender.track.kind == kind) {
        sender.track.enabled = enable;
      }
    });
  }

  stopTrack(kind) {
    this._pc.getSenders().forEach(sender => {
      if (sender.track && sender.track.kind == kind) {
        console.log('stop track', sender.track.id);
        sender.track.stop();
      }
    });
  }

  replaceTrack(replacement_track) {
    var sender = this._pc.getSenders().find(sender => {
      return sender.track.kind == replacement_track.kind;
    });
    if (sender) {
      sender.replaceTrack(replacement_track)
        .then(t => {
          console.log('Sender track replaced by', replacement_track.id);
          replacement_track.enabled = true;
        })
        .catch(e => console.error('Unable to replace track: ', e));
    } else {
      console.error('No sender for replaceTrack');
    }
  }

  onStreamChange(cb) {
    this._streamChangeCallback = cb;
  }

  _sendJsonInput(evt) {
    this._inputChannel.send(JSON.stringify(evt));
  }

  sendMousePosition({x, y, down, display_label}) {
    this._sendJsonInput({
      type: 'mouse',
      down: down ? 1 : 0,
      x,
      y,
      display_label,
    });
  }

  // TODO (b/124121375): This should probably be an array of pointer events and
  // have different properties.
  sendMultiTouch({idArr, xArr, yArr, down, slotArr, display_label}) {
    this._sendJsonInput({
      type: 'multi-touch',
      id: idArr,
      x: xArr,
      y: yArr,
      down: down ? 1 : 0,
      slot: slotArr,
      display_label: display_label,
    });
  }

  sendKeyEvent(code, type) {
    this._sendJsonInput({type: 'keyboard', keycode: code, event_type: type});
  }

  disconnect() {
    this._cameraDataChannel.close();
    this._inputChannel.close();
    if (this._adbChannel) {
      this._adbChannel.close();
    }
   
    this._bluetoothChannel.close();
    this._pc.close();
    this._pc = null;
    this._control.signalingWebsocket.close();
  }

  getState() {
    if (!this._pc) {
      return "closed";
    }
    console.log("PC", this._pc.signalingState);
    return this._pc.signalingState;
  }

  isClosed() {
    if (!this._pc) {
      return true;
    }
    return this._pc.signalingState == "closed";
  }

  isConnected() {
    return this._pc && this._pc.connectionState == "connected";
  }

  controlChannelOpen() {
    return this._controlDataChannel && this._controlDataChannel.readyState == 'open';
  }

  // Sends binary data directly to the in-device adb daemon (skipping the host)
  sendAdbMessage(msg) {
    if (this._adbChannel) {
      this._adbChannel.send(msg);
    }
  }

  // Provide a callback to receive data from the in-device adb daemon
  onAdbMessage(cb) {
    this._onAdbMessage = cb;
  }

  // Send control commands to the device
  sendControlMessage(msg) {
    this._controlChannel.send(msg);
  }

  async _useDevice(in_use, transceivers_arr, device_opt) {
    // An empty array means no tracks are currently in use
    if (transceivers_arr.length > 0 === !!in_use) {
      console.warn('Device is already ' + (in_use ? '' : 'not ') + 'in use');
      return in_use;
    }
    if (this._pc.signalingState != 'stable') {
      console.warn('Connection not stable - not altering media streams');
      return transceivers_arr.length > 0;
    }
    if (in_use) {
      try {
        let stream = await navigator.mediaDevices.getUserMedia(device_opt);
        stream.getTracks().forEach(track => {
          console.info(`Using ${track.kind} device: ${track.label}`);
          transceivers_arr.push(this._pc.addTransceiver(track));
        });
        if (device_opt.video && transceivers_arr.length > 0) {
          this._localCameraStream = stream;
          const resolution = this.streamResolution;
          this.sendCameraSettings(resolution);
        }
      } catch (e) {
        console.error('Failed to add stream to peer connection: ', e);
        // Don't return yet, if there were errors some tracks may have been
        // added so the connection should be renegotiated again.
      }
    } else {
      for (const transceiver of transceivers_arr) {
        console.info(
            `Removing ${transceiver.sender.track.kind} `,
            `device: ${transceiver.sender.track.label}`);
        let track = transceiver.sender.track;
        track.stop();
        transceiver.stop();
      }
      // Empty the array passed by reference, just assigning [] won't do that.
      transceivers_arr.length = 0;
    }
    // Return the new state
    return transceivers_arr.length > 0;
  }

  async useMic(in_use) {
    return this._useDevice(in_use, this._micTransceivers, {audio: true});
  }

  async useCamera(in_use) {
    return this._useDevice(in_use, this._cameraTransceivers, {video: true});
  }

  // force landscape so that video stream work well
  async sendCameraSettings(resolution, force_landscape = true, max_fps = 30) {
    if (this.cameraEnabled && resolution) {
      const photo_resolution = await this.photoResolution(this.imageCapture);
      const track = this._cameraTransceivers[0].sender.track;
      const settings = track.getSettings();
      const track_name = track.label;
      const client_name = track_name.substr(0, track_name.indexOf(" ")) +
        "_" + resolution.width.toString() + "x" + resolution.height.toString() +
        "_" + photo_resolution.width.toString() + "x" + photo_resolution.height.toString();
      const fps = Math.min(settings.frameRate, max_fps);

      this.sendControlMessage(JSON.stringify({
        command: 'camera_settings',
        width: force_landscape
          ? Math.max(resolution.width, resolution.height)
          : resolution.width,
        height: force_landscape
          ? Math.min(resolution.width, resolution.height)
          : resolution.height,
        img_width: photo_resolution.width,
        img_height: photo_resolution.height,
        frame_rate: fps,
        facing: settings.facingMode,
        rotation: isiOS() ? 90 : 0,
        name: client_name
      }));
    }
  }

  sendOrQueueCameraData(data) {
    if (this._cameraDataChannel.bufferedAmount > 0 ||
        this._cameraInputQueue.length > 0) {
      this._cameraInputQueue.push(data);
    } else {
      this.sendCameraData(data);
    }
  }

  sendCameraData(data) {
    const MAX_SIZE = 65535;
    const END_MARKER = 'EOF';
    for (let i = 0; i < data.byteLength; i += MAX_SIZE) {
      // range is clamped to the valid index range
      this._cameraDataChannel.send(data.slice(i, i + MAX_SIZE));
    }
    this._cameraDataChannel.send(END_MARKER);
  }

  // Provide a callback to receive control-related comms from the device
  onControlMessage(cb) {
    this._onControlMessage = cb;
  }

  sendBluetoothMessage(msg) {
    this._bluetoothChannel.send(msg);
  }

  onBluetoothMessage(cb) {
    this._onBluetoothMessage = cb;
  }

  // Provide a callback to receive connectionstatechange states.
  onConnectionStateChange(cb) {
    this._pc.addEventListener(
        'connectionstatechange', evt => cb(this._pc.connectionState));
  }
}

import SDPMangler from './sdp_mangler'
class Controller {
  _pc;
  _sdpMangler = new SDPMangler();
  _codecPreference = '';
  _timeouts;

  constructor() {
    if (!isApple()) {
      this._codecPreference = 'VP9'
    }
    console.log('codec preference:',
      this._codecPreference ? this._codecPreference : 'none');
  }

  _onDeviceMessage(message) {
    let type = message.type;
    switch (type) {
      case 'offer':
        this._onOffer({type: 'offer', sdp: message.sdp});
        break;
      case 'answer':
        this._onAnswer({type: 'answer', sdp: message.sdp});
        break;
      case 'ice-candidate':
          this._onIceCandidate(new RTCIceCandidate({
            sdpMid: message.mid,
            sdpMLineIndex: message.mLineIndex,
            candidate: message.candidate
          }));
        break;
      case 'error':
        console.error('Device responded with error message: ', message.error);
        break;
      case 'debug':
        console.debug('Device webrtc logs:', message.logs);
        break;
      default:
        console.error('Unrecognized message type from device: ', type);
    }
  }

  async _sendClientDescription(desc) {
    console.debug('sendClientDescription');
    return this._sendToDevice({type: 'answer', sdp: desc.sdp});
  }

  async _sendIceCandidate(candidate) {
    return this._sendToDevice({type: 'ice-candidate', candidate});
  }

  async _onOffer(desc) {
    console.debug('Remote description (offer): ', desc);
    try {
      await this._pc.setRemoteDescription(desc);
      let answer = await this._pc.createAnswer();
      if (this._codecPreference) {
        let modifiedSdp = this._sdpMangler.parse(answer.sdp)
          .preferCodec(this._codecPreference)
          .getMangledSdp();
        answer.sdp = modifiedSdp;
      }
      console.debug('Answer: ', answer);
      await this._pc.setLocalDescription(answer);
      await this._sendClientDescription(answer);
    } catch (e) {
      console.error('Error processing remote description (offer)', e)
      throw e;
    }
  }

  async _onAnswer(answer) {
    console.debug('Remote description (answer): ', answer);
    try {
      await this._pc.setRemoteDescription(answer);
      this._logVideoCodec();
    } catch (e) {
      console.error('Error processing remote description (answer)', e)
      throw e;
    }
  }

  _onIceCandidate(iceCandidate) {
    if (this._pc.signalingState != "closed") {
      //console.debug(`Remote ICE Candidate: `, iceCandidate);
      this._pc.addIceCandidate(iceCandidate);
    }
  }

  _logVideoCodec() {
    this._pc.getSenders().forEach((sender) => {
      if (sender.track && sender.track.kind == 'video') {
        const codec = sender.getParameters().codecs[0];
        console.log(`Sender video mime type:${codec.mimeType}`);
      }
    });
  }

  RetryConnection() {
    let timeoutIt = this._timeouts.next();
    if (timeoutIt.done || !this._pc) {
      return false;
    }
    console.log(`Restart ICE gathering in ${timeoutIt.value} milliseconds`);
    setTimeout(() => {
      if (this._pc && this._pc.connectionState == 'failed') {
        this._pc.restartIce();
      }
    }, timeoutIt.value);
    return true;
  }

  ConnectDevice(pc, infraConfig) {
    this._pc = pc;
    this._timeouts = iceRestartTimeout();
    console.debug('ConnectDevice');
    // ICE candidates will be generated when we add the offer. Adding it here
    // instead of in _onOffer because this function is called once per peer
    // connection, while _onOffer may be called more than once due to
    // renegotiations.
    this._pc.addEventListener('icecandidate', evt => {
      if (evt.candidate) this._sendIceCandidate(evt.candidate);
    });
    this._pc.addEventListener('negotiationneeded', evt => {
      this.renegotiateConnection();
    })
    this._sendToDevice(
      {type: 'request-offer', ice_servers: infraConfig.ice_servers});
  }

  async renegotiateConnection() {
    if (this._pc.connectionState == 'new') {
      console.log("Connection has not been establised - don't renegotiate");
      return;
    }
    console.debug('Re-negotiating connection');
    let offer = await this._pc.createOffer();
    if (this._codecPreference) {
      let modifiedSdp = this._sdpMangler.parse(offer.sdp)
        .preferCodec(this._codecPreference)
        .getMangledSdp();
      offer.sdp = modifiedSdp;
    }
    console.debug('Local description (offer): ', offer);
    await this._pc.setLocalDescription(offer);
    this._sendToDevice({type: 'offer', sdp: offer.sdp});
  }
}

class WebsocketController extends Controller {
  _promiseResolvers;
  _websocket;

  constructor(websocket) {
    super();

    websocket.onmessage = e => {
      let data = JSON.parse(e.data);
      this._onWebsocketMessage(data);
    };
    this._websocket = websocket;

    this._promiseResolvers = {};
  }

  get signalingWebsocket() {
    return this._websocket;
  }

  _onWebsocketMessage(message) {
    const type = message.message_type;
    if (message.error) {
      console.error(message.error);
      this._on_connection_failed(message.error);
      return;
    }
    switch (type) {
      case 'config':
        this._infra_config = message;
        break;
      case 'device_info':
        if (this._on_device_available) {
          this._on_device_available(message.device_info);
          delete this._on_device_available;
        } else {
          console.error('Received unsolicited device info');
        }
        break;
      case 'device_msg':
        this._onDeviceMessage(message.payload);
        break;
      default:
        console.error('Unrecognized message type from server: ', type);
        this._on_connection_failed(
            'Unrecognized message type from server: ' + type);
        console.error(message);
    }
  }

  async _wsSendJson(obj) {
    return this._websocket.send(JSON.stringify(obj));
  }

  async _sendToDevice(payload) {
    return this._wsSendJson({message_type: 'forward', payload});
  }

  async requestDevice(device_id) {
    return new Promise((resolve, reject) => {
      this._on_device_available = (deviceInfo) => resolve({
        deviceInfo,
        infraConfig: this._infra_config,
      });
      this._on_connection_failed = (error) => reject(error);
      this._wsSendJson({
        message_type: 'connect',
        device_id,
      });
    });
  }
}

class PollingController extends Controller {
  _connectUrl;
  _forwardUrl;
  _pollUrl;
  _connection_id;
  _infraConfig;
  _pollerSchedule;

  constructor(connectUrl, forwardUrl, pollUrl, infra_config) {
    super();

    this._connectUrl = connectUrl;
    this._forwardUrl = forwardUrl;
    this._pollUrl = pollUrl;
    this._infraConfig = infra_config;
  }

  _startPolling() {
    if (this._pollerSchedule !== undefined) {
      return;
    }

    let currentPollDelay = 1000;
    let pollerRoutine = async () => {
      let messages = await ajaxPostJson(this._pollUrl, {
        connection_id: this._connection_id,
      });
      // Do exponential backoff on the polling up to 60 seconds
      currentPollDelay = Math.min(60000, 2 * currentPollDelay);
      for (const message of messages) {
        this._onDeviceMessage(message);
        // There is at least one message, poll sooner
        currentPollDelay = 1000;
      }
      this._pollerSchedule = setTimeout(pollerRoutine, currentPollDelay);
    };

    this._pollerSchedule = setTimeout(pollerRoutine, currentPollDelay);
  }

  async _sendToDevice(obj) {
    // Forward messages act like polling messages as well
    let device_messages = await ajaxPostJson(this._forwardUrl, {
      connection_id: this._connection_id,
      payload: obj,
    });
    for (const message of device_messages) {
      this._onDeviceMessage(message);
    }
  }

  async requestDevice(device_id) {
    let response = await ajaxPostJson(this._connectUrl, {
             device_id
           });
    this._connection_id = response.connection_id;

    // Start polling after we get a connection id
    this._startPolling();

    return {
      deviceInfo: response.device_info,
      infraConfig: this._infraConfig,
    };
  }
}

async function createController(options) {
  let ws = await new Promise((resolve, reject) => {
    let ws = new WebSocket(options.wsUrl);
    ws.onopen = () => {
      console.debug(`Connected to ${options.wsUrl}`);
      resolve(ws);
    };
    ws.onclose = evt => {
      console.log('WebSocket closed:', evt.reason)
    };
    ws.onerror = evt => {
      console.error('WebSocket error:', evt);
      reject(evt);
    };
  });
  return new WebsocketController(ws);
}

function createPeerConnection(infra_config) {
  let pc_config = {iceServers: [], iceTransportPolicy: resolveTransportPolicy(infra_config.ice_servers) };
  pc_config.iceServers = infra_config.ice_servers;
  let pc = new RTCPeerConnection(pc_config);

  pc.addEventListener('icecandidate', evt => {
    console.debug('Local ICE Candidate: ', evt.candidate);
  });
  pc.addEventListener('iceconnectionstatechange', evt => {
    console.debug(`ICE State Change: ${pc.iceConnectionState}`);
  });
  pc.addEventListener(
      'connectionstatechange',
      evt => console.debug(
          `WebRTC Connection State Change: ${pc.connectionState}`));
  return pc;
}

export async function Connect(deviceId, options) {
  let control = await createController(options);

  let requestRet = await control.requestDevice(deviceId);
  let deviceInfo = requestRet.deviceInfo;
  let infraConfig = requestRet.infraConfig;
  console.debug('Device available:');
  console.debug(deviceInfo);
  let pc_config = {iceServers: []};
  if (infraConfig.ice_servers && infraConfig.ice_servers.length > 0) {
    for (const server of infraConfig.ice_servers) {
      pc_config.iceServers.push(server);
    }
  }
  let pc = createPeerConnection(infraConfig);
 
  let mediaStream;
  try {
    mediaStream =
      await navigator.mediaDevices.getUserMedia({video: false, audio: true});
    const tracks = mediaStream.getTracks();
    tracks.forEach(track => {
      console.log(`Using ${track.kind} device: ${track.label}`);
      pc.addTrack(track, mediaStream);
    });
  } catch (e) {
    console.error('Failed to open device: ', e);
  }

  let deviceConnection = new DeviceConnection(pc, control, false);
  deviceConnection.description = deviceInfo;

  let connected_promise = new Promise((resolve, reject) => {
    pc.addEventListener('connectionstatechange', evt => {
      let state = pc.connectionState;
      console.log(Date.now(),"Connection state change. New state: " + state);
      if (state == 'connected') {
        resolve(deviceConnection);
      } else if (state == 'failed') {
        if (!control.RetryConnection()) {
          setTimeout(() => {
            if (pc.connectionState == 'failed') {
              reject(evt)
            }
          }, 2000);
        }
      }
      if (deviceConnection.connectionChangeCallback) {
        deviceConnection.connectionChangeCallback(pc.connectionState);
      }
    });
    control.ConnectDevice(pc, infraConfig);
  });

  return connected_promise;
}

function resolveTransportPolicy(ice_servers) {
  let transportPolicy = 'all';
  ice_servers.forEach(server => {
    if (server.urls) {
      server.urls.forEach(url => {
        if (url && url.length > 4) {
          let serverType = url.substr(0,4);
          if (serverType.toLowerCase() == 'turn') {
            transportPolicy = 'relay';
            return;
          }
        }
      })
    }
  });
  return transportPolicy;
}

