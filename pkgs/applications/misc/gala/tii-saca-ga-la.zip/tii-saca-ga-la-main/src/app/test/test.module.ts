import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { TestPage } from './test.page';

import { LoginModule } from '../common/login/login.module';
import { TestPageRoutingModule } from './test-routing.module';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    TestPageRoutingModule,
    LoginModule,
  ],
  declarations: [TestPage],
})
export class TestPageModule {}
