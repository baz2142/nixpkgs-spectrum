import { Injectable } from '@angular/core';
import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';

@Injectable()
export class ReloadGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | UrlTree {
    if (this.isPageRefresh()) {
      const tree: UrlTree = this.router.parseUrl('/tabs/device');
      return tree;
    } else {
      return true;
    }
  }

  // I determine if the current route-request is part of a page refresh.
  private isPageRefresh(): boolean {
    // If the router has yet to establish a single navigation, it means that this
    // navigation is the first attempt to reconcile the application state with the
    // URL state. Meaning, this is a page refresh.
    return !this.router.navigated;
  }
}
