export const environment = {
  production: true,
};

export const BACKEND_UNSECURE = false;
export const SACA_MODE = 'Test';

const TEST_BACKEND = require('./backends.js').TEST_BACKEND;

// Backend definition
export const BACKEND = {
  ADDRESS: TEST_BACKEND.ADDRESS,
  PROTOCOL: TEST_BACKEND.PROTOCOL,
  WSPROTOCOL: TEST_BACKEND.WSPROTOCOL,
  PORT: TEST_BACKEND.PORT,
};

export const STATUSBACKEND = {
  ADDRESS: 'saca-statusservice-gcfiv4xhra-ew.a.run.app',
  WSPROTOCOL: 'wss://',
  PORT: ':443',
};
