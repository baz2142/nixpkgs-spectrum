import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, Platform, ToastController } from '@ionic/angular';
import { GridApi, GridOptions } from 'ag-grid-community';
import { forkJoin } from 'rxjs';
import { DropDownEditor } from '../../common/dropdown/dropdown.editor';
import { LinkCellRenderer } from '../../common/link-cell-renderer.component';
import { SelectCellRenderer } from '../../common/select-cell-renderer.component';
import {
  ContainerService,
  InstanceGroupInfo,
  InstanceGroupInstanceResponse,
  InstanceGroupsResponse,
  InstanceInfo,
  RequestStatus,
} from '../../container.service';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-instancegroups',
  templateUrl: 'instancegroups.component.html',
  styleUrls: ['instancegroups.component.scss'],
})
export class InstanceGroupsComponent implements OnInit {
  public instanceGroupInstances: InstanceInfo[];
  selectedGroupName: string;
  selectedInstanceAddress: string;

  groupsGridOptions: GridOptions;
  gridApi: GridApi;

  public frameworkComponents = {
    dropdownEditor: DropDownEditor,
    linkCellRenderer: LinkCellRenderer,
    selectCellRenderer: SelectCellRenderer,
  };

  public groupsColumnDefs = [
    {
      headerName: 'Group name',
      field: 'Name',
      sortable: true,
      editable: false,
      cellRenderer: 'linkCellRenderer',
      cellRendererParams: {
        clicked: (Name: string) => {
          this.navigateToGroup(Name);
        },
      },
      minWidth: 300,
      maxWidth: 300,
    },
    {
      headerName: 'Created',
      field: 'Created',
      sortable: true,
      editable: false,
      valueFormatter: (param) => this.formatDate(param.value),
      flex: 1,
    },
    {
      headerName: 'Template',
      field: 'InstanceTemplate',
      sortable: true,
      editable: false,
      valueFormatter: (param) => {
        const templateName = param.value;
        return templateName.substr(templateName.lastIndexOf('/') + 1);
      },
      flex: 1,
      tooltipField: 'InstanceTemplate',
      tooltip: (value: string): string => value,
    },
    {
      headerName: 'AOSP Build Id',
      field: 'Settings.AospBuildId',
      sortable: true,
      editable: false,
      flex: 1,
      tooltipField: 'Settings.AospBuildId',
      tooltip: (value: string): string => value,
    },
    {
      headerName: 'Config',
      field: 'Config.CuttlefishDefaultOptions',
      sortable: true,
      editable: false,
      flex: 1,
      tooltipField: 'Config.CuttlefishDefaultOptions',
      tooltip: (value: string): string => value,
    },
    {
      headerName: 'VM count',
      field: 'TargetSize',
      sortable: true,
      editable: false,
      minWidth: 130,
      maxWidth: 130,
    },
    {
      headerName: 'CVD count',
      field: 'Settings.NumCvdInstances',
      sortable: true,
      editable: false,
      minWidth: 130,
      maxWidth: 140,
    },
    {
      headerName: 'Stable',
      field: 'Stable',
      sortable: true,
      editable: false,
      filter: false,
      minWidth: 110,
      maxWidth: 110,
    },
    {
      headerName: 'Actions',
      headerClass: 'center-label',
      field: 'Name',
      cellStyle: { display: 'flex', justifyContent: 'center' },
      cellRenderer: 'selectCellRenderer',
      cellRendererParams: {
        actions: this.generateActions(),
      },
      suppressMenu: true,
      minWidth: 100,
      maxWidth: 100,
      resizable: false,
      sortable: false,
      editable: false,
      filter: false,
    },
  ];

  constructor(
    private platform: Platform,
    private toastController: ToastController,
    private containerService: ContainerService,
    private userService: UserService,
    private alertController: AlertController,
    private router: Router
  ) {}

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);

      if (authenticated) {
        this.refreshInstanceGroups();
      }
    });

    this.groupsGridOptions = this.generateGridOptions(
      this.sortGrid,
      'Created',
      'desc'
    );
  }

  generateActions() {
    const actions = new Array();
    actions.push({
      title: 'Delete',
      value: 'delete',
      action: (groupName) => {
        this.deleteGroup(groupName);
      },
    });
    actions.push({
      title: 'Scale up',
      value: 'scaleup',
      action: (groupName) => {
        this.scaleGroupUp(groupName);
      },
    });

    return actions;
  }

  formatDate(date: string): string {
    const parsed = new Date(Date.parse(date));
    return `${parsed.toLocaleString(navigator.language)}`;
  }

  getNavigationLink(name: string) {
    return 'test' + name;
  }

  getActionTitle(id: string) {
    return '...';
  }

  actionList(): string[] {
    return ['Something', 'Else'];
  }

  generateGridOptions(
    gridSort: any,
    column: string,
    direction: string
  ): GridOptions {
    return {
      onGridReady: (param) => {
        param.api.sizeColumnsToFit();
        gridSort(param, column, direction);
        this.gridApi = param.api;
      },
      onCellDoubleClicked: (param) => {
        param.api.sizeColumnsToFit();
      },
      onRowDataChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      onGridSizeChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      defaultColDef: {
        flex: 1,
        minWidth: 100,
        resizable: true,
        sortable: true,
        editable: true,
        filter: true,
      },
      tooltipShowDelay: 1000,
      rowSelection: 'single',
      enableCellTextSelection: true,
    } as GridOptions;
  }

  sortGrid(param, field, sortDir) {
    const columnState = {
      // https://www.ag-grid.com/javascript-grid-column-state/#column-state-interface
      state: [
        {
          colId: field,
          sort: sortDir,
        },
      ],
    };
    param.columnApi.applyColumnState(columnState);
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
    });
    toast.present();
  }

  async presentConfirmation(question: string): Promise<boolean> {
    const alert = await this.alertController.create({
      header: 'Confirmation',
      message: question,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
        },
        {
          text: 'OK',
          role: 'ok',
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    return role === 'ok';
  }

  refreshInstanceGroups() {
    console.log('Refresh instance groups');
    this.gridApi?.showLoadingOverlay();
    this.containerService
      .refreshInstanceGroups()
      .subscribe((result: InstanceGroupsResponse) => {
        console.log('List groups result', result);
        this.gridApi?.hideOverlay();
      });
  }

  public get instanceGroups(): InstanceGroupInfo[] {
    return this.containerService.getInstanceGroups();
  }

  navigateToGroup(groupName: string) {
    this.router.navigateByUrl('/tabs/admin/instancegroups/' + groupName);
  }

  listGroupInstances(groupName: string) {
    this.selectedGroupName = groupName;
    this.containerService
      .listGroupInstances(groupName)
      .subscribe((result: InstanceGroupInstanceResponse) => {
        console.log('List group instances result', result);
        if (result.Status) {
          //this.selectedInstanceAddress = "";
          this.instanceGroupInstances = result.Instances;
        }
      });
  }

  instanceGroup(name: string): InstanceGroupInfo {
    return this.instanceGroups
      .filter((group) => {
        return group.Name === name;
      })
      ?.pop();
  }


  deleteGroup(groupName: string) {
    const observables = [];

    this.presentConfirmation(
      `Do you want to delete the group ${groupName}?`
    ).then((answer) => {
      if (answer) {
        this.containerService
      .deleteInstanceGroup(groupName)
      .subscribe((result: RequestStatus) => {
        console.log('List group instances result', result);
        if (result.Status) {
          this.refreshInstanceGroups();
          this.presentToast(groupName + ': Instance group deleted');
        }
      });
      }
    });
  }

  scaleGroupUp(groupName: string) {
    const group = this.instanceGroup(groupName);
    this.scaleGroup(groupName, group.TargetSize + 1);
  }


  scaleGroup(groupName: string, scaling: number) {
    this.presentConfirmation(
      `Do you want to scale the group ${groupName} to ${scaling} instances?`
    ).then((answer) => {
      if (answer) {
        this.containerService
          .scaleInstanceGroup(groupName, scaling)
          .subscribe((result: RequestStatus) => {
            console.log('Instance group scale result', result);
            if (result.Status) {
              this.presentToast(groupName + ': Instance group re-scaled');
              this.refreshInstanceGroups();
            }
          });
      }
    });
  }
}
