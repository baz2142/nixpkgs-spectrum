import { AfterViewInit, Component, ViewChild, ViewContainerRef } from '@angular/core';
import { ICellEditorAngularComp } from 'ag-grid-angular';

type CvdOption = {
  name: string,
  value: string
};

@Component({
  selector: 'dropdown-cell-editor',
  templateUrl: 'dropdown.editor.html',
})
export class DropDownEditor implements ICellEditorAngularComp, AfterViewInit {
  private params: any;
  public value: string;
  public options: CvdOption[];
  public selected: CvdOption;

 // @ViewChild('input', { read: ViewContainerRef }) public input;

  agInit(params: any): void {
    this.params = params;
    this.value = this.params.value;
    this.options = this.params.getoptions();
    this.options.forEach((option) => {
      if (option.value === this.value) {
        this.selected = option;
      }
    });
  }

  getValue(): any {
    return this.value;
  }

  ngAfterViewInit() {
    /*window.setTimeout(() => {
      this.input.element.nativeElement.focus();
    });*/
  }

  onChange($event) {
    console.log("SELECTABLE CHANGE", $event);
    this.value = $event.value.value;
  }
}
