import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Platform } from '@ionic/angular';
import firebase from 'firebase/compat/app';
import { Observable, Subject } from 'rxjs';
import { share } from 'rxjs/operators';
import { ENVIRONMENTAPI, USERAPI } from '../environments/endpoints';
import { BACKEND, BACKEND_UNSECURE, SACA_MODE, STATUSBACKEND } from '../environments/environment';
import { CuttlefishMapping, DeviceInstance, RequestStatus } from './container.service';

export type CloudRevision = {
  ServiceName: string;
  RevisionName: string;
  Created: string;
};

export type CloudRevisionResponse = {
  Status: boolean;
  AdminRevision: CloudRevision;
  BackendRevision: CloudRevision;
};

export type UserInfo = {
  UID?: string;
  DisplayName?: string;
  Email?: string;
  Phone?: string;
  Role?: string;
  DeviceId?: string;
  PasswordHash?: string;
};

export type UserInfoResponse = {
  Status: boolean;
  Users: UserInfo[];
};

export type UserResponse = {
  Status: boolean;
  User: UserInfo;
};

export type ApplicationSettings = {
  ConnectAutomatically: boolean;
};

export type BatchAddUsersRequest = {
  InstanceGroups: string[];
  Users: UserInfo[];
};

export type BatchDeleteUsersRequest = {
  Users: UserInfo[];
};

const ROLE_SUPER = 'super';
const ROLE_ADMIN = 'admin';
const ROLE_USER = 'user';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  public backendRevision: CloudRevision;
  public adminRevision: CloudRevision;
  public authStateSubject: Subject<boolean>;
  private defaultDevice: DeviceInstance;
  private token: string = null;
  private userData: firebase.User;
  private role: string;
  private deviceUserData: any;
  private authInitSubject: Subject<boolean>;
  private firebaseTokenRefresh: NodeJS.Timeout;
  private applicationSettings: ApplicationSettings = {
    ConnectAutomatically: false,
  };

  public defaultDeviceUpdated$: EventEmitter<DeviceInstance>;

  constructor(private httpClient: HttpClient, private firebaseAuth: AngularFireAuth, private platform: Platform) {
    console.log('User service constructor');

    /* Saving user data in localstorage when
    logged in and setting up null when logged out */
    this.userData = this.readFromLocalStorage('sacauser');
    this.deviceUserData = this.readFromLocalStorage('sacadeviceuser');
    this.applicationSettings = this.readFromLocalStorage('sacasettings', this.defaultAppSettings);
    this.applicationSettings.ConnectAutomatically = false; // Temporary disable of automatic connect

    this.authStateSubject = new Subject();
    this.authInitSubject = new Subject();

    this.defaultDeviceUpdated$ = new EventEmitter();

    this.firebaseAuth.authState.subscribe((user) => {
      this.handleDesktopAuthChange(user);
    });

    const currentTime = new Date().toLocaleString();
    console.log('Instantiating token refresh timer', currentTime);
    this.firebaseTokenRefresh = setInterval(() => {
      const refreshTime = new Date().toLocaleString();
      console.log('Running Firebase token refresh...', refreshTime);
      firebase
        .auth()
        .currentUser.getIdToken(true)
        .then(
          (idToken) => {
            this.token = idToken;
          },
          (reason: any) => {
            console.log('Refresh token rejected', reason);
            this.token = null;
            this.completeAuthInit(false);
            this.authStateSubject.next(true);
          }
        )
        .catch((error) => {
          console.log('Refresh token catch error', error);
        });
    }, 3540000); // 59 minutes firebase token refresh (1 hr expiration)
  }

  public whenAuthenticated(): Promise<boolean> {
    if (this.authInitSubject.isStopped) {
      this.authInitSubject = new Subject();
      setTimeout(() => {
        this.completeAuthInit(this.token !== null);
      }, 1);
    }
    return this.authInitSubject.toPromise();
  }

  private completeAuthInit(authenticated: boolean) {
    this.authInitSubject.next(authenticated);
    this.authInitSubject.complete();
  }

  public getToken(): string {
    return this.token;
  }

  public getUserEmail(): string {
    if (this.userData) {
      return this.userData.email;
    } else if (this.deviceUserData) {
      return this.deviceUserData.email;
    } else {
      return null;
    }
  }

  public isDesktop(): boolean {
    return !this.platform.is('hybrid');
  }

  public login(userName: string, password: string): Promise<any> {
    return this.loginDesktop(userName, password);
  }

  public changeUserPassword(currentPassword, newPassword): Promise<any> {
    return new Promise((resolve, reject) => {
      const currentUser = firebase.auth().currentUser;
      const credentials = firebase.auth.EmailAuthProvider.credential(currentUser.email, currentPassword);

      currentUser
        .reauthenticateWithCredential(credentials)
        .then((auth) => {
          currentUser
            .updatePassword(newPassword)
            .then((response) => {
              console.log('success: ' + response);
              resolve(auth);
            })
            .catch((error) => {
              console.log('error: ' + error);
              reject(error);
            });
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  public loginWithPhone(phoneNumber: string): Promise<any> {
    throw new Error('loginWithPhone not supported');
  }

  public confirmPhoneAuth(code: string): Promise<any> {
    throw new Error('confirmPhoneAuth not supported');
  }

  public logout() {
    console.log('Logout');
    this.firebaseAuth.signOut();
  }

  public get sacaMode(): string {
    return SACA_MODE;
  }

  public get userRole(): string {
    return this.role;
  }

  public isSuperUser(): boolean {
    return this.role === ROLE_SUPER;
  }

  public isAdminUser(): boolean {
    return this.role === ROLE_ADMIN;
  }

  public isNormalUser(): boolean {
    return this.role === ROLE_USER;
  }

  public get autoConnect(): boolean {
    return this.applicationSettings.ConnectAutomatically;
  }

  public set autoConnect(connect: boolean) {
    this.applicationSettings.ConnectAutomatically = connect;
    this.saveToLocalStorage('sacasettings', this.applicationSettings);
  }

  public backendAddress(): string {
    // Since only webui is using NGINX, we need to return the real backend address for mobile devices
    if (this.isDesktop()) {
      return 'saca-api';
    } else {
      return BACKEND.PROTOCOL + BACKEND.ADDRESS + BACKEND.PORT;
    }
  }

  public websocketAddress(): string {
    return STATUSBACKEND.WSPROTOCOL + STATUSBACKEND.ADDRESS + STATUSBACKEND.PORT;
  }
  public resolveEndpoint(resource: any): string {
    let endpoint = this.backendAddress() + '/' + resource;
    if (BACKEND_UNSECURE) {
      endpoint += 'unsecure';
    }
    return endpoint;
  }

  public resolveWebsocketEndpoint(resource: any): string {
    let endpoint = this.websocketAddress() + '/' + resource;
    if (BACKEND_UNSECURE) {
      endpoint += 'unsecure';
    }
    return endpoint;
  }

  public getEnvironmentVersions(adminEnv: string): Observable<CloudRevisionResponse> {
    const obs = this.createRequest(ENVIRONMENTAPI.VERSIONS, adminEnv, 'adminenv').pipe(share());

    obs.subscribe((result: CloudRevisionResponse) => {
      if (result && result.Status) {
        this.adminRevision = result.AdminRevision;
        this.backendRevision = result.BackendRevision;
      }
    });

    return obs;
  }

  public publishDefaultDeviceInfo() {
    this.defaultDeviceUpdated$.emit(this.defaultDevice);
  }

  public getDefaultDevice(): Observable<CuttlefishMapping> {
    console.log('User service get default device');
    const obs = this.createRequest(USERAPI.DEFAULTDEVICE, null).pipe(share());
    obs.subscribe((result: DeviceInstance) => {
      this.defaultDevice = result;
      this.publishDefaultDeviceInfo();
    });

    return obs;
  }

  public refreshToken() {
    firebase
      .auth()
      .currentUser.getIdToken(true)
      .then(
        (idToken) => {
          console.log('refresh got token', idToken);
          this.token = idToken;
          this.completeAuthInit(true);
          this.authStateSubject.next(true);
        },
        (reason: any) => {
          console.log('authentication rejected', reason);
          this.token = null;
          this.completeAuthInit(false);
          this.authStateSubject.next(false);
        }
      )
      .catch((error) => {
        console.log('Refresh token catch error', error);
      });
  }

  public getPasswordReset(): Observable<RequestStatus> {
    return this.createRequest(USERAPI.PASSWORDRESET, null);
  }

  public getPasswordResetForUser(userId: string): Observable<RequestStatus> {
    return this.createRequest(USERAPI.PASSWORDRESETFORUSER, userId, 'userid');
  }

  private handleDesktopAuthChange(user: firebase.User) {
    console.log('Auth state changed', user);
    if (user) {
      this.userData = user;
      localStorage.setItem('sacauser', JSON.stringify(this.userData));
      if (user) {
        user.getIdTokenResult().then(
          (idTokenResult: firebase.auth.IdTokenResult) => {
            console.log('Authentication OK', idTokenResult.token);
            this.token = idTokenResult.token;
            this.role = idTokenResult.claims.role;
            console.log('Current role ' + this.role);
            console.log('Claims', idTokenResult.claims);
            this.completeAuthInit(true);
            this.authStateSubject.next(true);
          },
          (reason: any) => {
            console.log('authentication rejected', reason);
            this.token = null;
            this.completeAuthInit(false);
            this.authStateSubject.next(false);
          }
        );
      }
    } else {
      localStorage.setItem('sacauser', null);
      this.userData = null;
      this.token = null;
      this.completeAuthInit(false);
      this.authStateSubject.next(false);
    }
  }

  private handleDeviceAuthChange(user: any) {
    console.log('Device Auth state changed', user);
    if (user) {
      this.deviceUserData = user;
      localStorage.setItem('sacadeviceuser', JSON.stringify(this.deviceUserData));
      if (user) {
        throw new Error('handleDeviceAuthChange not supported for user');
      }
    } else {
      localStorage.setItem('sacadeviceuser', null);
      this.deviceUserData = null;
      this.token = null;
      this.completeAuthInit(false);
      this.authStateSubject.next(false);
    }
  }

  private loginDesktop(userName: string, password: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.firebaseAuth
        .signInWithEmailAndPassword(userName, password)
        .then((credential: firebase.auth.UserCredential) => {
          console.log('Sign in status: ', credential);
          credential.user
            .getIdToken(false)
            .then((data: string) => {
              console.log('Token status', data);
              // this.setToken(data);
              resolve(true);
            })
            .catch((err) => {
              console.error('Token error', err);
              reject();
            });
        })
        .catch((err) => {
          console.error('Sign in error', err);
          reject();
        });
    });
  }

  private createRequest(endpoint: string, queryParam: string, paramName?: string): Observable<any> {
    let url = this.resolveEndpoint(endpoint);

    // Append deviceid param if given
    let queryParamName = 'deviceid';
    if (paramName) {
      queryParamName = paramName;
    }
    if (queryParam) {
      url = url + '?' + queryParamName + '=' + queryParam;
    }

    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'json',
    });
  }

  private getHeaders(contentType?: string): HttpHeaders {
    let headers = new HttpHeaders();
    if (contentType) {
      headers = headers.set('Content-Type', contentType);
    }
    return headers;
  }

  private readFromLocalStorage(storageKey: string, defaultInitializer?: () => any): any {
    const item = localStorage.getItem(storageKey);
    console.log('Read from localstorage', storageKey, item);
    if (item) {
      return JSON.parse(item);
    } else {
      return defaultInitializer ? defaultInitializer() : {};
    }
  }

  private saveToLocalStorage(storageKey: string, data: any) {
    console.log('Saving data to local storage: ' + storageKey, data);
    localStorage.setItem(storageKey, JSON.stringify(data));
  }

  private defaultAppSettings(): ApplicationSettings {
    return {
      ConnectAutomatically: true,
    };
  }
}
