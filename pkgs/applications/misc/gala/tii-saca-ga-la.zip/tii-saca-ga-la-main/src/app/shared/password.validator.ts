import { AbstractControl, ValidationErrors } from '@angular/forms';

export class CustomValidators {
  static PasswordsMatchValidator(
    control: AbstractControl
  ): ValidationErrors | null {
    const password = control.get('password_new');
    const confirmPassword = control.get('password_verify');

    return password?.value === confirmPassword?.value
      ? null
      : { notmatched: true };
  }
}
