import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {
  AlertController,
  ModalController,
  Platform,
  ToastController,
} from '@ionic/angular';
import {
  ColumnState,
  GridApi,
  GridOptions,
  ValueSetterParams,
} from 'ag-grid-community';
import { distinctUntilChanged } from 'rxjs/operators';
import { BtnCellRenderer } from '../../common/btn-cell-renderer.component';
import { DevicecardModalPage } from '../../common/devicecard/devicecard.modal';
import { DropDownEditor } from '../../common/dropdown/dropdown.editor';
import { SelectCellRenderer } from '../../common/select-cell-renderer.component';
import { SpinnerCellRenderer } from '../../common/spinner-cell-renderer.component';
import {
  ContainerService,
  DeviceInstance,
  DeviceInstanceResponse,
  RequestStatus,
} from '../../container.service';
import { SacaUsersService } from '../../sacausers.service';
import { UserInfo, UserService } from '../../user.service';

const roles = {
  user: 'User',
  admin: 'Admin',
  super: 'Superuser',
};

@Component({
  selector: 'app-users',
  templateUrl: 'users.component.html',
  styleUrls: ['users.component.scss'],
})
export class UsersComponent implements OnInit {
  users: UserInfo[] = null;
  filteredUsers: UserInfo[] = null;
  allDevices: DeviceInstance[] = [];
  mappedDevices: any;
  activeActions: any = [];

  gridApi: GridApi;
  columnApi: any;
  gridOptions: GridOptions;
  columnDefs = [];

  showAddUsers: true;

  gridFilters = {
    showUsers: true,
    showAdmins: true,
    showSupers: true,
    showRegistered: true,
    showUnregistered: true,
  };

  public newUser: UserInfo = {
    UID: null,
    DisplayName: null,
    Email: null,
    Phone: null,
    Role: null,
    DeviceId: '',
  };

  public frameworkComponents = {
    btnCellRenderer: BtnCellRenderer,
    dropdownEditor: DropDownEditor,
    selectCellRenderer: SelectCellRenderer,
    spinnerCellRenderer: SpinnerCellRenderer,
  };

  customActionSheetOptions: any = {
    header: 'Device',
    subHeader: 'Select the reserved device',
    cssClass: 'custom-device-select',
  };

  public defaultSortState: ColumnState[];

  @Output() toggleTabsNotification: EventEmitter<any> = new EventEmitter();

  constructor(
    private platform: Platform,
    private toastController: ToastController,
    private alertController: AlertController,
    private userService: UserService,
    private containerService: ContainerService,
    private sacaUsersService: SacaUsersService,
    private modalController: ModalController
  ) {
    this.defaultSortState = [
      { colId: 'Role', sort: 'asc', sortIndex: 0 },
      { colId: 'DisplayName', sort: 'asc', sortIndex: 1 },
    ] as ColumnState[];
  }

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);

      if (authenticated) {
        this.sacaUsersService.fetchUsers(false);
        this.fetchDevices();
        this.sacaUsersService.sacaUsers$.subscribe((users) => {
          if (users) {
            console.log('Setting users', users);
            if (this.gridApi) {
              this.gridApi.hideOverlay();
            }
            this.users = users;
            this.filteredUsers = this.getShownUsers();
          }
        });

        this.containerService.cvdStatusUpdated$
          .pipe(
            distinctUntilChanged(
              (a, b) => JSON.stringify(a) === JSON.stringify(b)
            )
          )
          .subscribe((status) => {
            this.mappedDevices = this.deviceListForSelect('');
            if (this.gridApi) {
              this.gridApi.refreshCells({ force: true });
            }
          });
      }
    });

    this.gridOptions = {
      onGridReady: (param) => {
        this.gridApi = param.api;
        param.api.sizeColumnsToFit();
        this.sortGrid(param, this.defaultSortState);
      },

      onCellDoubleClicked: (param) => {
        param.api.sizeColumnsToFit();
      },

      onGridSizeChanged: (param) => {
        param.api.sizeColumnsToFit();
      },

      onRowDataChanged: (param) => {
        param.api.sizeColumnsToFit();
        this.sortGrid(param, this.defaultSortState);
      },
      enableCellTextSelection: true,
      //enableCellChangeFlash: true,
      rowHeight: 35,
    } as GridOptions;

    this.createColumnDefs();
  }

  private createColumnDefs() {
    this.columnDefs = [
      {
        headerName: 'Name',
        field: 'DisplayName',
        sortable: true,
        editable: true,
        filter: true,
        minWidth: 150,
      },
      {
        headerName: 'Email',
        field: 'Email',
        sortable: true,
        editable: false,
        filter: true,
        minWidth: 200,
      },
      {
        headerName: 'Role',
        field: 'Role',
        sortable: true,
        editable: true,
        filter: true,
        cellEditor: 'agSelectCellEditor',
        cellEditorParams: {
          values: this.extractValues(roles),
        },
        valueFormatter: (params) => {
          return this.lookupValue(roles, params.value);
        },
        minWidth: 140,
        maxWidth: 140,
        singleClickEdit: true,
      },
      {
        headerName: 'Device',
        field: 'DeviceId',
        sortable: true,
        minWidth: 300,
        singleClickEdit: true,
        editable: (params) => {
          const deviceId = params.data['DeviceId'];
          if (deviceId) {
            return !this.containerService.isDeviceStarted(
              this.device(deviceId)
            );
          } else {
            return true;
          }
        },
        cellEditor: 'dropdownEditor',
        cellEditorParams: (params) => {
          return {
            getoptions: this.getOptionsArray.bind(this, params.value),
            value: params.value,
          };
        },
        cellRenderer: (params) => {
          return this.getDeviceListTitleWithIcon(this.device(params.value));
        },
        valueSetter: (params: ValueSetterParams) => {
          if (!params.oldValue) {
            params.data.DeviceId = params.newValue;
            return true;
          }

          if (!params.newValue) {
            return false;
          }

          const oldDevice = this.device(params.oldValue);
          const newDevice = this.device(params.newValue);
          if (oldDevice.AospBuild !== newDevice.AospBuild) {
            // Okay, AOSP version is different -->  ask for confirmation
            // Return false in the 1st place, as async confirmation query
            // is not supported by ag grid.
            // If confirmation is ok --> change UI value and trigger user data update
            console.log(
              'User grid -- device change : AOSP is going to be changed'
            );
            this.presentConfirmation(
              'AOSP version is different in target CVD. Userdata will be cleared, when CVD is started. Do you want to continue?'
            ).then((changeOk) => {
              if (changeOk) {
                console.log(
                  'User grid -- changing the device after confirmation'
                );
                params.data.DeviceId = newDevice.Id;
                params.api.refreshCells({
                  rowNodes: [params.node],
                  columns: [params.column],
                });
                this.updateUser(params.data);
              }
            });
            return false;
          } else {
            params.data.DeviceId = newDevice.Id;
            return true;
          }
        },
      },
      {
        headerName: 'CVD status',
        field: 'DeviceId',
        sortable: true,
        editable: false,
        filter: true,
        valueFormatter: (params) => {
          return this.getDeviceStatus(this.device(params.value));
        },
        cellStyle: this.backgroundCellStyle.bind(this),
        minWidth: 150,
        maxWidth: 200,
      },
      {
        headerName: 'CVD',
        headerClass: 'center-label',
        field: 'DeviceId',
        cellStyle: { display: 'flex', justifyContent: 'center' },
        cellRendererSelector: this.selectCellRenderer.bind(this),
        suppressMenu: true,
        minWidth: 100,
        maxWidth: 100,
        resizable: false,
        sortable: false,
        editable: false,
        filter: false,
      },

      {
        headerName: 'Actions',
        headerClass: 'center-label',
        field: 'UID',
        cellStyle: { display: 'flex', justifyContent: 'center' },
        cellRenderer: 'selectCellRenderer',
        cellRendererParams: {
          actions: this.generateUserActions(),
        },
        suppressMenu: true,
        minWidth: 100,
        maxWidth: 100,
        resizable: false,
        sortable: false,
        editable: false,
        filter: false,
      },
    ];
  }

  private getOptionsArray(deviceId: string) {
    return this.deviceListForSelect(deviceId);
  }

  generateActions(): Array<any> {
    const actions = new Array();
    actions.push({
      title: 'Start',
      value: 'start',
      action: (param) => {
        this.startInstance(param);
      },
    });
    actions.push({
      title: 'Stop',
      value: 'stop',
      action: (param) => {
        this.stopInstance(param);
      },
    });
    actions.push({
      title: 'CVD info',
      value: 'info',
      action: (param) => {
        this.showCvdInfo(param);
      },
    });

    actions.push({
      title: 'Unregister',
      value: 'unregister',
      action: (param) => {
        this.unregisterDevice(param);
      },
    });
    return actions;
  }

  generateUserActions(): Array<any> {
    const actions = new Array();

    actions.push({
      title: 'Reset password',
      value: 'resetpwd',
      action: (param) => {
        this.resetPassword(param);
      },
    });

    actions.push({
      title: 'Delete user',
      value: 'delete',
      action: (param) => {
        this.deleteUser(param);
      },
    });

    return actions;
  }

  selectCellRenderer(params): any {
    const selectRenderer = {
      component: 'selectCellRenderer',
      params: {
        actions: this.generateActions(),
      },
    };

    const spinnerRenderer = {
      component: 'spinnerCellRenderer',
    };

    if (params.data.DeviceId) {
      if (this.activeActions[params.data.DeviceId]) {
        return spinnerRenderer;
      } else {
        return selectRenderer;
      }
    }
    return undefined;
  }

  onCellValueChanged($event) {
    console.log('User which was changed', this.user($event.data.UID));
    this.updateUser(this.user($event.data.UID));
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  extractValues(mappings) {
    console.log('Extract values', mappings);
    return Object.keys(mappings);
  }

  getDeviceListTitle(device: DeviceInstance): string {
    if (!device) {
      return null;
    }

    const deviceNum = device.CvdControlPort - 8080 + 1; // Magic formula to make cvd num 1 and up
    const deviceName = device.CvdId || `${device.VmHostName}-cvd-${deviceNum}`; // If CVD ID not found, use another name

    return deviceName;
  }

  getDeviceListTitleWithIcon(device: DeviceInstance): string {
    let opacity = '1.0';
    let deviceName = '';
    if (device) {
      const deviceNum = device.CvdControlPort - 8080 + 1; // Magic formula to make cvd num 1 and up
      deviceName = device.CvdId || `${device.VmHostName}-cvd-${deviceNum}`; // If CVD ID not found, use another name
      if (this.containerService.isDeviceStarted(device)) {
        opacity = '0.4'; // To look like disabled
      }
    }

    const titleHtml = `<span><i style="opacity: ${opacity}"><ion-icon name="create-outline"></ion-icon></i></span>
                       <span style="position: absolute; left: 50px">${deviceName}</span>
                      `;

    return titleHtml;
  }

  getDeviceStatus(device: DeviceInstance): string {
    if (!device) {
      return null;
    }
    if (this.containerService.isDeviceRunning(device)) {
      return `running`;
    } else if (this.containerService.isDeviceBooting(device)) {
      return `booting`;
    } else if (this.containerService.isDeviceError(device)) {
      return `error`;
    } else {
      return `stopped`;
    }
  }

  backgroundCellStyle(params): any {
    const status = this.getDeviceStatus(this.device(params.value));
    if (status === 'running') {
      return { backgroundColor: 'lightgreen' };
    }
    if (status === 'starting') {
      return { backgroundColor: 'lightskyblue' };
    }
    if (status === 'booting') {
      return { backgroundColor: 'lightblue' };
    }
    if (status === 'stopped') {
      return { backgroundColor: 'lightyellow' };
    }
    if (status === 'error') {
      return { backgroundColor: 'lightcoral' };
    }
    return null;
  }

  async showCvdInfo(deviceId: string) {
    console.log('Show CVD info', deviceId);
    console.table(this.device(deviceId));

    const modal = await this.modalController.create({
      component: DevicecardModalPage,
      componentProps: {
        paramID: deviceId,
        paramTitle: this.getDeviceListTitle(this.device(deviceId)),
      },
    });
    return await modal.present();
  }

  changeUserFiltering() {
    this.filteredUsers = this.getShownUsers();
  }

  getShownUsers() {
    if (!(this.users && this.users.length > 0)) {
      return [];
    }

    return this.users
      .filter((user) => {
        if (this.gridFilters.showUsers && user.Role === 'user') {
          return true;
        }
        if (this.gridFilters.showAdmins && user.Role === 'admin') {
          return true;
        }
        if (this.gridFilters.showSupers && user.Role === 'super') {
          return true;
        }
        return false;
      })
      .filter((user) => {
        if (this.gridFilters.showUnregistered && !user.DeviceId) {
          return true;
        }
        if (this.gridFilters.showRegistered && !!user.DeviceId) {
          return true;
        }
      });
  }

  deviceListForSelect(currentDeviceId: string): Array<{}> {
    /* const nullDeviceArray = [
      {
        name: '',
        value: '',
      },
    ]; */

    if (!(this.allDevices && this.allDevices.length > 0)) {
      return [];
    }

    const mapList = this.allDevices
      .filter((device) => {
        return (
          device.Id === currentDeviceId ||
          device.CustomerId === null ||
          device.CustomerId.length < 1
        );
      })
      .filter((device) => {
        return !this.containerService.isDeviceStarted(device);
      })
      .map((device: DeviceInstance) => {
        const rObj = {
          name: this.getDeviceListTitle(device),
          value: device.Id,
        };

        return rObj;
      })
      .sort((a: any, b: any) => {
        return a.name >= b.name ? 1 : -1;
      });

    return mapList;
  }

  device(deviceId: string): DeviceInstance {
    if (!deviceId) {
      return null;
    }
    return this.allDevices.find((device) => device.Id === deviceId);
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
    });
    toast.present();
  }

  async presentConfirmation(question: string): Promise<boolean> {
    const alert = await this.alertController.create({
      header: 'Confirmation',
      message: question,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
        },
        {
          text: 'OK',
          role: 'ok',
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    return role === 'ok';
  }

  async presentAlert(alertMessage: string): Promise<boolean> {
    const alert = await this.alertController.create({
      header: 'Alert',
      message: alertMessage,
      buttons: [
        {
          text: 'OK',
          role: 'ok',
        },
      ],
    });

    await alert.present();
    await alert.onDidDismiss();
    return true;
  }

  clearDefaults() {
    this.newUser = {
      UID: null,
      DisplayName: null,
      Email: null,
      Phone: null,
      Role: null,
      DeviceId: null,
    };
  }

  user(userId: string): UserInfo {
    return this.users.find((user) => user.UID === userId);
  }

  userByEmail(email: string): UserInfo {
    return this.users.find((user) => user.Email === email);
  }

  refreshUsersAndDevices() {
    this.sacaUsersService.fetchUsers(true);
    this.fetchDevices();
    if (this.gridApi) {
      this.gridApi.showLoadingOverlay();
    }
  }

  submitForm(form: any) {
    this.presentConfirmation(
      `Do you want to create new user ${this.newUser.DisplayName}?`
    ).then((answer) => {
      if (answer) {
        this.register(this.newUser.DeviceId);
      }
    });
  }

  deleteUser(userId: string) {
    this.presentConfirmation(
      `Do you want to delete user ${this.user(userId)?.Email}?`
    ).then((answer) => {
      if (answer) {
        this.containerService
          .unRegisterCustomer(userId)
          .subscribe((result: RequestStatus) => {
            if (result.Status) {
              this.sacaUsersService
                .deleteUser(userId)
                .subscribe((deleteResult: RequestStatus) => {
                  console.log('Delete user result', deleteResult);
                  if (deleteResult.Status) {
                    this.presentToast('User deleted');
                    this.refreshUsersAndDevices();
                  }
                });
            } else {
              this.presentToast('Error deleting user - ' + result.Message);
            }
          });
      }
    });
  }

  unregisterDevice(deviceId: string) {
    const device = this.device(deviceId);
    if (!device.CustomerId) {
      return;
    }
    if (this.containerService.isDeviceStarted(device)) {
      this.presentAlert(
        'Device is not stopped, please stop it first to preserve user data'
      );
    } else {
      const userId = device.CustomerId;
      this.presentConfirmation(
        `Do you want to clear user ${
          this.user(userId)?.Email
        } device registration?`
      ).then((answer) => {
        if (answer) {
          this.containerService
            .unRegisterCustomer(userId)
            .subscribe((result: RequestStatus) => {
              if (result.Status) {
                this.presentToast('Device unregistered');
                this.refreshUsersAndDevices();
              } else {
                this.presentToast(
                  'Error unregistering device - ' + result.Message
                );
              }
            });
        }
      });
    }
  }

  updateUser(user: UserInfo) {
    this.sacaUsersService.upsert(user).subscribe((result: RequestStatus) => {
      console.log('Update user result', result);
      if (result.Status) {
        this.presentToast('User information updated');
        this.fetchDevices();
        //this.refreshUsersAndDevices();
      } else {
        this.presentToast(
          'Error updating user information - ' + result.Message
        );
      }
    });
  }

  fetchDevices() {
    this.containerService
      .listDevices()
      .subscribe((response: DeviceInstanceResponse) => {
        if (response.Status) {
          this.allDevices = response.Instances;
          console.log('All devices', this.allDevices);
          this.mappedDevices = this.deviceListForSelect('');

          if (this.gridApi) {
            this.gridApi.refreshClientSideRowModel();
            this.gridApi.refreshCells({ force: true });
          }
        }
      });
  }

  resetPassword(userId: string) {
    this.userService
      .getPasswordResetForUser(userId)
      .subscribe((response: RequestStatus) => {
        if (response.Status) {
          window.open(response.Message, '_blank').focus();
        }
      });
  }

  private register(deviceId: string) {
    this.sacaUsersService.upsert(this.newUser).subscribe(
      (result) => {
        console.log('Update user result', result);
        this.newUser.DeviceId = '';
        if (result.Status) {
          this.presentToast('New user added succesfully');
          this.refreshUsersAndDevices();
          // Show password change
          window.open(result.PasswordReset, '_blank').focus();
        } else {
          this.presentToast('Error adding new user - ' + result.Message);
        }
      },
      (error) => {
        console.log(error);
        this.presentToast('Error adding new user');
      }
    );
  }

  startInstance(deviceId: string) {
    const cvd = this.device(deviceId);
    this.activeActions[deviceId] = true;
    if (this.gridApi) {
      this.gridApi.refreshCells({ force: true });
    }
    this.containerService.startDevice(deviceId).subscribe(
      (result) => {
        this.activeActions[deviceId] = null;
        if (this.gridApi) {
          this.gridApi.refreshCells({ force: true });
        }
        console.log('CVD started, result', result);
        if (result.Status) {
          this.presentToast(`Device ${cvd.CvdId} started`);
        } else {
          this.presentToast(`Device ${cvd.CvdId} start failed`);
        }
      },
      (error) => {
        this.activeActions[deviceId] = null;
        if (this.gridApi) {
          this.gridApi.refreshCells({ force: true });
        }
        console.log('Device start error', error);
        this.presentToast(`Device ${cvd.CvdId} start failed`);
      }
    );
  }

  stopInstance(deviceId: string) {
    const cvd = this.device(deviceId);
    this.activeActions[deviceId] = true;
    if (this.gridApi) {
      this.gridApi.refreshCells({ force: true });
    }
    this.containerService.stopDevice(deviceId).subscribe(
      (result) => {
        this.activeActions[deviceId] = null;
        if (this.gridApi) {
          this.gridApi.refreshCells({ force: true });
        }
        console.log('CVD stopped, result', result);
        if (result.Status) {
          this.presentToast(`Device ${cvd.CvdId} stopped`);
        } else {
          this.presentToast(`Device ${cvd.CvdId} stop failed`);
        }
      },
      (error) => {
        this.activeActions[deviceId] = null;
        if (this.gridApi) {
          this.gridApi.refreshCells({ force: true });
        }
        console.log('Device stop error', error);
        this.presentToast(`Device ${cvd.CvdId} stop failed`);
      }
    );
  }

  showQrCode(userId: string) {
    console.log('Showing QR code for the user');
  }

  lookupValue(mappings: Record<string, string>, key: string) {
    return mappings[key];
  }

  public onModelUpdated() {
    this.gridApi?.sizeColumnsToFit();
    console.log(this.gridApi);
  }

  public sortGrid(param, state) {
    param.columnApi.applyColumnState({
      state,
    });
  }
}
