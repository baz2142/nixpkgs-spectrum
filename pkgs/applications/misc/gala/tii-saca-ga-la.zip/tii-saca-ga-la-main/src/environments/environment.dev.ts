export const environment = {
  production: true,
};

export const BACKEND_UNSECURE = false;
export const SACA_MODE = 'Development';

const DEV_BACKEND = require('./backends.js').DEV_BACKEND;

// Backend definition
export const BACKEND = {
  ADDRESS: DEV_BACKEND.ADDRESS,
  PROTOCOL: DEV_BACKEND.PROTOCOL,
  PORT: DEV_BACKEND.PORT,
};

export const STATUSBACKEND = {
  ADDRESS: 'development-saca-statusservice-asvsrjxw5q-ew.a.run.app',
  WSPROTOCOL: 'wss://',
  PORT: ':443',
};
