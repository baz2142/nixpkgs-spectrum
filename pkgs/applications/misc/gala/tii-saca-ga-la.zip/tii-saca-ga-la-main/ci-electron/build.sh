#!/bin/bash

workplace=$(pwd)
outputpath=$workplace/out

echo "Run NPM install"
npm install 

echo "$(date): Workplace path: $workplace"

export GALA_CI_GIT_HASH=$(git rev-parse --short HEAD)
cordova telemetry off

echo "$(date): Add Electron Platform"
ionic cordova platform add electron --confirm --no-interactive


echo "$(date): Build Electron .deb package"
ionic cordova build electron --configuration=development --release

# Copy artifacts
echo "$(date): Copy artifacts"
mkdir -p $outputpath
cp /workspace/platforms/electron/build/dev.scpp.saca.gala_0.0.1_amd64.deb $outputpath/gala-electron-dev.deb
cp /workspace/platforms/electron/build/dev.scpp.saca.gala_0.0.1_arm64.deb $outputpath/gala-electron-dev-arm64.deb
cp /workspace/platforms/electron/build/dev.scpp.saca.gala-0.0.1.zip $outputpath/gala-electron-dev.zip
cp /workspace/platforms/electron/build/dev.scpp.saca.gala-0.0.1-arm64.zip $outputpath/gala-electron-dev-arm64.zip
