// app/common/btn-cell-renderer.component.ts
import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'spinner-cell-renderer',
  template: `
    <ion-spinner name="crescent"></ion-spinner>
  `,
})
export class SpinnerCellRenderer implements ICellRendererAngularComp {

  agInit(params: any): void {
  }

  refresh(params: ICellRendererParams): boolean {
    return false;
  }
}
