import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Platform } from '@ionic/angular';
import { BehaviorSubject, Observable } from 'rxjs';
import { USERAPI } from '../environments/endpoints';
import { HttpUrlEncodingCodec } from './common/httpparamcodec';
import { BatchAddUsersRequest, BatchDeleteUsersRequest, UserInfo, UserInfoResponse, UserService } from './user.service';

@Injectable({
  providedIn: 'root',
})
export class SacaUsersService {
  public sacaUsers$: BehaviorSubject<any> = new BehaviorSubject(null);
  public sacaUnassignedUsers$: BehaviorSubject<any> = new BehaviorSubject(null);

  private usersFetched = false;
  private fetchOngoing = false;

  constructor(private httpClient: HttpClient, private platform: Platform, private userService: UserService) {
    console.log('Sacausers service constructor');
  }

  public isDesktop(): boolean {
    return !this.platform.is('hybrid');
  }

  public upsert(userData: UserInfo) {
    return this.createPostRequest(USERAPI.UPSERT, userData);
  }

  public getUser(userId: string) {
    return this.createRequest(USERAPI.GET, userId, 'userid');
  }

  public deleteUser(userId: string) {
    return this.createRequest(USERAPI.DELETE, userId, 'userid');
  }

  /**
   * Used to mass add or mass delete users
   * @param addUsers true if adding, false if deleting
   * @param usersData
   */
  public batchControlUsers(addUsers: boolean, usersData: BatchAddUsersRequest | BatchDeleteUsersRequest): Promise<any> {
    return new Promise((resolve, reject) => {
      this.createBatchRequest(!!addUsers ? USERAPI.BATCHADD : USERAPI.BATCHDELETE, usersData).subscribe((result) => {
        if (!!result.Status) {
          resolve(result);
        } else {
          reject(result.Message);
        }
      });
    });
  }

  public fetchUsers(forceUpdate: boolean) {
    console.log('SacaUserService: fetchUsers');
    if (this.fetchOngoing) {
      console.log('SacaUserService: fetchUsers - fetchOngoing');
      return;
    }
    if (forceUpdate || !this.usersFetched) {
      this.fetchOngoing = true;
      console.log('SacaUserService: fetching...');
      this.createRequest(USERAPI.LIST, null).subscribe(
        (result: UserInfoResponse) => {
          this.fetchOngoing = false;
          console.log('SacaUserService: fetchUsers - fetched', result);
          if (result && result.Status) {
            this.usersFetched = true;
            this.sacaUsers$.next(result.Users);

            const unassigned = result.Users.filter((user) => user.DeviceId !== null);
            this.sacaUnassignedUsers$.next(unassigned);
          }
        },
        (error) => {
          this.fetchOngoing = false;
          console.log('SacaUserService: fetchUsers fail', error);
        }
      );
    }
  }

  private createRequest(endpoint: string, queryParam: string, paramName?: string): Observable<any> {
    let url = this.userService.resolveEndpoint(endpoint);

    // Append deviceid param if given
    let queryParamName = 'deviceid';
    if (paramName) {
      queryParamName = paramName;
    }
    if (queryParam) {
      url = url + '?' + queryParamName + '=' + queryParam;
    }

    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'json',
    });
  }

  private createPostRequest(endpoint: string, userData: UserInfo): Observable<any> {
    let url = this.userService.resolveEndpoint(endpoint);

    const payload = new HttpParams({ encoder: new HttpUrlEncodingCodec() })
      .set('UID', userData.UID)
      .set('DisplayName', userData.DisplayName)
      .set('Email', userData.Email)
      .set('Phone', userData.Phone)
      .set('Role', userData.Role)
      .set('DeviceId', userData.DeviceId);

    return this.httpClient.post(url, payload, {
      headers: this.getHeaders('application/x-www-form-urlencoded'),
      responseType: 'json',
    });
  }

  private createBatchRequest(
    endpoint: string,
    userData: BatchAddUsersRequest | BatchDeleteUsersRequest
  ): Observable<any> {
    const url = this.userService.resolveEndpoint(endpoint);
    const payload = userData;

    return this.httpClient.post(url, payload, {
      headers: this.getHeaders('application/x-www-form-urlencoded'),
      responseType: 'json',
    });
  }

  private getHeaders(contentType?: string): HttpHeaders {
    let headers = new HttpHeaders();
    if (contentType) {
      headers = headers.set('Content-Type', contentType);
    }
    return headers;
  }
}
