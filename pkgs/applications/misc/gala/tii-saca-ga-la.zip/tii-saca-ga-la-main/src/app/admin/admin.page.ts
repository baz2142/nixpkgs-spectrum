import { Component, OnInit } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { filter } from 'rxjs/operators';
import { FooterService } from '../footer.service';
import { CloudRevision, UserService } from '../user.service';
import { ContainerService } from '../container.service';

export const AdminRoutes = {
  instancegroups: 'instancegroups',
  instancetemplates: 'instancetemplates',
  devicegrid: 'devicegrid',
  mappings: 'mappings',
  galabuilds: 'galabuilds',
  users: 'users',
  configuration: 'configuration',
};

@Component({
  selector: 'app-admin',
  templateUrl: 'admin.page.html',
  styleUrls: ['admin.page.scss'],
})
export class AdminPage implements OnInit {
  public selectedRoute: string;
  public narrowMenu: boolean = false;
  public adminRoutes = AdminRoutes;

  constructor(
    private footerService: FooterService,
    private platform: Platform,
    private router: Router,
    private userService: UserService,
    private containerService: ContainerService
  ) {
    this.selectedRoute = this.router.url.split('/').pop();

    this.router.events
      .pipe(filter((event) => event instanceof NavigationStart))
      .subscribe((navigation: NavigationStart) => {
        this.selectedRoute = navigation.url.split('/').pop();
      });
  }

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      if (authenticated) {
        const adminEnv = this.parseAdminEnvironment() || 'localhost';
        this.userService.getEnvironmentVersions(adminEnv);
      }

      this.containerService.setupWebsocketListener();
    });
  }

  ionViewDidEnter() {
    this.footerService.showFooter();
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  get adminRevision(): CloudRevision {
    return this.userService.adminRevision;
  }

  get backendRevision(): CloudRevision {
    return this.userService.backendRevision;
  }

  public toggleMenu() {
    this.narrowMenu = !this.narrowMenu;
  }

  formatDate(date: string): string {
    if (date === '' || date === null) {
      return '';
    }
    const parsed = new Date(Date.parse(date));
    return `${parsed.toISOString().substring(0, 10)} ${parsed
      .toISOString()
      .substring(11, 19)}`;
  }

  parseAdminEnvironment(): string {
    const host = window.location.hostname;
    const hostPart = 'saca-admin';

    const start = host.indexOf(hostPart);
    if (start < 0) {
      return null;
    } else {
      return host.substr(0, start + hostPart.length);
    }
  }
}
