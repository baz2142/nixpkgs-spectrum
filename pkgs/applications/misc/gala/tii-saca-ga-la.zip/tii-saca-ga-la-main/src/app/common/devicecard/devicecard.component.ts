import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Platform, PopoverController, ToastController } from '@ionic/angular';
import { ContainerService, DeviceInfo, RequestStatus, StartParams } from '../../container.service';
import { DeviceService } from '../../device.service';
import { SacaUsersService } from '../../sacausers.service';
import { UserInfo, UserResponse, UserService } from '../../user.service';

enum ActionOngoing {
  None = '',
  Deleting = 'Deleting',
  Preparing = 'Preparing',
  Starting = 'Starting',
  Stopping = 'Stopping',
  Logs = 'Logs',
  Upload = 'Upload',
  Connecting = 'Connecting',
  Disconnecting = 'Disconnecting',
}

type LocalDeviceInfo = {
  DeviceId: string;
  DeviceInfo: DeviceInfo;
  ActionOngoing: ActionOngoing;
};

@Component({
  selector: 'app-devicecard',
  templateUrl: 'devicecard.component.html',
  styleUrls: ['devicecard.component.scss'],
  providers: [DeviceService],
})
export class DevicecardComponent implements OnInit, OnDestroy {
  public videoSource: MediaStream;
  public audioSource: MediaStream;
  public localDeviceInfo: LocalDeviceInfo = {} as LocalDeviceInfo;
  public customerId: string;
  private backupCustomerId: string;
  private customer: UserInfo;
  public usersForSelect: UserInfo[] = [];
  public startParamsVisible = false;
  public startParams: StartParams = {} as StartParams;
  public cuttleScreenVisible = false;
  public ActionOngoing: typeof ActionOngoing = ActionOngoing;

  public deviceStatusText: string = '';

  @Input() deviceId: string;

  @ViewChild('deviceScreen') deviceScreen: ElementRef;

  constructor(
    private userService: UserService,
    private sacaUsersService: SacaUsersService,
    private platform: Platform,
    private toastController: ToastController,
    protected containerService: ContainerService,
    private deviceService: DeviceService,
    protected popoverController: PopoverController
  ) {
    this.localDeviceInfo.DeviceInfo = {} as DeviceInfo;
    this.localDeviceInfo.DeviceId = this.deviceId;
    this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
  }

  ngOnInit(fetchUsers: boolean = true) {
    this.getDeviceInfo(this.deviceId);
    this.videoSource = null;
    this.audioSource = null;

    if (fetchUsers) {
      this.fetchUsers();
    }

    this.sacaUsersService.sacaUsers$.subscribe((data) => {
      if (data) {
        this.usersForSelect = data;
      }
    });
  }

  ngOnDestroy() {
    if (this.isConnected) {
      this.disconnect();
    }
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  getTitle(): string {
    if (this.localDeviceInfo.DeviceInfo && this.localDeviceInfo.DeviceInfo.Instance) {
      return (
        this.localDeviceInfo.DeviceInfo.Instance.VmHostName +
        ':' +
        this.localDeviceInfo.DeviceInfo.Instance.CvdControlPort
      );
    }
  }

  getDnsAddress(): string {
    if (this.cuttleStatus && this.cuttleStatus.dns_address) {
      return this.cuttleStatus.dns_address;
    } else {
      return '';
    }
  }

  public get usersForSelectAscending(): UserInfo[] {
    if (!this.usersForSelect.length) {
      return [];
    }
    return this.usersForSelect
      .filter((user) => user.DeviceId === '')
      .sort((a: UserInfo, b: UserInfo) => {
        return (a.DisplayName || a.Email) >= (b.DisplayName || b.Email) ? 1 : -1;
      });
  }


  public get isConnected(): boolean {
    return this.cuttleScreenVisible;
  }

  public get isConnecting(): boolean {
    return this.deviceService.isConnecting();
  }

  public get cuttleStatus() {
    return this.containerService.getCuttleStatus(this.deviceId);
  }

  public get cuttleStatusText() {
    if (this.localDeviceInfo && this.localDeviceInfo.DeviceInfo && this.localDeviceInfo.DeviceInfo.Instance) {
      return this.containerService.resolveDeviceStatus(this.localDeviceInfo.DeviceInfo.Instance);
    } else {
      return '';
    }
  }

  isPrepareActive(): boolean {
    return this.cuttleStatus && this.cuttleStatus.images === 'present' && this.cuttleStatus.binaries === 'missing';
  }

  isStartActive(): boolean {
    return (
      this.cuttleStatus &&
      this.cuttleStatus.images === 'present' &&
      this.cuttleStatus.binaries === 'present' &&
      this.cuttleStatus.cuttlefish === 'stopped'
    );
  }

  isStopActive(): boolean {
    return (
      this.cuttleStatus &&
      this.cuttleStatus.images === 'present' &&
      this.cuttleStatus.binaries === 'present' &&
      this.cuttleStatus.cuttlefish === 'running'
    );
  }

  isCvdRunning(): boolean {
    if (this.cuttleStatus && this.cuttleStatus.cuttlefish === 'running') {
      return true;
    }
    return false;
  }

  getCustomerName(): string {
    if (this.customer) {
      return this.customer.DisplayName || this.customer.Email;
    } else {
      return this.customerId;
    }
  }

  getCuttleEndpoint(): string {
    return this.cuttleStatus?.dns_address;
  }

  getCuttleDnsEndpoint(): string {
    return this.cuttleStatus?.dns_address;
  }

  getCuttleEndpointWithIdAndToken(): string {
    let endpoint = this.getCuttleEndpoint() + '?token=' + this.userService.getToken();
    if (this.cuttleStatus?.device_id) {
      endpoint += '&cvdid=' + this.cuttleStatus.device_id;
    }
    return endpoint;
  }

  getCuttleDnsEndpointWithIdAndToken(): string {
    let endpoint = this.getCuttleDnsEndpoint() + '?token=' + this.userService.getToken();
    if (this.cuttleStatus?.device_id) {
      endpoint += '&cvdid=' + this.cuttleStatus.device_id;
    }
    return endpoint;
  }

  getDeviceInfo(deviceId: string) {
    this.containerService.deviceInfo(deviceId).subscribe((result: DeviceInfo) => {
      this.localDeviceInfo.DeviceInfo = result;
      if (this.localDeviceInfo.DeviceInfo.Instance.CustomerId) {
        this.customerId = this.localDeviceInfo.DeviceInfo.Instance.CustomerId;
        this.sacaUsersService.getUser(this.customerId).subscribe((response: UserResponse) => {
          console.log('Got response', response);
          if (response.Status) {
            console.log('Got customer', response.User);
            this.customer = response.User;
          }
        });
      }
      // Trigger status fetching if not already arrived
      // console.log("status exists", this.containerService.isCuttleStatusExisting(deviceId));
      if (!this.containerService.isCuttleStatusExisting(deviceId)) {
        this.getCvdStatus(deviceId);
      }
    });
  }

  public getCvdStatus(deviceId: string, force: string = 'false') {
    console.log('Device card -- getCvdStatus');
    this.containerService.deviceStatus(deviceId, force);
  }

  // TODO: Fetch these only once and somewhere centrally
  fetchUsers(force: boolean = false) {
    this.usersForSelect = [];
    this.sacaUsersService.fetchUsers(force);
  }

  getLogs(deviceId: string) {
    console.log('get logs');
    this.localDeviceInfo.ActionOngoing = ActionOngoing.Logs;
    this.containerService.getLogs(deviceId).subscribe(
      (data: any) => {
        console.log('Logs status', data);
        this.downloadFile(this.getTitle(), data);
        this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
      },
      (error) => {
        console.log('Device card -- log fetch error', error);
        this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
        this.presentToast(this.getTitle(), 'Logs error: ' + error.message);
      }
    );
  }

  startDevice(deviceId: string) {
    this.localDeviceInfo.ActionOngoing = ActionOngoing.Starting;
    this.containerService.startDevice(deviceId, this.startParams).subscribe(
      (result: RequestStatus) => {
        console.log('Start device result', result);
        if (result.Status) {
          this.presentToast(this.getTitle(), 'Device started');
          this.getDeviceInfo(deviceId);
          this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
        } else {
          this.presentToast(this.getTitle(), 'Device start error: ' + result.Message);
          this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
        }
      },
      (error) => {
        console.log('Device card -- start device error', error);
        this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
        this.presentToast(this.getTitle(), 'Device start error: ' + error.message);
      }
    );
  }

  stopDevice(deviceName: string) {
    this.localDeviceInfo.ActionOngoing = ActionOngoing.Stopping;
    this.containerService.stopDevice(deviceName).subscribe(
      (result: RequestStatus) => {
        console.log('Stop device result', result);
        if (result.Status) {
          this.presentToast(this.getTitle(), 'Device stopped');
          this.getDeviceInfo(deviceName);
          this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
        } else {
          this.presentToast(this.getTitle(), 'Device stop error: ' + result.Message);
          this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
        }
      },
      (error) => {
        console.log('Device card -- stop device error', error);
        this.localDeviceInfo.ActionOngoing = ActionOngoing.None;
        this.presentToast(this.getTitle(), 'Device stop error: ' + error.message);
      }
    );
  }

  connect(cvdId?: string) {
    if (this.isConnected /*|| this.deviceService.isConnected() || this.deviceService.isConnecting()*/) {
      // console.log("No connection will be made", cvdId, this.isConnected, this.deviceService.isConnecting(), this.deviceService.isConnected());
      return;
    }

    console.log('CONNECT TO ' + cvdId);
    if (cvdId && cvdId.length > 0) {
      this.presentToast(cvdId, 'Connecting...');
      this.connectToDevice(cvdId);
    } else {
      // The "old way" --> needs to be removed
      this.deviceService.fetchCvdId(this.getWssEndPointWithDNS()).subscribe(
        (deviceIds) => {
          console.log('Data from WS server', deviceIds);
          const cvdIds = deviceIds.concat(deviceIds as string[]);
          if (cvdIds && cvdIds.length > 0) {
            this.connectToDevice(cvdIds[0]);
          } else {
            // this.actionOngoing = ActionOngoing.None;
            this.presentToast(this.getTitle(), 'No device found from the running container!');
          }
        },
        (error) => {
          console.log('Connection error', error);
          this.presentToast(this.getTitle(), 'Connection attempt failed: ' + error);
        }
      );
    }
  }

  public connectToDevice(cvdId: string) {
    if (!cvdId) {
      cvdId = 'cvd-1';
    }

    console.log('Device card -- connecting to device', cvdId);
    this.deviceService
      .connectToDevice(
        cvdId,
        (videoStream) => {
          console.log(videoStream);
          this.videoSource = this.deviceService.videoStream;
          this.cuttleScreenVisible = true;
          console.log('Connected to CVD');
        },
        this.getWssEndPointWithDNS()
      )
      .catch((error) => {
        this.presentToast(this.getTitle(), 'WebRTC Connection failed: ' + error);
      });
  }

  disconnect() {
    this.cuttleScreenVisible = false;
    this.deviceService.disconnectFromDevice();
  }

  getWssEndPointWithDNS(): string {
    const httpEndpoint = this.getCuttleDnsEndpoint();

    const delim = httpEndpoint.indexOf(':');
    if (delim > 0) {
      const endUrl = httpEndpoint.substr(delim);
      return 'wss' + endUrl;
    } else {
      return this.getWssEndpoint();
    }
  }

  getWssEndpoint(): string {
    // Temporary fix to connect to correct WSS port with authentication
    const address = this.localDeviceInfo.DeviceInfo.CuttleWssAddress;

    if (address && address.length > 4) {
      const len = address.length;
      let port = Number.parseInt(address.substring(len - 4), 10);

      if (port > 8400) {
        port = port - 100;
      }
      const newAddress = address.substr(0, len - 4) + port;
      return newAddress;
    } else {
      return this.localDeviceInfo.DeviceInfo.CuttleWssAddress;
    }
  }

  isEmulatorRunning(deviceId: string): boolean {
    return this.cuttleStatus?.emulator === 'running';
  }

  isCuttlefishRunning(deviceId: string): boolean {
    return this.cuttleStatus?.cuttlefish === 'running';
  }

  isActionOngoing(deviceId: string): boolean {
    return this.localDeviceInfo.ActionOngoing !== ActionOngoing.None;
  }

  isThisActionOngoing(deviceId: string, action: ActionOngoing) {
    return this.localDeviceInfo.ActionOngoing === action;
  }

  createEmptyDeviceInfo(deviceId: string, action: ActionOngoing) {
    return {
      DeviceId: deviceId,
      DeviceInfo: {} as DeviceInfo,
      ActionOngoing: action,
    } as LocalDeviceInfo;
  }

  async presentToast(deviceName: string, message: string) {
    const toast = await this.toastController.create({
      message: deviceName + ': ' + message,
      duration: 3000,
    });
    toast.present();
  }

  downloadFile(deviceName: string, data: BlobPart) {
    const blob = new Blob([data], { type: 'application/zip' });

    const downloadURL = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = downloadURL;
    link.download = deviceName + '_logs.zip';
    link.click();
  }

  get getHwWidth(): string {
    if (this.deviceService.currentDisplay) {
      return this.deviceService.currentDisplay.x_res;
    } else {
      return '';
    }
  }

  get getHwHeight(): string {
    if (this.deviceService.currentDisplay) {
      return this.deviceService.currentDisplay.y_res;
    } else {
      return '';
    }
  }

  get getHwCpu(): string {
    if (this.deviceService.currentHardware) {
      return this.deviceService.currentHardware.CPUs;
    } else {
      return '';
    }
  }

  get getHwMemory(): string {
    if (this.deviceService.currentHardware) {
      return this.deviceService.currentHardware.RAM;
    } else {
      return '';
    }
  }

  get getGPUMode(): string {
    if (this.deviceService.currentHardware) {
      return this.deviceService.currentHardware['GPU Mode'];
    } else {
      return '';
    }
  }

  get getDeviceVersionStr(): string {
    if (this.deviceService.deviceVersionStr) {
      return this.deviceService.deviceVersionStr;
    } else {
      return '';
    }
  }
}
