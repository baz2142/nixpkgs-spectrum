import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { DeviceService } from '../../device.service';
import { CvdPopoverComponent } from '../popover/cvdpopover.component';
import { DevicecardComponent } from './devicecard.component';

@Component({
  selector: 'app-devicecardlist',
  templateUrl: 'devicecardlist.component.html',
  providers: [DeviceService],
})
export class DevicecardListComponent extends DevicecardComponent implements OnInit, OnDestroy {
  @Input() isSelected: boolean;
  @Input() connectDevice: Subject<boolean>;

  ngOnInit() {
    super.ngOnInit(false);

    this.connectDevice.subscribe((val) => {
      if (val && this.isSelected) {
        super.connect(this.cuttleStatus.device_id);
      }

      if (!val && this.isSelected) {
        super.disconnect();
      }
    });
  }

  ngOnDestroy() {
    this.isSelected = false;
    super.ngOnDestroy();
  }

  showPopover() {
    this.popoverController
      .create({
        component: CvdPopoverComponent,
        componentProps: {
          video: this.videoSource,
        },
        showBackdrop: false,
      })
      .then((popoverElement) => {
        popoverElement.present();
      });
  }
}
