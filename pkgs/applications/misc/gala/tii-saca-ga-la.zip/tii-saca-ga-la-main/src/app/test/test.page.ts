import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { Platform, ToastController } from '@ionic/angular';
import { DeviceService } from '../device.service';
import { FooterService } from '../footer.service';

@Component({
  selector: 'app-test',
  templateUrl: 'test.page.html',
  styleUrls: ['test.page.scss'],
})
export class TestPage {
  public cvdIds: string[];
  public protocol: string = 'https';
  public port: string = '8443';

  @Output() toggleTabsNotification: EventEmitter<any> = new EventEmitter();

  constructor(
    private deviceService: DeviceService,
    private footerService: FooterService,
    private androidPermissions: AndroidPermissions,
    private router: Router,
    private platform: Platform,
    private toastController: ToastController
  ) {}

  ionViewDidEnter() {
    console.log('ionViewDidEnter');
    this.footerService.showFooter();
    // this.listDevices();
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
    });
    toast.present();
  }

  connect(cvdId: string) {
    this.connectToDevice(cvdId);
  }

  generateEndPoint(): string {
    return this.protocol + '://' + this.hostAddress + ':' + this.port;
  }

  generateWebsocketEndPoint(): string {
    return 'wss://' + this.hostAddress + ':' + this.port;
  }

  listDevices() {
    this.cvdIds = [];
    this.deviceService.fetchCvdId(this.generateEndPoint()).subscribe((deviceIds) => {
      console.log('Data from WS server', deviceIds);
      this.cvdIds = this.cvdIds.concat(deviceIds as string[]);
    });
  }

  addPermissions() {
    this.checkAndAskPermission(this.androidPermissions.PERMISSION.RECORD_AUDIO);
    this.checkAndAskPermission(this.androidPermissions.PERMISSION.MODIFY_AUDIO_SETTINGS);
    this.checkAndAskPermission(this.androidPermissions.PERMISSION.CAMERA);
  }

  checkAndAskPermission(permissionName: string) {
    this.androidPermissions.checkPermission(permissionName).then(
      (result) => {
        console.log('Has permission', permissionName, '?', result.hasPermission);
        if (!result.hasPermission) {
          this.androidPermissions.requestPermission(permissionName);
        }
      },
      (err) => this.androidPermissions.requestPermission(permissionName)
    );
  }

  toggleFooter() {
    this.footerService.toggleFooter();
  }

  public connectToDevice(deviceId: string) {
    if (!deviceId) {
      deviceId = 'cvd-1';
    }
    this.deviceService
      .connectToDevice(
        deviceId,
        (videoStream) => {
          console.log(videoStream);
          // Change tab automatically when device is connected.
          // Small timeout here..
          this.router.navigateByUrl('/tabs/cuttle');
        },
        this.generateWebsocketEndPoint(),
        false // don't use ticket
      )
      .catch((error) => {
        console.log('Connection failed with error', error);
      });
  }

  public disconnectFromDevice() {
    this.deviceService.disconnectFromDevice();
  }

  get localWidth(): string {
    return window.innerWidth.toString();
  }

  get localHeight(): string {
    return window.innerHeight.toString();
  }

  get getHwWidth(): string {
    if (this.deviceService.currentDisplay) {
      return this.deviceService.currentDisplay.x_res;
    } else {
      return '';
    }
  }

  get getHwHeight(): string {
    if (this.deviceService.currentDisplay) {
      return this.deviceService.currentDisplay.y_res;
    } else {
      return '';
    }
  }

  get getHwCpu(): string {
    if (this.deviceService.currentHardware) {
      return this.deviceService.currentHardware.CPUs;
    } else {
      return '';
    }
  }

  get getHwMemory(): string {
    if (this.deviceService.currentHardware) {
      return this.deviceService.currentHardware.RAM;
    } else {
      return '';
    }
  }

  get getDeviceVersionStr(): string {
    if (this.deviceService.deviceVersionStr) {
      return this.deviceService.deviceVersionStr;
    } else {
      return '';
    }
  }

  get hostAddress(): string {
    return this.deviceService.hostAddress;
  }

  set hostAddress(address: string) {
    this.deviceService.hostAddress = address;
  }
}
