export const environment = {
  production: true,
};

export const BACKEND_UNSECURE = false;
export const SACA_MODE = 'Demo';

const DEMO_BACKEND = require('./backends.js').DEMO_BACKEND;

// Backend definition
export const BACKEND = {
  ADDRESS: DEMO_BACKEND.ADDRESS,
  PROTOCOL: DEMO_BACKEND.PROTOCOL,
  WSPROTOCOL: DEMO_BACKEND.WSPROTOCOL,
  PORT: DEMO_BACKEND.PORT,
};
export const STATUSBACKEND = {
  ADDRESS: 'saca-statusservice-ynpjkh6lua-ew.a.run.app',
  WSPROTOCOL: 'wss://',
  PORT: ':443',
};
