const BACKEND = require('./backends.js').DEV_BACKEND;
const DEV_PROXY_CONFIG = require('./proxy.conf.js');

DEV_PROXY_CONFIG['/saca-api/*'].target = BACKEND.PROTOCOL + BACKEND.ADDRESS + BACKEND.PORT;

module.exports = DEV_PROXY_CONFIG;
