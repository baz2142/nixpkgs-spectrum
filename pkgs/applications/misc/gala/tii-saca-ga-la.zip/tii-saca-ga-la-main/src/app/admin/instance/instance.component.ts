import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Platform } from '@ionic/angular';
import {
  ContainerService,
  DeviceInstance,
  DeviceInstanceResponse,
} from '../../container.service';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-instance',
  templateUrl: 'instance.component.html',
  styleUrls: ['instance.component.scss'],
})
export class InstanceComponent implements OnInit {
  public selectedInstance: string;
  private containers: DeviceInstance[];

  constructor(
    private platform: Platform,
    private containerService: ContainerService,
    private userService: UserService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);
      if (authenticated) {
        this.route.queryParams.subscribe((params) => {
          this.selectedInstance =
            this.route.snapshot.paramMap.get('instanceid');
          this.listHostDevices();
        });
      }
    });
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  listHostDevices() {
    this.containerService
      .listDevicesByVmHost(this.selectedInstance)
      .subscribe((result: DeviceInstanceResponse) => {
        console.log('List group instances result', result);
        if (result.Status) {
          this.containers = result.Instances;
        }
      });
  }

  get sortedContainers(): DeviceInstance[] {
    if (!this.containers) {
      return [];
    }
    return this.containers.sort((a, b) => {
      return a.CvdControlPort >= b.CvdControlPort ? 1 : -1;
    });
  }
}
