// app/common/btn-cell-renderer.component.ts
import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'select-cell-renderer',
  template: `
    <div class="custom-select-wrapper">
      <ion-select
        class="renderer-select dots"
        interface="popover"
        (ionChange)="doAction($event, actionSelect.value)"
        #actionSelect
      >
        <ion-select-option
          *ngFor="let action of params.actions"
          [value]="action.value"
          >{{ action.title }}</ion-select-option
        >
      </ion-select>
      <ion-icon name="ellipsis-vertical"></ion-icon>
    </div>
  `,
  styles: [
    '.custom-select-wrapper { display: flex; justify-content: center; align-items: center; }',
    '.custom-select-wrapper:hover ion-icon, .custom-select-wrapper:active ion-icon, .custom-select-wrapper:focus ion-icon { color: black; }',
    'ion-select { width: 40px; }',
    'ion-select::part(icon) { display: none; }',
    'ion-icon { position: absolute; font-size: 18px; color: rgba(0,0,0,0.39) }',
  ],
})
export class SelectCellRenderer implements ICellRendererAngularComp {
  public params: any;

  agInit(params: any): void {
    this.params = params;
  }

  btnClickedHandler() {
    this.params.clicked(this.params.value);
  }

  refresh(params: ICellRendererParams): boolean {
    return false;
  }

  doAction($event: Event, actionName: string) {
    if (actionName) {
      console.log('DO ACTION: ' + actionName);
      const actions = this.params.actions as Array<any>;
      const actionFunc = actions
        .filter((action) => action.value === actionName)
        .pop();
      actionFunc.action(this.params.value);
    }
  }
}
