import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { LoginModule } from '../common/login/login.module';
import { SharedModule } from '../shared/shared.module';
import { ChangePasswordContainerComponent } from './change-password-container/change-password-container.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ToggleFingerprintLoginComponent } from './toggle-fingerprint-login/toggle-fingerprint-login.component';
import { ToggleScreenshotComponent } from './toggle-screenshot/toggle-screenshot.component';
import { UserPageRoutingModule } from './user-routing.module';
import { UserPage } from './user.page';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    UserPageRoutingModule,
    ReactiveFormsModule,
    LoginModule,
    SharedModule,
  ],
  declarations: [
    UserPage,
    ChangePasswordComponent,
    ToggleFingerprintLoginComponent,
    ChangePasswordContainerComponent,
    ToggleScreenshotComponent,
  ],
})
export class UserPageModule {}
