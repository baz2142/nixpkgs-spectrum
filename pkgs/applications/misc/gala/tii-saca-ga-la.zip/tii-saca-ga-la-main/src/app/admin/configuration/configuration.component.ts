import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {
  ContainerService,
  RequestStatus,
  SacaConfig,
} from '../../container.service';
import { UserService } from '../../user.service';
import { AlertController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-configuration',
  templateUrl: 'configuration.component.html',
  styleUrls: ['configuration.component.scss'],
})
export class ConfigurationComponent implements OnInit {
  public configs: SacaConfig[] = [];
  
  // TODO: Remove log-level configuration if deciced to be removed.
  //public logLevel: string = null;


  @Output() toggleTabsNotification: EventEmitter<any> = new EventEmitter();

  constructor(
    private containerService: ContainerService,
    private userService: UserService,
    private alertController: AlertController,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      this.getConfigs();
      //this.getLogLevel();
    });
  }

  sortConfigs(configs: SacaConfig[]): SacaConfig[] {
    return configs.sort((a,b) => {
      return a.ConfigName <= b.ConfigName ? -1 : 1;
    })
  }

  getConfigs() {
    this.containerService.getConfigs().subscribe((result: SacaConfig[]) => {
      console.log('Get config result', result);
      if (result) {
        this.configs = this.sortConfigs(result);
      }
    });
  }

  /*
  logLevelChanged(event: any) {
    console.log('logLevelChanged', event);
    this.containerService
      .setLogLevel(event.detail.value)
      .subscribe((result) => {
        console.log('Logging level updated', result);
      });
  }

  getLogLevel() {
    this.containerService.getLogLevel().subscribe((result: any) => {
      console.log('Get log level result', result);
      this.logLevel = result;
    });
  }

  setLogLevel() {
    this.containerService
      .setLogLevel(this.logLevel)
      .subscribe((result: any) => {
        console.log('Set log level result', result);
      });
  } */

  addConfig() {
    const newConfig = {} as SacaConfig;
    this.configs.unshift(newConfig)
  }

  submitConfigForm(config: SacaConfig) {
    this.containerService.postConfig(config).subscribe((result: SacaConfig) => {
      console.log('Post config result', result);
      if (result.Id) {
        this.getConfigs();
      }
    });
  }

  deleteConfig(configId: string, configName: string) {
    this.presentConfirmation(
      `Do you want to delete the config ${configName}?`
    ).then((answer) => {
      if (answer) {
        this.containerService
          .deleteConfig(configId)
          .subscribe((result: RequestStatus) => {
            console.log('Delete config result', result);
            if (result.Status) {
              this.getConfigs();
            }
          });
      }
    });
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
    });
    toast.present();
  }

  async presentConfirmation(question: string): Promise<boolean> {
    const alert = await this.alertController.create({
      header: 'Confirmation',
      message: question,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
        },
        {
          text: 'OK',
          role: 'ok',
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    return role === 'ok';
  }
}
