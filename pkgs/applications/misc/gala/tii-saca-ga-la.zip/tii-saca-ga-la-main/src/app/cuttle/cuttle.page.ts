import { Component, ElementRef, ViewChild } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import {
  IonFab,
  NavController,
  Platform,
  ToastController,
  AlertController,
} from '@ionic/angular';
import { DeviceService } from '../device.service';
import { FooterService } from '../footer.service';
import { UserService } from '../user.service';
import { ContainerService, CuttleStatusJson } from '../container.service';
import { Ocr } from '../ocr';
import { Subscription } from 'rxjs';

enum ReconnectState {
  None = 1,
  WaitingForDevice = 2,
  WaitingForBoot = 3,
  Reconnecting = 4,
}

@Component({
  selector: 'app-cuttle',
  templateUrl: 'cuttle.page.html',
  styleUrls: ['cuttle.page.scss'],
})
export class CuttlePage {
  @ViewChild('deviceScreen') deviceScreen: ElementRef;
  @ViewChild('menuRef') deviceMenu: IonFab;

  public videoSource: MediaStream;
  public audioSource: MediaStream;
  private mouseIsDown = false;
  private screenHasBeenResized = false;
  private lastTouch: Touch;
  private touchIdSlotMap = new Map();
  private touchSlots = new Array();
  private ocr: Ocr;
  private enableTestMenu = false;
  private inputCache: string = '';
  private alertModal: HTMLIonAlertElement;
  private reconnectInterval: NodeJS.Timeout;
  private reconnectState: ReconnectState;
  private connectionSub: Subscription;
  private connectionStateSub: Subscription;
  private reconnectTimeoutHandle: any;

  get canShowTestMenu(): boolean {
    return this.enableTestMenu;
  }

  get enableOcr(): boolean {
    return !!this.ocr;
  }

  set enableOcr(enable: boolean) {
    if (enable && !this.ocr) {
      this.ocr = new Ocr();
      this.ocr.initialize();
    } else if (!enable && this.ocr) {
      this.ocr.deinitialize();
      this.ocr = null;
    }
  }

  constructor(
    private deviceService: DeviceService,
    private footerService: FooterService,
    private navController: NavController,
    private platform: Platform,
    private toastController: ToastController,
    private statusBar: StatusBar,
    private splashScreen: SplashScreen,
    private alertController: AlertController,
    private userService: UserService,
    private containerService: ContainerService
  ) {}

  ngOnInit() {
    this.connectionSub =
      this.deviceService.whenConnected.subscribe((connected) => {
        if (connected) {
          setTimeout(() => {
            console.log('Connected - set media sources');
            this.videoSource = this.deviceService.videoStream;
            this.audioSource = this.deviceService.audioStream;

            this.deviceService.deviceConnection.sendControlMessage(
              JSON.stringify({
                command: 'request_frames',
              })
            );
          }, 1);
        }
      });
    this.connectionStateSub =
      this.deviceService.connectionState$.subscribe((state) => {
        console.log('Connection state change: ' + state);
        if (state === 'disconnected') {
          clearTimeout(this.reconnectTimeoutHandle);
          this.reconnectTimeoutHandle = setTimeout(() => {
            this.startReconnectProcess();
          }, 2000);
        } else if (state === 'connected') {
          clearTimeout(this.reconnectTimeoutHandle);
        }
      });
  }

  ngOnDestroy() {
    this.connectionSub.unsubscribe();
    this.connectionStateSub.unsubscribe();
  }

  ionViewWillEnter() {}

  ionViewDidEnter() {
    console.log('ionViewDidEnter');

    this.registerSecretCodeHandler('TEST', () => {
      console.log('Test menu enabled');
      this.enableTestMenu = true;
    });

    this.startMouseTracking();
    this.footerService.hideFooter();
    this.splashScreen.hide();

    if (!this.isDesktop()) {
      this.statusBar.hide();
    }
  }

  ionViewDidLeave() {
    if (!this.deviceService.isInputStopped()) {
      this.deviceService.stopInputAutomator();
    }
    console.log('Left cuttle view');
    this.enableOcr = false;

    if (!this.isDesktop()) {
      this.statusBar.show();
    }
  }

  async presentAlert(messageText: string) {
    if (this.alertModal) {
      this.alertModal.dismiss();
    }
    const alert = await this.alertController.create({
      header: 'Reconnecting...',
      message: messageText,
      buttons: ['OK'],
    });

    this.alertModal = alert;
    await this.alertModal.present();

    const { role } = await alert.onDidDismiss();
    console.log('onDidDismiss resolved with role', role);
  }

  startReconnectProcess() {
    this.presentAlert('WebRTC disconnected');
    let currentDeviceId = this.deviceService.getActiveDeviceId();
    console.log('Current device ID is: ', currentDeviceId);
    this.reconnectState = ReconnectState.WaitingForDevice;
    this.reconnectInterval = setInterval(() => {
      this.userService.getDefaultDevice().subscribe((device) => {
        if (device) {
          if (device.Id !== currentDeviceId) {
            currentDeviceId = device.Id;
            this.presentAlert('Default CVD changed -- new is ' + device.CvdId);
          }
          this.containerService
            .deviceStatus(device.Id)
            .subscribe((deviceStatus) => {
              console.log(
                'RECONNECT PROCESS -- got device & status',
                device,
                deviceStatus
              );
              if (
                deviceStatus.emulator === 'booting' &&
                this.reconnectState !== ReconnectState.WaitingForBoot
              ) {
                this.reconnectState = ReconnectState.WaitingForBoot;
                this.presentAlert('Device is booting up...');
                console.log(
                  'RECONNECT PROCESS -- emulator booting',
                  deviceStatus
                );
              }
              if (deviceStatus.emulator === 'running') {
                this.reconnectState = ReconnectState.Reconnecting;
                clearInterval(this.reconnectInterval);
                this.alertModal.dismiss();
                this.deviceService
                  .connectToDevice(
                    deviceStatus.device_id,
                    (videoStream) => {
                      console.log(videoStream);
                      // Change tab automatically when device is connected.
                      this.deviceService.setActiveCvdId(deviceStatus.device_id);
                      this.deviceService.setActiveEndpoint(
                        this.getWssEndPointWithDNS(deviceStatus)
                      );
                      this.deviceService.setActiveDeviceId(deviceStatus.id);
                    },
                    this.getWssEndPointWithDNS(deviceStatus)
                  )
                  .then(() => {
                    this.reconnectState = ReconnectState.None;
                  })
                  .catch((error) => {
                    console.log('RECONNECT ERROR ', error);
                    this.reconnectState = ReconnectState.None;
                  });
              }
            });
        }
      });
    }, 10000);
  }

  getWssEndPointWithDNS(cvdStatus: CuttleStatusJson): string {
    const httpEndpoint = cvdStatus.dns_address;

    const delim = httpEndpoint.indexOf(':');
    if (delim > 0) {
      const endUrl = httpEndpoint.substr(delim);
      return 'wss' + endUrl;
    }
  }

  onHoverClick() {
    console.log('onHoverClick');
    this.footerService.toggleFooter();
  }

  onBackClick() {
    console.log('onBackClick');
    this.navController.back();
  }

  onControlPanelButton(command: string) {
    this.deviceService.sendControlCommand(command, 'down');
    this.deviceService.sendControlCommand(command, 'up');
  }

  onOcrClick() {
    if (!this.ocr) {
      console.warn('OCR disabled - cannot recognize');
      return;
    }
    this.ocr
      .recognize(this.deviceScreen.nativeElement)
      .then((text) => console.log(text))
      .catch((e) => console.error('Failed to get OCR data:', e.message));
  }

  toggleCamera() {
    const currentState =
      this.deviceService && this.deviceService.cameraEnabled();
    const targetState = !currentState;

    console.log('Toggle camera', targetState ? 'on' : 'off');
    this.deviceService
      .enableCamera(targetState)
      .then((actualState) => {
        if (targetState !== actualState) {
          const msg = 'Cannot toggle camera ' + (targetState ? 'on' : 'off');
          console.warn(msg);
          this.showToast(msg, 2000);
        }
      })
      .catch((e) => {
        const msg = 'toggleCamera: ' + e.message;
        console.error(msg);
        this.showToast(msg, 2000);
      });
  }

  onStopButton() {
    if (!this.deviceService.isInputStopped()) {
      this.deviceService.stopInputAutomator();
    } else {
      console.warn('Cannot stop. Already stopped');
    }
  }

  onRecordButton() {
    if (this.deviceService.isInputStopped()) {
      this.deviceService.recordInput();
    } else {
      console.warn('Cannot start recording. Must stop first');
    }
  }

  onPlaybackButton() {
    if (this.deviceService.isInputStopped()) {
      const stopCallback = () => console.log('replay ended');
      this.deviceService.replayInput(stopCallback);
    } else {
      console.warn('Cannot start playback. Must stop first');
    }
  }

  onRepeatButton() {
    if (this.deviceService.isInputStopped()) {
      this.deviceService.repeatInput();
    } else {
      console.warn('Cannot start playback. Must stop first');
    }
  }

  onDownloadInputButton() {
    this.deviceService
      .exportInput()
      .then((data) => {
        const link = document.createElement('a');
        link.href = data.url;
        link.download = data.name;
        link.click();
      })
      .catch((e) => console.error('Cannot download input:', e.message));
  }

  onUploadInputButton() {
    document.getElementById('input_file_upload').click();
  }

  onUploadInputFile(files: FileList) {
    const file = files.item(0);
    let desc = file.name;
    // remove file extension
    const extension = '.json';
    if (desc.endsWith(extension)) {
      desc = desc.substring(0, desc.lastIndexOf(extension));
    }
    file
      .text()
      .then((text) => this.deviceService.importInput(text, desc))
      .catch((e) => console.error('Cannot upload:', e.message));
  }

  get cameraEnabled(): boolean {
    return this.deviceService.cameraEnabled();
  }

  get currentInputDescription(): string {
    const desc = this.deviceService.getInputDescription();
    return desc ? desc : '<no use case>';
  }

  get testStatus(): string {
    if (this.deviceService.isInputPlaying()) {
      return 'playing';
    } else if (this.deviceService.isInputRecording()) {
      return 'recording';
    } else if (this.deviceService.isInputStopped()) {
      return 'stopped';
    } else {
      return '';
    }
  }

  isMobileLandscape(): boolean {
    return this.platform.isLandscape() && this.platform.is('mobile');
  }

  isMobilePortrait(): boolean {
    return this.platform.isPortrait() && this.platform.is('mobile');
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  private showToast(msg: string, durationMs: number) {
    this.toastController
      .create({
        message: msg,
        duration: durationMs,
      })
      .then((toast) => toast.present())
      .catch((e) => console.error('Could not create toast:', e.message));
  }

  private startMouseTracking() {
    console.log('startMouseTracking');
    if (!this.isDesktop()) {
      if (window.TouchEvent) {
        this.registerTouchHandlers();
      } else if (window.PointerEvent) {
        this.registerPointerHandlers();
      } else if (window.MouseEvent) {
        this.registerMouseHandlers();
      }
    } else {
      this.registerMouseHandlers();
    }
  }

  private registerSecretCodeHandler(code: string, onCodeMatch: Function) {
    addEventListener('keydown', (e) =>
      this.checkSecretTestCode(e, code, onCodeMatch)
    );
  }

  private checkSecretTestCode(event: any, code: string, onCodeMatch: Function) {
    this.inputCache += String.fromCharCode(event.keyCode).toUpperCase();
    if (this.inputCache === code.toUpperCase()) {
      onCodeMatch();
      this.inputCache = '';
    } else if (this.inputCache.length >= code.length) {
      this.inputCache = this.inputCache.substring(1);
    }
  }

  private registerTouchHandlers() {
    console.log('registering touch events');
    this.deviceScreen.nativeElement.addEventListener('touchstart', (e) =>
      this.onStartDrag(e)
    );
    this.deviceScreen.nativeElement.addEventListener('touchmove', (e) =>
      this.onContinueDrag(e)
    );
    this.deviceScreen.nativeElement.addEventListener('touchend', (e) =>
      this.onEndDrag(e)
    );
  }

  private registerPointerHandlers() {
    console.log('registering pointer events');
    this.deviceScreen.nativeElement.addEventListener('pointerdown', (e) =>
      this.onStartDrag(e)
    );
    this.deviceScreen.nativeElement.addEventListener('pointermove', (e) =>
      this.onContinueDrag(e)
    );
    this.deviceScreen.nativeElement.addEventListener('pointerup', (e) =>
      this.onEndDrag(e)
    );
  }

  private registerMouseHandlers() {
    console.log('registering mouse events');
    this.deviceScreen.nativeElement.addEventListener('mousedown', (e) =>
      this.onStartDrag(e)
    );
    this.deviceScreen.nativeElement.addEventListener('mousemove', (e) =>
      this.onContinueDrag(e)
    );
    this.deviceScreen.nativeElement.addEventListener('mouseup', (e) =>
      this.onEndDrag(e)
    );
  }

  private onStartDrag(e) {
    e.preventDefault();
    console.log('mousedown at ' + e.pageX + ' / ' + e.pageY, e);
    this.mouseIsDown = true;
    this.sendEventUpdate(true, e);
  }

  private onContinueDrag(e) {
    e.preventDefault();
    if (this.mouseIsDown) {
      this.sendEventUpdate(true, e);
    }
  }

  private onEndDrag(e) {
    e.preventDefault();
    console.log('mouseup at ' + e.pageX + ' / ' + e.pageY, e);
    this.mouseIsDown = false;
    this.sendEventUpdate(false, e);
  }

  private resizeDeviceView() {
    console.log('resizeDeviceView');
    const videoElement = this.deviceScreen.nativeElement;
    // Auto-scale the screen based on window size.
    // Max window width of 70%, allowing space for the control panel.
    const ww = window.innerWidth * 0.7;
    const wh = window.innerHeight;
    const vw = videoElement.videoWidth;
    const vh = videoElement.videoHeight;
    const scaling = vw * wh > vh * ww ? ww / vw : wh / vh;
    videoElement.style.width = vw * scaling;
    videoElement.style.height = vh * scaling;
  }

  private sendEventUpdate(down: boolean, e: any) {
    const videoElement = this.deviceScreen.nativeElement;
    const eventType = e.type.substring(0, 5);

    // Before the first video frame arrives there is no way to know width and
    // height of the device's screen, so turn every click into a click at 0x0.
    // A click at that position is not more dangerous than anywhere else since
    // the user is clicking blind anyways.
    const videoWidth = videoElement.videoWidth ? videoElement.videoWidth : 1;
    const videoHeight = videoElement.videoHeight ? videoElement.videoHeight : 1;
    const elementWidth = videoElement.offsetWidth
      ? videoElement.offsetWidth
      : 1;
    const elementHeight = videoElement.offsetHeight
      ? videoElement.offsetHeight
      : 1;

    // - If vh*ew > eh*vw, then height fits to the element (potentially padding
    //   on left/right). Otherwise, width fits to the element (potentially
    //   padding on top/bottom)
    const heightFits = videoHeight * elementWidth > videoWidth * elementHeight;

    const scaling = heightFits
      ? videoHeight / elementHeight
      : videoWidth / elementWidth;

    var xArr = [];
    var yArr = [];
    var idArr = [];
    var slotArr = [];

    if (eventType == 'mouse' || eventType == 'point') {
      xArr.push(e.offsetX);
      yArr.push(e.offsetY);

      const thisId = down ? e.pointerId : -1;
      slotArr.push(0);
      idArr.push(thisId);
    } else if (eventType === 'touch') {
      // touchstart: list of touch points that became active
      // touchmove: list of touch points that changed
      // touchend: list of touch points that were removed
      const changes = e.changedTouches;
      const rect = e.target.getBoundingClientRect();
      const maxTouches = 10;

      for (let i = 0; i < changes.length; i++) {
        xArr.push(changes[i].pageX - rect.left);
        yArr.push(changes[i].pageY - rect.top);
        const id = Math.abs(changes[i].identifier % maxTouches);
        if (this.touchIdSlotMap.has(id)) {
          const slot = this.touchIdSlotMap.get(id);

          slotArr.push(slot);
          if (e.type === 'touchstart') {
            // error
            console.error('touchstart when already have slot');
            return;
          } else if (e.type === 'touchmove') {
            idArr.push(id);
          } else if (e.type === 'touchend') {
            this.touchSlots[slot] = false;
            this.touchIdSlotMap.delete(id);
            idArr.push(-1);
          }
        } else {
          if (e.type === 'touchstart') {
            let slot = -1;
            for (let j = 0; j < this.touchSlots.length; j++) {
              if (!this.touchSlots[j]) {
                slot = j;
                break;
              }
            }
            if (slot === -1) {
              slot = this.touchSlots.length;
              this.touchSlots.push(true);
            }
            slotArr.push(slot);
            this.touchSlots[slot] = true;
            this.touchIdSlotMap.set(id, slot);
            idArr.push(id);
          } else if (e.type === 'touchmove') {
            // error
            console.error('touchmove when no slot');
            return;
          } else if (e.type === 'touchend') {
            // error
            console.error('touchend when no slot');
            return;
          }
        }
      }
    }

    for (let i = 0; i < xArr.length; i++) {
      xArr[i] = xArr[i] * scaling;
      yArr[i] = yArr[i] * scaling;

      // Substract the offset produced by the difference in aspect ratio, if any.
      if (heightFits) {
        xArr[i] -= (elementWidth * scaling - videoWidth) / 2;
      } else {
        yArr[i] -= (elementHeight * scaling - videoHeight) / 2;
      }

      xArr[i] = Math.trunc(xArr[i]);
      yArr[i] = Math.trunc(yArr[i]);
    }

    // NOTE: Rotation is handled automatically because the CSS rotation through
    // transforms also rotates the coordinates of events on the object.

    this.deviceService.sendMultiTouch(idArr, xArr, yArr, down, slotArr);
  }

  private sendMouseUpdate(down: boolean, e: any) {
    const videoElement = this.deviceScreen.nativeElement;
    let x = e.offsetX || e.clientX;
    let y = e.offsetY || e.clientY;

    console.log('Pointer x/y', x, y, e);
    console.log(
      'VideoElement offset widht/heigh',
      videoElement.offsetWidth,
      videoElement.offsetHeight
    );

    console.log(
      'VideoElement video widht/height',
      videoElement.videoWidth,
      videoElement.videoHeight
    );

    let elementWidth;
    let elementHeight;
    if (this.screenHasBeenResized) {
      elementWidth = parseInt(videoElement.style.width, 10);
      elementHeight = parseInt(videoElement.style.height, 10);
    } else {
      // Before the first video frame arrives there is no way to know width and
      // height of the device's screen, so turn every click into a click at 0x0.
      // A click at that position is not more dangerous than anywhere else since
      // the user is clicking blind anyways.
      elementWidth = videoElement.offsetWidth ? videoElement.offsetWidth : 1;
      elementHeight = videoElement.offsetHeight ? videoElement.offsetHeight : 1;
    }
    const videoWidth = videoElement.videoWidth ? videoElement.videoWidth : 1;
    const videoHeight = videoElement.videoHeight ? videoElement.videoHeight : 1;
    // The screen uses the 'object-fit: cover' property in order to completely
    // fill the element while maintaining the screen content's aspect ratio.
    // Therefore:
    // - If vh*ew > eh*vw, w is scaled so that content width === element width
    // - Otherwise,        h is scaled so that content height === element height
    const scaleWidth = videoHeight * elementWidth > videoWidth * elementHeight;
    console.log('ScaleWidth', scaleWidth);

    // Convert to coordinates relative to the video by scaling.
    // (This matches the scaling used by 'object-fit: cover'.)
    //
    // This scaling is needed to translate from the in-browser x/y to the
    // on-device x/y.
    //   - When the device screen has not been resized, this is simple: scale
    //     the coordinates based on the ratio between the input video size and
    //     the in-browser size.
    //   - When the device screen has been resized, this scaling is still needed
    //     even though the in-browser size and device size are identical. This
    //     is due to the way WindowManager handles a resized screen, resized via
    //     `adb shell wm size`:
    //       - The ABS_X and ABS_Y max values of the screen retain their
    //         original values equal to the value set when launching the device
    //         (which equals the video size here).
    //       - The sent ABS_X and ABS_Y values need to be scaled based on the
    //         ratio between the max size (video size) and in-browser size.
    const scaling = scaleWidth
      ? videoWidth / elementWidth
      : videoHeight / elementHeight;
    console.log('Scaling', scaling);
    x = x * scaling;
    y = y * scaling;
    // Substract the offset produced by the difference in aspect ratio, if any.
    if (scaleWidth) {
      // Width was scaled, leaving excess content height, so subtract from y.
      y -= (elementHeight * scaling - videoHeight) / 2;
    } else {
      // Height was scaled, leaving excess content width, so subtract from x.
      x -= (elementWidth * scaling - videoWidth) / 2;
    }
    console.log(x, y, down);
    // NOTE: Rotation is handled automatically because the CSS rotation through
    // transforms also rotates the coordinates of events on the object.
    this.deviceService.sendMousePosition(x, y, down);
  }
}
