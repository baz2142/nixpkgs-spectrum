
class SDPCodecMap {
    #mappingByName = new Map();
    #mappingById = new Map();

    addCodec(name, id) {
        if (!this.#mappingByName.has(name)) {
            this.#mappingByName.set(name, new Array());
        }
        if (!this.#mappingByName.get(name).includes(id)) {
            this.#mappingByName.get(name).push(id);
        }
        this.#mappingById.set(id, name);
    }

    clear() {
        this.#mappingByName.clear();
        this.#mappingById.clear();
    }

    getByName(name) {
        if (name.includes('/')) {
            // Format is [codec]/[clock rate]
            return this.#mappingByName.get(name);
        }
        // format is [codec]
        let result = [];
        this.#mappingByName.forEach((value, key) => {
            if (key.startsWith(name)) {
                result.push(...value);
            }
        });
        return result;
    }

    getById(id) {
        return this.#mappingById.get(id);
    }
}

function moveToFront(toFront, allItems) {
    let filteredToFront = toFront.filter(item => allItems.includes(item));
    let filteredItems = allItems.filter(item => !toFront.includes(item));
    return filteredToFront.concat(filteredItems);
}

export default class SDPMangler {
    #matchCodec = /a=rtpmap:([0-9]+)\s+([^\s]*)/ig;
    #matchVideoList = /(m=video\s+[0-9]+\s+[\w\/]+)\s+(\d[\d\s]*\d)/ig;
    #codecs = new SDPCodecMap();
    #videoCodecLists = [];
    #sdp;

    parse(sdp) {
        this.#sdp = sdp;
        this.#codecs.clear();
        this.#videoCodecLists = [];
        const codecMatches = sdp.matchAll(this.#matchCodec);
        for (const match of codecMatches) {
            const codecName = match[2];
            const codecId = parseInt(match[1], 10);
            this.#codecs.addCodec(codecName, codecId);
        }
        const videoListMatches = sdp.matchAll(this.#matchVideoList)
        for (const match of videoListMatches) {
            const codecList = match[2]
                .split(/\s+/)
                .map(item => parseInt(item, 10));
            this.#videoCodecLists.push(codecList);
        }
        return this;
    }

    getVideoCodecs() {
        return this.#videoCodecLists
                   .map(id => this.#codecs.getById(id));
    }

    // move all codecs associated with name to the front of the
    // video array
    preferCodec(name) {
        let ids = this.#codecs.getByName(name);
        if (!ids) {
            // We don't have that codec - return
            return this;
        }
        let newCodecList = [];
        for (const codecs of this.#videoCodecLists) {
            const modified = moveToFront(ids, codecs);
            newCodecList.push(modified);
        }
        this.#videoCodecLists = newCodecList;
        return this;
    }

    // return sdp with updated video codec priority array
    getMangledSdp() {
        let iterator = this.#videoCodecLists.values();
        let replacer = (match, p1, p2, offset, string) => {
            let nextReplacement = iterator.next();
            const priorityString = nextReplacement.value
                .map(id => id.toString())
                .join(' ');
            return p1 + ' ' + priorityString;
        }
        return this.#sdp.replaceAll(this.#matchVideoList, replacer);
    }

}