import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-listrow',
  styleUrls: ['listrow.component.scss'],
  templateUrl: 'listrow.component.html',
})
export class ListrowComponent {
  @Input() heading: string;

  @Input() value: string;

  @Input() isLink: boolean;

  @Input() url: string;

  @Input() headingsize: number;

  constructor() {}

  getHeadingColumnSize(): number {
    return this.headingsize || 3;
  }

  getValueColumnSize(): number {
    return 12 - this.getHeadingColumnSize();
  }
}
