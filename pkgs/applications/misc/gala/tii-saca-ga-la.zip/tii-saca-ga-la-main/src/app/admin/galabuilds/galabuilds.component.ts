import { Component, OnInit } from '@angular/core';
import { AlertController, Platform, ToastController } from '@ionic/angular';
import { ColumnState, GridApi, GridOptions } from 'ag-grid-community';
import { BtnCellRenderer } from '../../common/btn-cell-renderer.component';
import {
  ContainerService,
  GalaBuild,
  GalaBuildResponse,
} from '../../container.service';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-galabuilds',
  templateUrl: 'galabuilds.component.html',
  styleUrls: ['galabuilds.component.scss'],
})
export class GalaBuildsComponent implements OnInit {
  public galaBuilds: GalaBuild[] = null;
  public gridOptions: GridOptions;
  public columnDefs = [];
  public gridApi: GridApi;
  public defaultSortState: ColumnState[];
  public frameworkComponents = {
    btnCellRenderer: BtnCellRenderer,
  };

  constructor(
    private platform: Platform,
    private toastController: ToastController,
    private containerService: ContainerService,
    private alertController: AlertController,
    private userService: UserService
  ) {
    this.defaultSortState = [{ colId: 'Created', sort: 'desc' }];
  }

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);
      if (authenticated) {
        if (this.gridApi) {
          this.gridApi.refreshCells({ force: true });
          this.gridApi.hideOverlay();
        }
        this.listGalaBuilds();
      }
    });

    this.gridOptions = {
      onGridReady: (param) => {
        this.gridApi = param.api;
        this.gridApi.sizeColumnsToFit();
        this.sortGrid(param, this.defaultSortState);
      },

      onCellDoubleClicked: (param) => {
        param.api.sizeColumnsToFit();
      },

      onRowDataChanged: (param) => {
        param.api.sizeColumnsToFit();
        this.sortGrid(param, this.defaultSortState);
      },
      onGridSizeChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      enableCellTextSelection: true,
    } as GridOptions;

    this.columnDefs = [
      {
        headerName: 'Build',
        field: 'GalaBuild',
        sortable: true,
        editable: false,
        filter: true,
      },
      {
        headerName: 'File name',
        field: 'BuildId',
        sortable: true,
        editable: false,
        valueFormatter: (params) => {
          return this.formatFileName(params.value);
        },
      },
      {
        headerName: 'Created',
        field: 'Created',
        sortable: true,
        editable: false,
        filter: true,
        valueFormatter: (params) => {
          return this.formatDate(params.value);
        },
      },
      {
        headerName: 'Download',
        headerClass: 'center-label',
        field: 'BuildId',
        cellStyle: { display: 'flex', justifyContent: 'center' },
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          clicked: (BuildId: string) => {
            this.getApkForId(BuildId);
          },
          icon: 'cloud-download-outline',
        },
        minWidth: 120,
        maxWidth: 120,
        resizable: false,
        sortable: false,
        editable: false,
        filter: false,
      },
    ];
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  async presentToast(header: string, message: string, displaySecs: number = 2) {
    const toast = await this.toastController.create({
      message: header + ': ' + message,
      duration: displaySecs * 1000,
    });
    toast.present();
  }

  async presentConfirmation(question: string): Promise<boolean> {
    const alert = await this.alertController.create({
      header: 'Confirmation',
      message: question,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
        },
        {
          text: 'OK',
          role: 'ok',
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    return role === 'ok';
  }

  galaBuild(buildId: string): GalaBuild {
    return this.galaBuilds.filter((build) => build.BuildId === buildId).pop();
  }

  listGalaBuilds() {
    this.gridApi?.showLoadingOverlay();
    this.containerService
      .refreshGalaBuilds()
      .subscribe((result: GalaBuildResponse) => {
        console.log('List gala builds result', result);
        this.gridApi?.hideOverlay();
        if (result.Builds) {
          this.galaBuilds = result.Builds;
        }
      });
  }

  formatDate(date: string): string {
    const newDate = date.replace(' +0000 UTC', 'Z').replace(/ /, 'T');
    const parsed = new Date(Date.parse(newDate));
    return `${parsed.toLocaleString(navigator.language)}`;
  }

  formatFileName(buildId: string): string {
    if (buildId && buildId.indexOf('/') > 0) {
      return buildId.substring(buildId.indexOf('/') + 1);
    } else {
      return null;
    }
  }

  getApkForId(buildId: string) {
    this.containerService.downloadGalaBuild(buildId).subscribe((data: any) => {
      console.log('APK status', data);
      const buildName =
        this.galaBuild(buildId)?.GalaBuild + '-' + this.formatFileName(buildId);
      this.downloadFile(buildName, data);
    });
  }

  downloadFile(galaBuild: string, data: BlobPart) {
    const blob = new Blob([data], {
      type: 'application/vnd.android.package-archive',
    });
    const downloadURL = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = downloadURL;
    link.download = galaBuild;
    link.click();
  }

  public onModelUpdated() {
    this.gridApi?.sizeColumnsToFit();
  }

  public sortGrid(param, state) {
    param.columnApi.applyColumnState({
      state,
    });
  }
}
