import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { AgGridModule } from 'ag-grid-angular';
import { IonicSelectableModule } from 'ionic-selectable';
import { NgxCsvParserModule } from 'ngx-csv-parser';
import { BtnCellRenderer } from '../common/btn-cell-renderer.component';
import { CvdCellRenderer } from '../common/cvd-cell-renderer.component';
import { DevicecardComponent } from '../common/devicecard/devicecard.component';
import { DevicecardModalPage } from '../common/devicecard/devicecard.modal';
import { DevicecardCompactComponent } from '../common/devicecard/devicecardcompact.component';
import { DevicecardListComponent } from '../common/devicecard/devicecardlist.component';
import { DropDownEditor } from '../common/dropdown/dropdown.editor';
import { FilterPipe } from '../common/filterpipe';
import { LinkCellRenderer } from '../common/link-cell-renderer.component';
import { ListrowModule } from '../common/listrow/listrow.module';
import { LoginModule } from '../common/login/login.module';
import { CvdPopoverComponent } from '../common/popover/cvdpopover.component';
import { TemplatePipe } from '../common/searchfilter';
import { SelectCellRenderer } from '../common/select-cell-renderer.component';
import { SpinnerCellRenderer } from '../common/spinner-cell-renderer.component';
import { SharedModule } from '../shared/shared.module';
import { AdminPageRoutingModule } from './admin-routing.module';
import { AdminPage } from './admin.page';
import { ConfigurationComponent } from './configuration/configuration.component';
import { DeviceGridComponent } from './devicegrid/devicegrid.component';
import { DeviceMappingsComponent } from './devicemappings/devicemappings.component';
import { GalaBuildsComponent } from './galabuilds/galabuilds.component';
import { InstanceComponent } from './instance/instance.component';
import { InstanceGroupComponent } from './instancegroup/instancegroup.component';
import { InstanceGroupsComponent } from './instancegroups/instancegroups.component';
import { InstanceTemplatesComponent } from './instancetemplates/instancetemplates.component';
import { BatchAddUsersComponent } from './users/batch-add-users/batch-add-users.component';
import { UsersComponent } from './users/users.component';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    AdminPageRoutingModule,
    AgGridModule,
    NgSelectModule,
    ListrowModule,
    LoginModule,
    SharedModule,
    NgxCsvParserModule,
    IonicSelectableModule,
  ],
  declarations: [
    AdminPage,
    FilterPipe,
    TemplatePipe,
    DevicecardComponent,
    DevicecardCompactComponent,
    DevicecardListComponent,
    DevicecardModalPage,
    InstanceGroupsComponent,
    InstanceGroupComponent,
    InstanceComponent,
    InstanceTemplatesComponent,
    DeviceGridComponent,
    DeviceMappingsComponent,
    GalaBuildsComponent,
    UsersComponent,
    ConfigurationComponent,
    LinkCellRenderer,
    BtnCellRenderer,
    DropDownEditor,
    SelectCellRenderer,
    CvdCellRenderer,
    SpinnerCellRenderer,
    CvdPopoverComponent,
    BatchAddUsersComponent,
  ],
})
export class AdminPageModule {}
