import { Component, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Platform, ToastController } from '@ionic/angular';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-login',
  styleUrls: ['login.component.scss'],
  templateUrl: 'login.component.html',
})
export class LoginComponent {
  public loginForm: FormGroup;
  public userName: string;
  public password: string;

  @Input() title: string;
  /**
   * card mode should be used when using the component inside normal content.
   * When card mode is off, it is in toolbar mode
   */
  @Input() card: boolean;

  constructor(
    private userService: UserService,
    private platform: Platform,
    private toastController: ToastController,
    private formBuilder: FormBuilder
  ) {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  isCardMode(): boolean {
    return this.card;
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
    });
    toast.present();
  }

  public onSubmit() {
    if (this.loginForm.valid) {
      const userName = this.loginForm.get('username').value.trim();
      const password = this.loginForm.get('password').value;

      this.userService.login(userName, password).then(
        (status) => {
          console.log('Component: Login success: ', status);
          // TODO: Get rid of this reload, at least in the case
          // when nobody has not yet logged in.
          this.presentToast('User logged in');
          /*setTimeout(() => {
            window.location.reload();
          }, 1000);*/
        },
        (error) => {
          console.log('Component: Login error: ', error);
          this.presentToast('Login error - check your credentials');
        }
      );
    }
  }

  loginPhone(phoneNumber: any) {
    this.userService.loginWithPhone(phoneNumber);
  }

  confirmPhone(code: any) {
    this.userService.confirmPhoneAuth(code);
  }

  logout() {
    console.log('Logout');
    this.userService.logout();
    localStorage.setItem('biometricLogin', 'false');
    // unregister fingerprint?
    this.presentToast('User logged out -- reloading to clear data');
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  }

  isLoggedIn(): boolean {
    const token = this.userService.getToken();
    return token && token.length > 0;
  }

  get userEmail(): string {
    return this.userService.getUserEmail();
  }

  get sacaMode(): string {
    return this.userService.sacaMode === 'Development'
      ? 'Dev'
      : this.userService.sacaMode;
  }

  get loginStatus(): string {
    if (this.isLoggedIn()) {
      return 'Log-in OK';
    } else {
      return 'Logged out';
    }
  }
}
