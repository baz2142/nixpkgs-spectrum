import { Component } from '@angular/core';

@Component({
  selector: 'app-change-password-container',
  templateUrl: './change-password-container.component.html',
  styleUrls: ['./change-password-container.component.css'],
})
export class ChangePasswordContainerComponent {
  public showForm: boolean;
  public showSuccessMsg: boolean;

  constructor() {
    this.showForm = false;
    this.showSuccessMsg = false;
  }

  public toggleFormVisibility() {
    this.showForm = !this.showForm;
  }

  public passwordChanged() {
    this.showForm = false;
    this.showSuccessMsg = true;

    setTimeout(() => {
      this.showSuccessMsg = false;
    }, 5000);
  }
}
