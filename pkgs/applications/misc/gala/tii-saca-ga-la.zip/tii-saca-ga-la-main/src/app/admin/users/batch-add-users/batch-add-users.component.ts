import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { NgxCsvParser, NgxCSVParserError } from 'ngx-csv-parser';
import { ContainerService, InstanceGroupInfo, InstanceGroupsResponse } from 'src/app/container.service';
import { SacaUsersService } from 'src/app/sacausers.service';
import { BatchAddUsersRequest, BatchDeleteUsersRequest, UserInfo, UserService } from 'src/app/user.service';

@Component({
  selector: 'app-batch-add-users',
  templateUrl: './batch-add-users.component.html',
  styleUrls: ['./batch-add-users.component.css'],
})
export class BatchAddUsersComponent implements OnInit {
  public instanceGroups: InstanceGroupInfo[];
  public userList: UserInfo[];
  public isAddingUsers: boolean;
  public isLoading: boolean;

  public selectedInstanceGroups: any[];
  public customGroupName: string;

  @Output() refreshUsers: EventEmitter<any> = new EventEmitter();
  @ViewChild('csvFile') fileSelect: any;

  constructor(
    private ngxCsvParser: NgxCsvParser,
    private containerService: ContainerService,
    private userService: UserService,
    private sacaUsersService: SacaUsersService,
    private toastController: ToastController
  ) {
    this.instanceGroups = [];
    this.userList = [];
    this.isAddingUsers = true;
    this.isLoading = false;

    this.selectedInstanceGroups = [];
    this.customGroupName = '';
  }

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);
      if (authenticated) {
        this.containerService.refreshInstanceGroups().subscribe((result: InstanceGroupsResponse) => {
          this.instanceGroups = result.Groups;
        });
      }
    });
  }

  public onFileSelect(input: HTMLInputElement) {
    const file = input.files[0];

    console.log(this.customGroupName);

    this.ngxCsvParser
      .parse(file, { header: true, delimiter: ',' })
      .pipe()
      .subscribe({
        next: (result): void => {
          this.userList = result as UserInfo[];
          console.log('Result', result);
        },
        error: (error: NgxCSVParserError): void => {
          console.log('Error', error);
        },
      });
  }

  public batchAddUsers() {
    if (this.userList.length > 0) {
      this.isLoading = true;

      const InstanceGroups: string[] =
        this.customGroupName.length > 0 ? [this.customGroupName] : this.selectedInstanceGroups;

      const request: BatchAddUsersRequest = {
        InstanceGroups,
        Users: this.userList,
      };

      this.sacaUsersService
        .batchControlUsers(true, request)
        .then(
          (result) => {
            this.isLoading = false;
            this.refreshUsers.emit(true);
            this.presentToast('Succesfully added users');
            this.resetState();
          },
          (error) => {
            this.isLoading = false;
            console.log('Batch add failed, reason: ' + error);
            this.presentToast('Batch add failed, reason: ' + error);
          }
        )
        .catch((error) => {
          this.isLoading = false;
          console.log(error);
        });
    } else {
      return;
    }
  }

  public batchRemoveUsers() {
    this.isLoading = true;

    const request: BatchDeleteUsersRequest = {
      Users: this.userList,
    };

    this.sacaUsersService
      .batchControlUsers(false, request)
      .then(
        (result) => {
          this.isLoading = false;
          this.refreshUsers.emit(true);
          this.presentToast('Succesfully deleted users');
          this.resetState();
        },
        (error) => {
          this.isLoading = false;
          console.log('Batch delete failed, reason: ' + error);
          this.presentToast('Batch delete failed, reason: ' + error);
        }
      )
      .catch((error) => {
        this.isLoading = false;
        console.log(error);
      });
  }

  private resetState() {
    this.selectedInstanceGroups = [];
    this.customGroupName = '';

    this.userList = [];
    this.fileSelect.nativeElement.value = '';
  }

  async presentToast(message: string, displaySecs: number = 4) {
    const toast = await this.toastController.create({
      message: message,
      duration: displaySecs * 1000,
    });
    toast.present();
  }
}
