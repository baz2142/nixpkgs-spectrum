import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { Subject } from 'rxjs';
import { DeviceService } from '../../device.service';
import { DevicecardComponent } from './devicecard.component';

@Component({
  selector: 'app-devicecardcompact',
  templateUrl: 'devicecardcompact.component.html',
  styleUrls: ['devicecardcompact.component.scss'],
  providers: [DeviceService],
})
export class DevicecardCompactComponent
  extends DevicecardComponent
  implements OnInit, OnDestroy
{
  @Input() isSelected: boolean;
  @Input() connectDevice: Subject<boolean>;
  @Input() showTiles: boolean;
  @Output() isSelectedChange = new EventEmitter<boolean>();

  ngOnInit() {
    super.ngOnInit(false);

    this.connectDevice.subscribe((val) => {
      if (val && this.isSelected) {
        super.connect(this.cuttleStatus.device_id);
      }

      if (!val && this.isSelected) {
        super.disconnect();
      }
    });
  }

  ngOnDestroy() {
    if (this.isSelected) {
      this.isSelectedChange.emit(this.isSelected);
    }
    super.ngOnDestroy();
  }

  selectedChange() {
    this.isSelectedChange.emit(this.isSelected);
  }

}
