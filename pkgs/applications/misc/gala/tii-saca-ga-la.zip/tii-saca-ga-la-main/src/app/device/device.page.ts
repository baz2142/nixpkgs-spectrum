import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { Platform, ToastController } from '@ionic/angular';
import {
  ContainerService,
  CuttlefishMapping,
  DeviceInstance,
  DeviceInstanceResponse,
  RequestStatus,
  StartParams,
} from '../container.service';
import { DeviceService } from '../device.service';
import { FooterService } from '../footer.service';
import { UserService } from '../user.service';


enum ActionOngoing {
  None = '',
  Preparing = 'Preparing',
  Starting = 'Starting',
  Stopping = 'Stopping',
  Connecting = 'Connecting',
  Disconnecting = 'Disconnecting',
}

const RESOLUTION_DEFAULT_X = 720;
const RESOLUTION_DEFAULT_Y = 1280;

@Component({
  selector: 'app-device',
  templateUrl: 'device.page.html',
  styleUrls: ['device.page.scss'],
})
export class DevicePage implements OnInit {
  public deviceList: DeviceInstance[] = [];
  public deviceSearchInput: string = '';
  public selectPlaceholder: string = '';

  //public joinedDeviceInfo: JoinedDeviceInfo = {} as JoinedDeviceInfo;

  public selectedDevice: string = '';
  public selectedDeviceInstance: DeviceInstance = {} as DeviceInstance;

  private actionOngoing = ActionOngoing.None;

  public ActionOngoing: typeof ActionOngoing = ActionOngoing;

  public startParamsVisible: boolean = false;
  public startParams: StartParams = {} as StartParams;

  public isConnectedToCuttle: boolean = false;

  @Output() toggleTabsNotification: EventEmitter<any> = new EventEmitter();

  constructor(
    private deviceService: DeviceService,
    private footerService: FooterService,
    private userService: UserService,
    private containerService: ContainerService,
    private androidPermissions: AndroidPermissions,
    private router: Router,
    private platform: Platform,
    private toastController: ToastController
  ) {}

  ngOnInit(): void {
    if (!this.isDesktop()) {
      this.addPermissions();
    }

    this.userService.defaultDeviceUpdated$.subscribe(
      (result: CuttlefishMapping) => {
        if (result && result.Id) {
          console.log('Got default device', result);
          this.selectedDevice = result.Id;
          this.getDeviceInfo(result.Id);
        }
      }
    );

    this.containerService.cvdStatusUpdated$.subscribe((status) => {
      if (this.selectedDevice === status.id) {
        console.log('Device page - current device status update', status);
        this.selectedDeviceInstance.AospBuild = status.aosp_build;
        this.selectedDeviceInstance.Binaries = status.binaries;
        this.selectedDeviceInstance.Cuttlefish = status.cuttlefish;
        this.selectedDeviceInstance.DnsAddress = status.dns_address;
        this.selectedDeviceInstance.Emulator = status.emulator;
        this.selectedDeviceInstance.Images = status.images;
        this.selectedDeviceInstance.CvdId = status.device_id;
      }
    });

    this.userService.publishDefaultDeviceInfo();
  }

  ionViewDidEnter() {
    this.footerService.showFooter();
    this.userService.whenAuthenticated().then((authenticated) => {
      if (authenticated && !this.userService.isNormalUser()) {
        this.listDevices(null);
      }
    });
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  isSuperUser(): boolean {
    return this.userService.isSuperUser();
  }

  isDeviceSelected(): boolean {
    return (
      this.selectedDevice &&
      this.selectedDevice.length > 0
    );
  }

  isActionOngoing(): boolean {
    return this.actionOngoing !== ActionOngoing.None;
  }

  isThisActionOngoing(action: ActionOngoing) {
    return this.actionOngoing === action;
  }

  isPrepareActive(): boolean {
    return (
      this.isDeviceSelected() &&
      this.selectedDeviceInstance.Images === 'present' &&
      this.selectedDeviceInstance.Binaries === 'missing'
    );
  }

  isStartActive(): boolean {
    return (
      this.isDeviceSelected() &&
      this.selectedDeviceInstance.Images === 'present' &&
      this.selectedDeviceInstance.Binaries === 'present' &&
      this.selectedDeviceInstance.Cuttlefish === 'stopped'
    );
  }

  isStopActive(): boolean {
    return (
      this.isDeviceSelected() &&
      this.selectedDeviceInstance.Images === 'present' &&
      this.selectedDeviceInstance.Binaries === 'present' &&
      this.selectedDeviceInstance.Cuttlefish === 'running'
    );
  }

  defaultResolutionParams() {
    this.startParams.xres = RESOLUTION_DEFAULT_X;
    this.startParams.yres = RESOLUTION_DEFAULT_Y;
  }

  deviceResolutionParams() {
    if (this.localWidth.length > 0 && this.localHeight.length > 0) {
      const width = Number.parseInt(this.localWidth);
      const height = Number.parseInt(this.localHeight);
      this.startParams.xres = RESOLUTION_DEFAULT_X;
      this.startParams.yres = Math.ceil(
        RESOLUTION_DEFAULT_X * (height / width)
      );
    }
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
    });
    toast.present();
  }

  selectDeviceWithSearchInput() {
    const search = this.deviceSearchInput;
    const splittedSearch = search.split(':');
    if (splittedSearch.length !== 2) {
      this.deviceSearchInput = '';
      return;
    }
    const hostName = splittedSearch[0];
    const port = parseInt(splittedSearch[1], 10);

    const device = this.sortedDeviceList.find((deviceInstance) => {
      return (
        deviceInstance.VmHostName === hostName &&
        deviceInstance.CvdControlPort === port
      );
    });

    if (device) {
      this.onDeviceChange(device.Id);
    }
    this.deviceSearchInput = '';
  }

  onDeviceChange(deviceId: string) {
    this.presentToast(this.filterDevice(deviceId)?.VmHostName + ' selected');
    this.selectedDevice = deviceId;
    this.deviceService.setActiveDeviceId(deviceId);
    //this.getDeviceInfo(deviceId);
    this.actionOngoing = ActionOngoing.None;
    this.selectedDeviceInstance = this.filterDevice(this.selectedDevice);
  }

  isLoggedIn(): boolean {
    const token = this.userService.getToken();
    return token && token.length > 0;
  }

  listDevices(activeDeviceId?: string) {
    this.selectPlaceholder = 'Refreshing...';
    this.containerService
      .listDevices()
      .subscribe((result: DeviceInstanceResponse) => {
        console.log('List devices result', result);
        if (result.Status && result.Instances && result.Instances.length > 0) {
          const deviceList = result.Instances.filter(
            (device) => !device.CustomerId || device.Id === activeDeviceId
          );
          this.deviceList = deviceList;
          this.selectPlaceholder = 'Select one';
          if (activeDeviceId) {
            this.selectedDevice = activeDeviceId;
            //this.getDeviceInfo(activeDeviceId);
          }
        }
      });
  }

  get sortedDeviceList(): DeviceInstance[] {
    if (!this.deviceList) {
      return [];
    }
    return this.deviceList.sort((a, b) => {
      return this.compareDevices(a, b);
    });
  }

  compareDevices(a: DeviceInstance, b: DeviceInstance): number {
    return a.VmHostName > b.VmHostName
      ? 1
      : a.VmHostName === b.VmHostName
      ? a.CvdControlPort >= b.CvdControlPort
        ? 1
        : -1
      : -1;
  }

  filterDevice(deviceId: string): DeviceInstance {
    const devices = this.deviceList.filter((device) => device.Id === deviceId);
    if (devices.length > 0) {
      return devices[0];
    } else {
      return null;
    }
  }

  parseDeviceTitle(device: DeviceInstance): string {
    if (device && device.Customer) {
      return device.Customer.DisplayName;
    } else {
      const deviceNum = device.CvdControlPort - 8080 + 1; // Magic formula to make cvd num 1 and up
      const deviceName = device.VmHostName;
      return `${deviceName} - CVD ${deviceNum}`;
    }
  }

  getDeviceInfo(deviceId: string, force: string = 'false') {
    console.log('Device page -- get device info');
    if (!!deviceId) {
      //this.selectedDeviceInfo.DeviceId = deviceId;
      this.containerService.deviceStatus(deviceId, force);
    }
    /*.subscribe((result: CuttleStatusJson) => {
        console.log('Device status', result);
        this.joinedDeviceInfo.CuttleStatus = result;
      });*/
  }

  prepare() {
    this.actionOngoing = ActionOngoing.Preparing;
    this.containerService
      .prepareContainer(this.selectedDevice)
      .subscribe((result: RequestStatus) => {
        console.log('Prepare container result', result);
        this.actionOngoing = ActionOngoing.None;
        if (result.Status) {
          this.presentToast(
            this.selectedDeviceInstance?.CvdId +
              ': Container prepared'
          );
          //this.getDeviceInfo(this.selectedDevice);
        } else {
          this.presentToast(
            this.selectedDeviceInstance?.CvdId +
              ': Container prepare error: ' +
              result.Message
          );
        }
      });
  }

  start() {
    this.actionOngoing = ActionOngoing.Starting;
    this.containerService
      .startDevice(this.selectedDevice, this.startParams)
      .subscribe((result: RequestStatus) => {
        console.log('Start device result', result);
        this.actionOngoing = ActionOngoing.None;
        if (result.Status) {
          this.presentToast(
            this.selectedDeviceInstance?.CvdId +
              ': Device started'
          );
          //this.getDeviceInfo(this.selectedDevice);
        } else {
          this.presentToast(
            this.selectedDeviceInstance?.CvdId +
              ': Device start error: ' +
              result.Message
          );
        }
      });
  }

  stop() {
    this.actionOngoing = ActionOngoing.Stopping;
    this.containerService
      .stopDevice(this.selectedDevice)
      .subscribe((result: RequestStatus) => {
        console.log('Stop device result', result);
        this.actionOngoing = ActionOngoing.None;
        if (result.Status) {
          this.presentToast(
            this.selectedDeviceInstance?.CvdId +
              ': Device stoppped'
          );
          //this.getDeviceInfo(this.selectedDevice);
        } else {
          this.presentToast(
            this.selectedDeviceInstance?.CvdId +
              ': Device stop error: ' +
              result.Message
          );
        }
      });
  }

  deviceReadyToConnect(): boolean {
    return this.selectedDeviceInstance?.Cuttlefish === 'running';
  }

  connect(cvdId: string) {
    this.actionOngoing = ActionOngoing.Connecting;
    if (cvdId && cvdId.length > 0) {
      this.connectToDevice(cvdId);
    } else {
      // The "old way" --> needs to be removed
      this.deviceService.fetchCvdId(this.getWssEndPointWithDNS()).subscribe(
        (deviceIds) => {
          console.log('Data from WS server', deviceIds);
          const cvdIds = deviceIds.concat(deviceIds as string[]);
          if (cvdIds && cvdIds.length > 0) {
            this.connectToDevice(cvdIds[0]);
          } else {
            this.actionOngoing = ActionOngoing.None;
            this.presentToast('No device found from the running container!');
          }
        },
        (error) => {
          this.actionOngoing = ActionOngoing.None;
          this.presentToast('Connection attempt failed!!!');
        }
      );
    }
  }

  disconnect() {
    this.deviceService.disconnectFromDevice();
    this.isConnectedToCuttle = false;
  }

  addPermissions() {
    this.checkAndAskPermission(this.androidPermissions.PERMISSION.RECORD_AUDIO);
    this.checkAndAskPermission(
      this.androidPermissions.PERMISSION.MODIFY_AUDIO_SETTINGS
    );
    this.checkAndAskPermission(this.androidPermissions.PERMISSION.CAMERA);
  }

  checkAndAskPermission(permissionName: string) {
    this.androidPermissions.checkPermission(permissionName).then(
      (result) => {
        console.log(
          'Has permission',
          permissionName,
          '?',
          result.hasPermission
        );
        if (!result.hasPermission) {
          this.androidPermissions.requestPermission(permissionName);
        }
      },
      (err) => this.androidPermissions.requestPermission(permissionName)
    );
  }

  getCuttleDnsEndpoint(): string {
    return this.selectedDeviceInstance?.DnsAddress;
  }

  getWssEndPointWithDNS(): string {
    const httpEndpoint = this.getCuttleDnsEndpoint();

    const delim = httpEndpoint.indexOf(':');
    if (delim > 0) {
      const endUrl = httpEndpoint.substr(delim);
      return 'wss' + endUrl;
    } else {
      //return this.getWssEndpoint();
    }
  }

  /*getWssEndpoint(): string {
    return this.joinedDeviceInfo.DeviceInfo.CuttleWssAddress;
  }*/

  toggleFooter() {
    this.footerService.toggleFooter();
  }

  public disconnectFromDevice() {
    this.deviceService.disconnectFromDevice();
  }

  public connectToDevice(cvdId: string) {
    if (!cvdId) {
      cvdId = 'cvd-1';
    }

    this.deviceService
      .connectToDevice(
        cvdId,
        (videoStream) => {
          console.log(videoStream);
          // Change tab automatically when device is connected.
          this.actionOngoing = ActionOngoing.None;
          this.isConnectedToCuttle = true;
          this.deviceService.setActiveCvdId(cvdId);
          this.deviceService.setActiveEndpoint(this.getWssEndPointWithDNS());
          this.deviceService.setActiveDeviceId(this.selectedDevice);
          this.router.navigateByUrl('/tabs/cuttle');
        },
        this.getWssEndPointWithDNS()
      )
      .catch((error) => {
        this.actionOngoing = ActionOngoing.None;
        this.isConnectedToCuttle = false;
        this.presentToast('WebRTC Connection failed: ' + error);
      });
  }

  get localHeight(): string {
    return window.innerHeight.toString();
  }

  get localWidth(): string {
    return window.innerWidth.toString();
  }

  get getHwWidth(): string {
    if (this.deviceService.currentDisplay) {
      return this.deviceService.currentDisplay.x_res;
    } else {
      return '';
    }
  }

  get getHwHeight(): string {
    if (this.deviceService.currentDisplay) {
      return this.deviceService.currentDisplay.y_res;
    } else {
      return '';
    }
  }

  get getHwCpu(): string {
    if (this.deviceService.currentHardware) {
      return this.deviceService.currentHardware.CPUs;
    } else {
      return '';
    }
  }

  get getHwMemory(): string {
    if (this.deviceService.currentHardware) {
      return this.deviceService.currentHardware.RAM;
    } else {
      return '';
    }
  }

  get getGPUMode(): string {
    if (this.deviceService.currentHardware) {
      return this.deviceService.currentHardware['GPU Mode'];
    } else {
      return '';
    }
  }

  get getDeviceVersionStr(): string {
    if (this.deviceService.deviceVersionStr) {
      return this.deviceService.deviceVersionStr;
    } else {
      return '';
    }
  }

  get hostAddress(): string {
    return this.deviceService.hostAddress;
  }

  set hostAddress(address: string) {
    this.deviceService.hostAddress = address;
  }
}
