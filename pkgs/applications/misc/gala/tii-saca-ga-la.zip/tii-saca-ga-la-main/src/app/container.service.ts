import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { share } from 'rxjs/operators';
import { webSocket } from 'rxjs/webSocket';
import {
  DEVICEAPI,
  INSTANCEGROUPAPI,
  VMINSTANCEAPI,
} from '../environments/endpoints';
import { UserInfo, UserService } from './user.service';

export type InstanceTemplate = {
  Id: number;
  Name: string;
  SelfLink: string;
  Created: string;
  Branch: string;
};

export type InstanceTemplateResponse = {
  Status: boolean;
  Templates: InstanceTemplate[];
};

export type AospBuild = {
  AospBuild: string;
  Created: string;
};

export type AospBuildResponse = {
  Status: boolean;
  Builds: AospBuild[];
};

export type GalaBuild = {
  BuildId: string;
  GalaBuild: string;
  Created: string;
};

export type GalaBuildResponse = {
  Status: boolean;
  Builds: GalaBuild[];
};

export type InstanceGroupInfo = {
  Id: string;
  SelfLink: string;
  Name: string;
  TargetSize: number;
  Created: string;
  InstanceTemplate: string;
  Stable: boolean;
  Settings: SacaSettings;
  Config: SacaConfig;
};

export type InstanceGroupsResponse = {
  Status: boolean;
  Groups: InstanceGroupInfo[];
};

export type InstanceGroupResponse = {
  Status: boolean;
  Group: InstanceGroupInfo;
};

export type InstanceInfo = {
  Id: number;
  Name: string;
  SelfLink: string;
  Status: string;
  Created: string;
  MachineType: string;
  IpAddress: string;
  Settings: SacaSettings;
  Config: SacaConfig;
};

export type InstanceGroupInstanceResponse = {
  Status: boolean;
  Instances: InstanceInfo[];
};

export type DeviceInfo = {
  IpAddress: string;
  CuttleAddress: string;
  CuttleWssAddress: string;
  Instance: DeviceInstance;
};

export type RequestStatus = {
  Status: boolean;
  Message: string;
};

export type DeviceInstance = {
  Id: string;
  VmHostName: string;
  GroupName: string;
  CvdControlPort: number;
  CustomerId: string;
  Customer: UserInfo;
  Status: CuttleStatusJson;
  IsSelected: boolean;
  Binaries: string;
  Images: string;
  Cuttlefish: string;
  Emulator: string;
  AospBuild: string;
  DnsAddress: string;
  CvdId: string;
};

export type DeviceInstanceResponse = {
  Status: boolean;
  Instances: DeviceInstance[];
};

// Task is the model used to store tasks in the datastore.
export type CuttlefishMapping = {
  Id: string;
  CustomerId: string;
  CvdControlPort: number;
  VmHostUrl: string;
  VmHostName: string;
  Binaries: string;
  Images: string;
  Cuttlefish: string;
  Emulator: string;
  AospBuild: string;
  DnsAddress: string;
  CvdId: string;
};

export type CuttleStatusJson = {
  id: string;
  binaries: string;
  cuttlefish: string;
  emulator: string;
  images: string;
  aosp_build: string;
  dns_address: string;
  device_id: string;
  statusText: string;
};

export type CuttleStatusMessage = {
  type: number;
  body: string;
};

export type SacaSettings = {
  Id: string;
  AospBuildId: string;
  NumCvdInstances: number;
};

export type SacaConfig = {
  Id: string;
  ConfigName: string;
  CuttlefishDefaultOptions: string;
  SignalingServerOptions: string;
  SignalingServerAospId: string;
  NumCvdInstances: number;
};

export type StartParams = {
  cpus: number;
  memory: number;
  xres: number;
  yres: number;
  dpi: number;
  refresh: number;
  custom: string;
};

enum WsMessageType {
  ConnectMessage = 1,
  StatusMessage = 2,
}

@Injectable({
  providedIn: 'root',
})
export class ContainerService {
  private instanceTemplates: InstanceTemplate[] = [];
  private aospBuilds: AospBuild[] = [];
  private galaBuilds: GalaBuild[] = [];
  private instangeGroups: InstanceGroupInfo[] = [];
  private cuttleStatuses: CuttleStatusJson[] = [];

  private websocketSubject;

  public cvdStatusUpdated$: EventEmitter<CuttleStatusJson>;

  constructor(
    private httpClient: HttpClient,
    private userService: UserService
  ) {
    // this.setupWebsocketListener();
    this.cvdStatusUpdated$ = new EventEmitter();
  }

  public setupWebsocketListener() {
    if (this.websocketSubject) {
      this.websocketSubject.unsubscribe();
    }
    const url = this.userService.resolveWebsocketEndpoint(
      'statesocketunsecure'
    );
    this.websocketSubject = webSocket(url);

    this.websocketSubject.subscribe(
      (msg) => this.handleStatusMessage(msg), // Called whenever there is a message from the server.
      (err) => this.handleWebsocketError(err), // Called if at any point WebSocket API signals some kind of error.
      () => this.handleWebsocketClose() // Called when connection is closed (for whatever reason).
    );
  }

  private handleWebsocketError(error: any) {
    if (error && error.type === 'close') {
    } else {
      console.log('Websocket error', error);
    }
    // Try to reconnect
    this.setupWebsocketListener();
  }

  private handleWebsocketClose() {
    console.log('websocket connection complete');
  }

  public getInstanceTemplates(): InstanceTemplate[] {
    return this.instanceTemplates;
  }

  public refreshInstanceTemplates(): Observable<InstanceTemplateResponse> {
    const obs = this.createRequest(INSTANCEGROUPAPI.LISTTEMPLATES, null).pipe(
      share()
    );

    obs.subscribe((result: InstanceTemplateResponse) => {
      if (result && result.Status) {
        this.instanceTemplates = result.Templates;
      }
    });

    return obs;
  }

  public getAospBuilds(): AospBuild[] {
    return this.aospBuilds;
  }

  public downloadGalaBuild(buildId: string): Observable<any> {
    let url = this.userService.resolveEndpoint(
      INSTANCEGROUPAPI.DOWNLOADGALABUILD
    );
    url = url + '?build=' + buildId;
    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'blob',
    });
  }

  public refreshAospBuilds(): Observable<AospBuildResponse> {
    const obs = this.createRequest(INSTANCEGROUPAPI.LISTAOSPBUILDS, null).pipe(
      share()
    );

    obs.subscribe((result: AospBuildResponse) => {
      if (result && result.Status) {
        this.aospBuilds = result.Builds;
      }
    });
    return obs;
  }

  public refreshGalaBuilds(): Observable<GalaBuildResponse> {
    const obs = this.createRequest(INSTANCEGROUPAPI.LISTGALABUILDS, null).pipe(
      share()
    );

    obs.subscribe((result: GalaBuildResponse) => {
      if (result && result.Status) {
        this.galaBuilds = result.Builds;
      }
    });
    return obs;
  }

  public getGalaBuilds(): GalaBuild[] {
    return this.galaBuilds;
  }

  public refreshInstanceGroups(): Observable<InstanceGroupsResponse> {
    const obs = this.createRequest(INSTANCEGROUPAPI.LISTGROUPS, null).pipe(
      share()
    );

    obs.subscribe((result: InstanceGroupsResponse) => {
      if (result && result.Status) {
        this.instangeGroups = result.Groups;
      }
    });

    return obs;
  }

  public getInstanceGroups(): InstanceGroupInfo[] {
    return this.instangeGroups;
  }

  private handleStatusMessage(msg: CuttleStatusMessage) {
    if (msg.type === WsMessageType.StatusMessage) {
      const cuttleStatus: CuttleStatusJson = JSON.parse(msg.body);
      if (cuttleStatus.id) {
        cuttleStatus.statusText =
          this.resolveDeviceStatusFromJson(cuttleStatus);
        this.cuttleStatuses[cuttleStatus.id] = cuttleStatus;
        console.log('CVD status updated', cuttleStatus);
        this.cvdStatusUpdated$.emit(cuttleStatus);
      }
    }
  }

  public getCuttleStatus(deviceId: string): CuttleStatusJson {
    return this.cuttleStatuses?.[deviceId];
  }

  public isCuttleStatusExisting(deviceId: string): boolean {
    return this.cuttleStatuses[deviceId] !== undefined;
  }

  public checkEmulatorStatus(device: DeviceInstance, status: string): boolean {
    return this.returnStatusProperty(device, 'Emulator') === status;
  }

  public checkCuttlefishStatus(
    device: DeviceInstance,
    status: string
  ): boolean {
    return this.returnStatusProperty(device, 'Cuttlefish') === status;
  }

  public checkBinariesStatus(device: DeviceInstance, status: string): boolean {
    return this.returnStatusProperty(device, 'Binaries') === status;
  }

  public checkImagesStatus(device: DeviceInstance, status: string): boolean {
    return this.returnStatusProperty(device, 'Images') === status;
  }

  public isDeviceCreating(device: DeviceInstance): boolean {
    return this.checkEmulatorStatus(device, 'creating');
  }

  public isDeviceStopped(device: DeviceInstance): boolean {
    return this.checkEmulatorStatus(device, 'stopped');
  }

  public isDeviceBooting(device: DeviceInstance): boolean {
    return this.checkEmulatorStatus(device, 'booting');
  }

  public isDeviceRunning(device: DeviceInstance): boolean {
    return this.checkEmulatorStatus(device, 'running');
  }

  public isDeviceStarted(device: DeviceInstance): boolean {
    return this.isDeviceBooting(device);
  }

  public isDevicePrepared(device: DeviceInstance): boolean {
    return this.checkBinariesStatus(device, 'present');
  }

  public isDeviceCreated(device: DeviceInstance): boolean {
    return this.checkImagesStatus(device, 'present');
  }

  public isDeviceError(device: DeviceInstance): boolean {
    return this.checkEmulatorStatus(device, 'error');
  }

  public resolveDeviceStatus(device: DeviceInstance): string {
    if (this.isDeviceRunning(device)) {
      return 'Running';
    } else if (this.isDeviceStopped(device) && this.isDeviceCreated(device)) {
      return 'Stopped';
    } else if (this.isDeviceBooting(device)) {
      return 'Booting';
    } else if (this.isDeviceError(device)) {
      return 'Error';
    } else if (this.isDevicePrepared(device)) {
      return 'Preparing';
    } else if (!this.isDeviceCreated(device)) {
      return 'Creating';
    } else {
      return 'Unknown';
    }
  }

  public resolveDeviceStatusFromJson(deviceStatus: CuttleStatusJson): string {
    if (deviceStatus.emulator === 'running') {
      return 'Running';
    } else if (deviceStatus.images === '' || deviceStatus.images === 'missing') {
      return 'Creating';
    } else if (deviceStatus.emulator === 'starting') {
      return 'Starting';
    } else if (deviceStatus.emulator === 'booting') {
      return 'Booting';
    } else if (deviceStatus.emulator === 'error') {
      return 'Error';
    } else if (deviceStatus.emulator === 'stopped') {
      return 'Stopped';
    } else if (deviceStatus.binaries === 'present') {
      return 'Preparing';
    } else if (deviceStatus.images === 'present') {
      return 'Created';
    } else {
      return 'Unknown';
    }
  }

  private returnStatusProperty(
    device: DeviceInstance,
    property: string
  ): string {
    if (this.isCuttleStatusExisting(device.Id)) {
      const cvdStatus = this.getCuttleStatus(device.Id);
      return cvdStatus[property.toLowerCase()] as string;
    } else {
      return device[property] as string;
    }
  }

  deleteInstanceGroup(groupName: string): Observable<RequestStatus> {
    return this.createRequest(
      INSTANCEGROUPAPI.DELETEGROUP,
      groupName,
      'groupname'
    );
  }

  listGroupInstances(
    groupId: string
  ): Observable<InstanceGroupInstanceResponse> {
    return this.createRequest(
      INSTANCEGROUPAPI.LISTINSTANCES,
      groupId,
      'groupname'
    );
  }

  listDevicesByVmHost(hostName: string): Observable<DeviceInstanceResponse> {
    return this.createRequest(
      VMINSTANCEAPI.LISTHOSTDEVICES,
      hostName,
      'hostname'
    );
  }

  deleteHostContainers(hostName: string): Observable<RequestStatus> {
    return this.createRequest(
      VMINSTANCEAPI.DELETEHOSTDEVICES,
      hostName,
      'hostname'
    );
  }

  getSettings(): Observable<SacaSettings> {
    return this.createRequest(VMINSTANCEAPI.SETTINGS, null);
  }

  postSettings(settings: SacaSettings): Observable<SacaSettings> {
    return this.createPostRequest(VMINSTANCEAPI.POSTSETTINGS, settings);
  }

  getConfigs(): Observable<SacaConfig[]> {
    return this.createRequest(VMINSTANCEAPI.CONFIG, null);
  }

  postConfig(config: SacaConfig): Observable<SacaConfig> {
    return this.createPostRequestForConfig(VMINSTANCEAPI.POSTCONFIG, config);
  }

  deleteConfig(configId: string): Observable<RequestStatus> {
    return this.createRequest(VMINSTANCEAPI.DELETECONFIG, configId, 'configid');
  }

  getLogLevel(): Observable<any> {
    return this.createRequest(VMINSTANCEAPI.LOGLEVEL, null);
  }

  setLogLevel(logLevel: string) {
    return this.createRequest(VMINSTANCEAPI.SETLOGLEVEL, logLevel, 'loglevel');
  }

  listDevices(): Observable<DeviceInstanceResponse> {
    const obs = this.createRequest(VMINSTANCEAPI.LISTDEVICES, null).pipe(
      share()
    );
    obs.subscribe((result: DeviceInstanceResponse) => {
      if (result && result.Status) {
        result.Instances.forEach((instance) => {
          const statusJson = {
            aosp_build: instance.AospBuild,
            binaries: instance.Binaries,
            cuttlefish: instance.Cuttlefish,
            emulator: instance.Emulator,
            images: instance.Images,
            dns_address: instance.DnsAddress,
            device_id: instance.CvdId,
            id: instance.Id,
          } as CuttleStatusJson;

          statusJson.statusText = this.resolveDeviceStatusFromJson(statusJson);

          this.cuttleStatuses[statusJson.id] = statusJson;
        });
      }
    });

    return obs;
  }

  listFreeDevices(): Observable<DeviceInstanceResponse> {
    return this.createRequest(VMINSTANCEAPI.LISTFREEDEVICES, null);
  }

  deviceInfo(deviceId: string): Observable<DeviceInfo> {
    // return this.createRequest(VMINSTANCEAPI.INFO, deviceId);
    const obs = this.createRequest(VMINSTANCEAPI.INFO, deviceId).pipe(share());
    obs.subscribe((result: DeviceInfo) => {
      if (result) {
        const statusJson = {
          aosp_build: result.Instance.AospBuild,
          binaries: result.Instance.Binaries,
          cuttlefish: result.Instance.Cuttlefish,
          emulator: result.Instance.Emulator,
          images: result.Instance.Images,
          dns_address: result.Instance.DnsAddress,
          device_id: result.Instance.CvdId,
          id: result.Instance.Id,
        } as CuttleStatusJson;

        statusJson.statusText = this.resolveDeviceStatusFromJson(statusJson);

        this.cuttleStatuses[statusJson.id] = statusJson;
      }
    });

    return obs;
  }

  prepareContainer(deviceId: string): Observable<RequestStatus> {
    return this.createRequest(DEVICEAPI.PREPARE, deviceId);
  }

  /*deviceStatus(deviceId: string): Observable<CuttleStatus> {
    return this.createRequest(DEVICEAPI.STATUS, deviceId);
  }*/

  public deviceStatus(
    deviceId: string,
    force: string = 'false'
  ): Observable<CuttleStatusJson> {
    const obs = this.createRequest(
      DEVICEAPI.STATUS,
      deviceId,
      'deviceid',
      force,
      'force'
    ).pipe(share());

    obs.subscribe((result: CuttleStatusJson) => {
      if (result) {
        result.statusText = this.resolveDeviceStatusFromJson(result);
        this.cuttleStatuses[result.id] = result;
        console.log('CVD status updated', result);
        this.cvdStatusUpdated$.emit(result);
      }
    });

    return obs;
  }

  startDevice(deviceId: string, startParams?: StartParams): Observable<any> {
    let url = this.userService.resolveEndpoint(DEVICEAPI.START);
    url = url + '?deviceid=' + deviceId;
    if (startParams) {
      url =
        url +
        this.appendParamIfExists('cpus', startParams.cpus) +
        this.appendParamIfExists('memory', startParams.memory) +
        this.appendParamIfExists('xres', startParams.xres) +
        this.appendParamIfExists('yres', startParams.yres) +
        this.appendParamIfExists('dpi', startParams.dpi) +
        this.appendParamIfExists('refresh', startParams.refresh) +
        this.appendCustomParamIfExists('custom', startParams.custom);
    }
    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'json',
    });
  }

  appendParamIfExists(paramName: string, param: number): string {
    if (param > 0) {
      return '&' + paramName + '=' + param;
    } else {
      return '';
    }
  }

  appendCustomParamIfExists(paramName: string, param: string): string {
    if (param) {
      return '&' + paramName + '=' + btoa(param);
    } else {
      return '';
    }
  }

  stopDevice(deviceId: string): Observable<RequestStatus> {
    return this.createRequest(DEVICEAPI.STOP, deviceId);
  }

  getLogs(deviceId: string): Observable<any> {
    let url = this.userService.resolveEndpoint(DEVICEAPI.GETLOGS);
    url = url + '?deviceid=' + deviceId;
    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'blob',
    });
  }

  registerCustomer(deviceId: string, customerName: string): Observable<any> {
    let url = this.userService.resolveEndpoint(VMINSTANCEAPI.REGISTERCUSTOMER);
    url = url + '?deviceid=' + deviceId + '&customer=' + customerName;

    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'json',
    });
  }

  unRegisterCustomer(customerId: string): Observable<RequestStatus> {
    return this.createRequest(
      VMINSTANCEAPI.UNREGISTERCUSTOMER,
      customerId,
      'customer'
    );
  }

  addContainer(
    instanceName: string,
    instanceAddress: string,
    port: number
  ): Observable<any> {
    let url = this.userService.resolveEndpoint(VMINSTANCEAPI.ADD);
    url =
      url +
      '?hostname=' +
      instanceName +
      '&ipaddress=' +
      instanceAddress +
      '&port=' +
      port;

    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'json',
    });
  }

  addInstanceGroup(
    groupName: string,
    instanceTemplate: string,
    size: number,
    configId: string
  ): Observable<any> {
    let url = this.userService.resolveEndpoint(INSTANCEGROUPAPI.ADDGROUP);
    url =
      url +
      '?groupname=' +
      groupName +
      '&template=' +
      instanceTemplate +
      '&size=' +
      size +
      '&configid=' +
      configId;

    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'json',
    });
  }

  scaleInstanceGroup(groupName: string, scaling: number): Observable<any> {
    let url = this.userService.resolveEndpoint(INSTANCEGROUPAPI.SCALE);
    url = url + '?groupname=' + groupName + '&scaling=' + scaling;

    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'json',
    });
  }

  removeContainer(deviceId: string): Observable<RequestStatus> {
    return this.createRequest(VMINSTANCEAPI.REMOVE, deviceId);
  }

  private createRequest(
    endpoint: string,
    queryParam: string,
    paramName?: string,
    queryParam2?: string,
    paramName2?: string
  ): Observable<any> {
    let url = this.userService.resolveEndpoint(endpoint);

    // Append deviceid param if given
    let queryParamName = 'deviceid';
    if (paramName) {
      queryParamName = paramName;
    }
    if (queryParam) {
      url = url + '?' + queryParamName + '=' + queryParam;
    }
    if (queryParam2) {
      url = url + '&' + paramName2 + '=' + queryParam2;
    }

    return this.httpClient.get(url, {
      headers: this.getHeaders(),
      responseType: 'json',
    });
  }

  private createPostRequest(
    endpoint: string,
    settings: SacaSettings
  ): Observable<any> {
    const url = this.userService.resolveEndpoint(endpoint);

    const payload = new HttpParams()
      .set('Id', settings.Id)
      .set('AospBuildId', settings.AospBuildId)
      // .set('DockerImage', settings.DockerImage)
      .set('NumCvdInstances', settings.NumCvdInstances.toString());

    return this.httpClient.post(url, payload, {
      headers: this.getHeaders('application/x-www-form-urlencoded'),
      responseType: 'json',
    });
  }

  private createPostRequestForConfig(
    endpoint: string,
    config: SacaConfig
  ): Observable<any> {
    const url = this.userService.resolveEndpoint(endpoint);

    const payload = new HttpParams()
      .set('Id', config.Id)
      .set('ConfigName', config.ConfigName)
      .set('CuttlefishDefaultOptions', config.CuttlefishDefaultOptions)
      .set('SignalingServerOptions', config.SignalingServerOptions)
      .set('SignalingServerAospId', config.SignalingServerAospId)
      .set('NumCvdInstances', config.NumCvdInstances.toString());

    return this.httpClient.post(url, payload, {
      headers: this.getHeaders('application/x-www-form-urlencoded'),
      responseType: 'json',
    });
  }

  private getHeaders(contentType?: string): HttpHeaders {
    let headers = new HttpHeaders();
    if (contentType) {
      headers = headers.set('Content-Type', contentType);
    }
    return headers;
  }
}
