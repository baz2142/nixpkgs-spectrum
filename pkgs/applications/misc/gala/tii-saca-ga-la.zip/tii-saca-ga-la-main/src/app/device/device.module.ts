import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DevicePage } from './device.page';
import { LoginModule } from '../common/login/login.module';
import { ListrowModule } from '../common/listrow/listrow.module';

import { DevicePageRoutingModule } from './device-routing.module';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    DevicePageRoutingModule,
    ListrowModule,
    LoginModule,
  ],
  declarations: [DevicePage],
})
export class DevicePageModule {}
