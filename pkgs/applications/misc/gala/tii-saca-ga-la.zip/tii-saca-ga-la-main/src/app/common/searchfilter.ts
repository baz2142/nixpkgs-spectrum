import { PipeTransform, Pipe, Injectable } from '@angular/core';

@Pipe({
  name: 'templatefilter',
})
@Injectable()
export class TemplatePipe implements PipeTransform {
  transform(items: any[], filterBy: string, filterProperty?: string): any[] {
    filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
    filterProperty = filterProperty ? filterProperty : 'Name';
    return filterBy
      ? items.filter(
          (item: any) =>
            item[filterProperty].toLocaleLowerCase().indexOf(filterBy) !== -1
        )
      : items;
  }
}
