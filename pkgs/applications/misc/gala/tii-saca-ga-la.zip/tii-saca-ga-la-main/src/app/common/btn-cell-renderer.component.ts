// app/common/btn-cell-renderer.component.ts
import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'btn-cell-renderer',
  template: `
    <ion-buttons>
      <ion-button (click)="btnClickedHandler()">
        <ion-icon name="{{ params.icon }}" *ngIf="params.icon"></ion-icon>
        <span *ngIf="params.name">{{ params.name }}</span>
      </ion-button>
    </ion-buttons>
  `,
})
export class BtnCellRenderer implements ICellRendererAngularComp {
  public params: any;

  agInit(params: any): void {
    this.params = params;
  }

  btnClickedHandler() {
    this.params.clicked(this.params.value);
  }

  refresh(params: ICellRendererParams): boolean {
    return false;
  }
}
