import { Component } from '@angular/core';
import { FooterService } from '../footer.service';
import { UserService } from '../user.service';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss'],
})
export class TabsPage {
  constructor(
    private footerService: FooterService,
    private userService: UserService,
    private platform: Platform
  ) {}

  public showFooter(): boolean {
    return this.footerService.footerState;
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  isAdminVisible(): boolean {
    return this.userService.isSuperUser() || this.userService.isAdminUser();
  }
}
