// app/common/btn-cell-renderer.component.ts
import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'cvd-cell-renderer',
  template: `
    <span>
      <app-devicecardlist
        *ngIf="params"
        [deviceId]="params.value"
        [connectDevice]="params.connect"
        [isSelected]="params.isSelected(params.value)"
      ></app-devicecardlist
    ></span>
  `,
})
export class CvdCellRenderer implements ICellRendererAngularComp {
  public params: any;

  agInit(params: any): void {
    this.params = params;
  }

  refresh(params: ICellRendererParams): boolean {
    return false;
  }
}
