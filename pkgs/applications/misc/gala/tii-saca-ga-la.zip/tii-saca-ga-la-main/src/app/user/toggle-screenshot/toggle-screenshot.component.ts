import { Component } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { ScreenshotPreventionService } from 'src/app/screenshot-prevention.service';

@Component({
  selector: 'app-toggle-screenshot',
  templateUrl: './toggle-screenshot.component.html',
  styleUrls: ['./toggle-screenshot.component.css'],
})
export class ToggleScreenshotComponent {
  public allowScreenshots: boolean;

  constructor(
    private screenshotService: ScreenshotPreventionService,
    private toastController: ToastController
  ) {
    this.allowScreenshots = false;
  }

  public toggleAllowScreenshot() {
    this.allowScreenshots = !this.allowScreenshots;

    if (this.allowScreenshots) {
      this.screenshotService.enableScreenshots().then((x) => {
        this.presentToast('Screenshots enabled');
        console.log(x + ' Screenshots enabled');
      });
    } else {
      this.screenshotService.disableScreenshots().then((x) => {
        this.presentToast('Screenshots disabled');
        console.log(x + ' Screenshots disabled');
      });
    }
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
    });
    toast.present();
  }
}
