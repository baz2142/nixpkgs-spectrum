import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CuttlePage } from './cuttle.page';

const routes: Routes = [
  {
    path: '',
    component: CuttlePage,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CuttlePageRoutingModule {}
