import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class FooterService {
  public footerState = true;

  constructor() {}

  toggleFooter() {
    this.footerState = !this.showFooter;
  }

  showFooter() {
    this.footerState = true;
  }

  hideFooter() {
    this.footerState = false;
  }
}
