import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ScreenshotPreventionService {
  public enableScreenshots(): Promise<boolean> {
    return new Promise((resolve, reject) => {
      (<any>window).plugins.preventscreenshot.enable(
        (a) => resolve(a),
        (b) => reject(b)
      );
    });
  }

  public disableScreenshots(): Promise<boolean> {
    return new Promise((resolve, reject) => {
      (<any>window).plugins.preventscreenshot.disable(
        (a) => resolve(a),
        (b) => reject(b)
      );
    });
  }
}
