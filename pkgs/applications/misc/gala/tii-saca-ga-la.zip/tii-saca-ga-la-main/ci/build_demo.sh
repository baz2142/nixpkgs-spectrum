#!/bin/bash

workplace=$(pwd)
outputpath=$workplace/out

echo "$(date): Workplace path: $workplace"

export GALA_CI_GIT_HASH=$(git rev-parse --short HEAD)
cordova telemetry off

echo "$(date): Build Android APK"
ionic cordova build android --configuration=demo --debug

# Copy artifacts
echo "$(date): Copy artifacts"
mkdir -p $outputpath
#cp $workplace/platforms/android/app/build/outputs/apk/debug/app-debug.apk $outputpath
cp /workspace/platforms/android/app/build/outputs/apk/debug/app-debug.apk $outputpath/demo-app-debug.apk


