export const firebaseConfig = {
  apiKey: 'AIzaSyDnMtgmQhBXWJs8sKw-L97NSbWk00YKZ3U',
  authDomain: 'ivam-dev.firebaseapp.com',
  projectId: 'ivam-dev',
  storageBucket: 'ivam-dev.appspot.com',
  messagingSenderId: '74890337806',
  appId: '1:74890337806:web:be210e4b74ec7ec9f2e65f',
};
