import { Component, OnInit } from '@angular/core';
import { AlertController, Platform, ToastController } from '@ionic/angular';
import { ColDef, GridApi, GridOptions } from 'ag-grid-community';
import { forkJoin, Subject } from 'rxjs';
import { CvdCellRenderer } from '../../common/cvd-cell-renderer.component';
import { DropDownEditor } from '../../common/dropdown/dropdown.editor';
import { LinkCellRenderer } from '../../common/link-cell-renderer.component';
import { SelectCellRenderer } from '../../common/select-cell-renderer.component';
import {
  ContainerService,
  CuttleStatusJson,
  DeviceInstance,
  DeviceInstanceResponse,
  InstanceGroupInfo,
  InstanceGroupsResponse,
} from '../../container.service';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-devicegrid',
  templateUrl: 'devicegrid.component.html',
  styleUrls: ['devicegrid.component.scss'],
})
export class DeviceGridComponent implements OnInit {
  public deviceSearchInput: string;
  public deviceFilterCount: number = 5;
  public showReserved = true;
  public showFree = true;

  gridFilters = {
    showCreating: true,
    showPrepared: true,
    showStarting: true,
    showRunning: true,
  };

  instanceGroups: InstanceGroupInfo[] = [];
  selectedDevice: any;

  public compactLayout = false;

  public intDeviceList: DeviceInstance[] = [];
  public renderDeviceList: DeviceInstance[] = [];

  private debugInfos: string[] = [];

  public selectAll = false;
  public showTiles = false;

  connectInstance: Subject<boolean> = new Subject();

  public cvdRange = { lower: 0, upper: 5 };

  public viewMode: string = 'default';

  deviceGridOptions: GridOptions;

  gridApi: GridApi;

  public frameworkComponents = {
    dropdownEditor: DropDownEditor,
    linkCellRenderer: LinkCellRenderer,
    selectCellRenderer: SelectCellRenderer,
    cvdCellRenderer: CvdCellRenderer,
  };

  deviceNameFilterParams = {
    textFormatter: (name) => {
      console.log('Format', name);
      return name;
    },
  };

  deviceColumnDefs: ColDef[] = [
    {
      field: 'Id',
      sortable: true,
      editable: false,
      maxWidth: 50,
      minWidth: 50,
      checkboxSelection: true,
      headerCheckboxSelection: true,
    },

    {
      headerName: 'CVD instance',
      field: 'Id',
      sortable: true,
      editable: false,
      flex: 1,
      cellRenderer: 'linkCellRenderer',
      cellRendererParams: {
        clicked: this.openDeviceInNewTab.bind(this),
        linkText: this.formatCvdInstanceColumn.bind(this),
        noLink: this.hideLink.bind(this),
      },
      filterValueGetter: (params) => {
        return params.data.VmHostName + ':' + params.data.CvdControlPort;
      },
    },
    {
      headerName: 'CVD Id',
      field: 'Status.device_id',
      sortable: true,
      editable: false,
    },
    {
      headerName: 'AOSP Id',
      field: 'Status.aosp_build',
      sortable: true,
      editable: false,
    },
    /*
    {
      headerName: 'Customer',
      field: 'Customer.DisplayName',
      sortable: true,
      editable: false,
    },*/
    {
      headerName: 'Bin',
      field: 'Status.binaries',
      sortable: true,
      editable: false,
      maxWidth: 100,
    },
    {
      headerName: 'Img',
      field: 'Status.images',
      sortable: true,
      editable: false,
      maxWidth: 100,
    },
    {
      headerName: 'Cuttle',
      field: 'Status.cuttlefish',
      sortable: true,
      editable: false,
      maxWidth: 100,
    },
    {
      headerName: 'Emu',
      field: 'Status.emulator',
      sortable: true,
      editable: false,
      maxWidth: 100,
    },
    {
      headerName: 'Status',
      field: 'Id',
      sortable: true,
      editable: false,
      suppressMenu: true,
      cellRenderer: 'cvdCellRenderer',
      cellRendererParams: {
        connect: this.connectInstance,
        isSelected: this.isNodeSelected.bind(this),
      },
      maxWidth: 150,
    },

    {
      headerName: 'Actions',
      headerClass: 'center-label',
      field: 'Id',
      cellStyle: { display: 'flex', justifyContent: 'center' },
      cellRenderer: 'selectCellRenderer',
      cellRendererParams: {
        actions: this.generateActions(),
      },
      suppressMenu: true,
      minWidth: 100,
      maxWidth: 100,
      resizable: false,
      sortable: false,
      editable: false,
      filter: false,
    },
  ];

  constructor(
    private platform: Platform,
    private toastController: ToastController,
    private containerService: ContainerService,
    private alertController: AlertController,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);
      if (authenticated) {
        this.fetchInstanceGroups();
        this.listDevices();

        this.containerService.cvdStatusUpdated$.subscribe((status) => {
          const renderDevice = this.getRenderDevice(status.id);
          if (renderDevice) {
            renderDevice.Status = null;
            renderDevice.Status = status;

            if (this.gridApi) {
              const rowNode = this.gridApi.getRowNode(status.id);
              this.gridApi.refreshCells({ rowNodes: [rowNode], force: true });
            }
          }
        });
      }
    });

    this.deviceGridOptions = this.generateGridOptions(
      this.sortGrid,
      'VmHostName',
      'asc'
    );
  }

  generateGridOptions(
    gridSort: any,
    column: string,
    direction: string
  ): GridOptions {
    return {
      onGridReady: (param) => {
        console.log('GRID IS READY');
        this.gridApi = param.api;
        param.api.sizeColumnsToFit();
        gridSort(param, column, direction);
        // this.refreshChanges();
      },

      onCellDoubleClicked: (param) => {
        // param.api.sizeColumnsToFit();
      },

      onRowDataChanged: (param) => {
        // param.api.sizeColumnsToFit();
      },
      onGridSizeChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      getRowNodeId: (data) => data.Id,
      defaultColDef: {
        flex: 1,
        minWidth: 100,
        resizable: true,
        sortable: true,
        editable: true,
        filter: true,
      },
      tooltipShowDelay: 1000,
      rowSelection: 'multiple',
      enableCellTextSelection: true,
    } as GridOptions;
  }

  sortGrid(param, field, sortDir) {
    const columnState = {
      // https://www.ag-grid.com/javascript-grid-column-state/#column-state-interface
      state: [
        {
          colId: field,
          sort: sortDir,
        },
      ],
    };
    param.columnApi.applyColumnState(columnState);
  }

  generateActions() {
    const actions = new Array();
    actions.push({
      title: 'Start',
      value: 'start',
      action: (deviceId) => {
        this.startInstance(deviceId);
      },
    });
    actions.push({
      title: 'Stop',
      value: 'stop',
      action: (deviceId) => {
        this.stopInstance(deviceId);
      },
    });

    return actions;
  }

  isRangeDisabled(): boolean {
    return this.deviceListCount === 0;
  }

  modeChanged($event) {
    this.gridApi = null;
  }

  rangeChanged() {
    this.updateDeviceSelection();
  }

  selectChanged() {
    this.updateDeviceSelection();
  }

  filterChanged() {
    this.updateDeviceSelection();
  }

  getSelectedDeviceIdsFromList(): string[] {
    if (this.viewMode === 'list') {
      return this.gridApi.getSelectedNodes().map((node) => node.data.Id);
    } else {
      return this.renderDeviceList
        .filter((device) => device.IsSelected === true)
        .map((device) => device.Id);
    }
  }

  updateDeviceSelection() {
    if (this.gridApi) {
      this.gridApi.deselectAll();
    }
    this.deviceIdListToBeRendered.forEach((deviceId) => {
      if (!this.containerService.isCuttleStatusExisting(deviceId)) {
        this.containerService.deviceStatus(deviceId).subscribe();
      }
    });

    this.renderDeviceList = this.deviceList.slice();
    this.renderDeviceList.forEach((device) => {
      device.Status = this.containerService.getCuttleStatus(device.Id);
    });
  }

  refreshData() {
    this.fetchInstanceGroups();
    this.listDevices();
  }

  isDesktop(): boolean {
    return this.platform.is('desktop');
  }

  formatCvdInstanceColumn(deviceId): string {
    const device = this.getRenderDevice(deviceId);
    if (device) {
      return device.VmHostName + ':' + device.CvdControlPort;
    } else {
      return '';
    }
  }

  hideLink(deviceId): boolean {
    const device = this.getRenderDevice(deviceId);
    if (device.Status && device.Status.emulator === 'running') {
      return false;
    } else {
      return true;
    }
  }

  openDeviceInNewTab(deviceId) {
    const url = this.getCuttleEndpointWithIdAndToken(deviceId);
    if (url) {
      window.open(url, '_blank').focus();
    }
  }

  isNodeSelected(deviceId): boolean {
    if (this.gridApi) {
      const node = this.gridApi.getRowNode(deviceId);
      return node.isSelected();
    } else {
      return false;
    }
  }

  getCuttleEndpointWithIdAndToken(deviceId: string): string {
    const status = this.getCvdStatus(deviceId);
    if (status) {
      let endpoint =
        status.dns_address + '?token=' + this.userService.getToken();
      if (status.device_id) {
        endpoint += '&cvdid=' + status.device_id;
      }
      return endpoint;
    }
  }

  searchChange($event) {
    this.intDeviceList.forEach((device: DeviceInstance) => {
      device.IsSelected = false;
    });

    this.selectAll = false;
  }

  public getCvdStatus(deviceId: string): CuttleStatusJson {
    return this.containerService.getCuttleStatus(deviceId);
  }

  private getRenderDevice(deviceId: string): DeviceInstance {
    return this.renderDeviceList
      .filter((device) => device.Id === deviceId)
      .pop();
  }

  fetchInstanceGroups() {
    console.log('Refresh instance groups');
    this.containerService
      .refreshInstanceGroups()
      .subscribe((result: InstanceGroupsResponse) => {
        console.log('List groups result', result);
        if (result.Status) {
          this.instanceGroups = result.Groups;
        }
      });
  }

  instanceGroupsLoading(): boolean {
    return this.instanceGroups.length < 1;
  }

  get deviceList(): DeviceInstance[] {
    return (
      this.intDeviceList
        .filter((device) => {
          return this.checkDeviceNameFilter(device);
        })
        /*.filter((device) => {
          return this.checkVisibilityForReservedAndFree(device);
        }) */
        .filter((device) => {
          return this.checkVisibilityForStatus(device);
        })
        .sort((a, b) => {
          return a.VmHostName + a.CvdControlPort >=
            b.VmHostName + b.CvdControlPort
            ? 1
            : -1;
        })
        .slice(this.cvdRange.lower, this.cvdRange.upper)
    );
  }

  get deviceListCount(): number {
    if (!(this.intDeviceList && this.intDeviceList.length > 0)) {
      return 0;
    }
    return this.intDeviceList
      .filter((device) => {
        return this.checkDeviceNameFilter(device);
      })
      .filter((device) => {
        return this.checkVisibilityForStatus(device);
      }).length;
  }

  private countDevicesByStatus(status): number {
    if (!(this.intDeviceList && this.intDeviceList.length > 0)) {
      return 0;
    }
    return this.intDeviceList
      .filter((device) => {
        return this.checkDeviceNameFilter(device);
      })
      .filter((device) => {
        const device_status = this.containerService.resolveDeviceStatus(device);
        //console.log('countDevicesByStatus.filter Emulator: ', device.Emulator, device.Binaries, '/', device_status);
        return (device_status == status);
      }).length;
  }

  get creatingDeviceListCount(): number {
    return this.countDevicesByStatus('Creating');
  }

  get stoppedDeviceListCount(): number {
    return this.countDevicesByStatus('Stopped');
  }

  get bootingDeviceListCount(): number {
    return this.countDevicesByStatus('Booting') + this.countDevicesByStatus('Preparing');
  }

  get runningDeviceListCount(): number {
    return this.countDevicesByStatus('Running');
  }

  get deviceIdListToBeRendered(): string[] {
    return this.deviceList.map((device) => {
      return device.Id;
    });
  }

  listDevices() {
    this.containerService
      .listDevices()
      .subscribe((result: DeviceInstanceResponse) => {
        if (result.Status) {
          this.intDeviceList = result.Instances;
          console.log('intDeviceList', this.intDeviceList);
        }
      });
  }

  private checkDeviceNameFilter(device: DeviceInstance): boolean {
    if (
      !this.deviceSearchInput ||
      (this.deviceSearchInput && this.deviceSearchInput.length < 2)
    ) {
      return false;
    }

    const re = new RegExp(this.deviceSearchInput); // any regex here
    const deviceName = device.VmHostName + ':' + device.CvdControlPort;
    return re.exec(deviceName) !== null;

    /* return (
      device.CustomerId.indexOf(this.deviceSearchInput) >= 0 ||
      device.VmHostName.indexOf(this.deviceSearchInput) >= 0
    ); */
  }

  private checkVisibilityForStatus(device: DeviceInstance): boolean {
    if (
      this.gridFilters.showPrepared &&
      this.containerService.isDeviceStopped(device)
    ) {
      return true;
    }
    if (
      this.gridFilters.showRunning &&
      this.containerService.isDeviceRunning(device)
    ) {
      return true;
    }
    if (
      this.gridFilters.showStarting &&
      this.containerService.isDeviceStarted(device)
    ) {
      return true;
    }

    if (
      this.gridFilters.showCreating &&
      !(
        this.containerService.isDeviceStarted(device) ||
        this.containerService.isDeviceStopped(device)
      )
    ) {
      return true;
    }

    return false;
  }

  private checkVisibilityForReservedAndFree(device: DeviceInstance): boolean {
    if (this.showFree && this.showReserved) {
      return true;
    } else if (!this.showFree && this.showReserved) {
      return device.CustomerId && device.CustomerId.length > 0;
    } else if (this.showFree && !this.showReserved) {
      return (
        (device.CustomerId && device.CustomerId.length === 0) ||
        !device.CustomerId
      );
    } else {
      return false;
    }
  }

  private getAddress(device: DeviceInstance): string {
    return device.VmHostName + ':' + (device.CvdControlPort - 8080 + 8343);
    // Magic: the difference between CVD control port and WebRTC port
  }

  async presentToast(header: string, message: string) {
    this.debugInfos.push(header + ': ' + message);
    const toast = await this.toastController.create({
      message: header + ': ' + message,
      duration: 2000,
    });
    toast.present();
  }

  async presentConfirmation(question: string): Promise<boolean> {
    const alert = await this.alertController.create({
      header: 'Confirmation',
      message: question,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
        },
        {
          text: 'OK',
          role: 'ok',
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    return role === 'ok';
  }

  formatDate(date: string): string {
    const parsed = new Date(Date.parse(date));
    return `${parsed.toISOString().substring(0, 10)} ${parsed
      .toISOString()
      .substring(11, 19)}`;
  }

  selectAllDevices($event) {
    if (this.viewMode === 'list') {
      this.gridApi.selectAllFiltered();
    } else {
      this.renderDeviceList.forEach((device: DeviceInstance) => {
        device.IsSelected = $event.detail.checked;
      });
    }
  }

  prepareInstances() {
    const observables = [];
    this.getSelectedDeviceIdsFromList().forEach((deviceId: string) => {
      console.log('Prepare device', deviceId);
      observables.push(this.containerService.prepareContainer(deviceId));
    });

    forkJoin(observables).subscribe((t) => {
      console.log('All devices prepared');
      this.presentToast('Prepare', 'All devices prepared');
    });
  }

  startInstances() {
    const observables = [];
    this.getSelectedDeviceIdsFromList().forEach((deviceId: string) => {
      console.log('Start device', deviceId);
      observables.push(this.containerService.startDevice(deviceId));
    });

    forkJoin(observables).subscribe((t) => {
      console.log('All devices started');
      this.presentToast('Start', 'All devices started');
    });
  }

  startInstance(deviceId: string) {
    this.containerService.startDevice(deviceId).subscribe((status) => {
      console.log('Instance started, status', status);
      this.presentToast('Start', 'Device started');
    });
  }

  stopInstances() {
    const observables = [];
    this.getSelectedDeviceIdsFromList().forEach((deviceId: string) => {
      console.log('Stop device', deviceId);
      observables.push(this.containerService.stopDevice(deviceId));
    });

    forkJoin(observables).subscribe((t) => {
      console.log('All devices stopped');
      this.presentToast('Stop', 'All devices stopped');
    });
  }

  stopInstance(deviceId: string) {
    this.containerService.stopDevice(deviceId).subscribe((status) => {
      console.log('Instance stopped, status', status);
      this.presentToast('Stop', 'Device stopped');
    });
  }

  connectInstances() {
    this.connectInstance.next(true);
  }

  disconnectInstances() {
    this.connectInstance.next(false);
  }

  statusInstances() {
    const observables = [];
    this.getSelectedDeviceIdsFromList().forEach((deviceId: string) => {
      console.log('Get device status', deviceId);
      observables.push(this.containerService.deviceStatus(deviceId, 'true'));
    });

    forkJoin(observables).subscribe((t) => {
      console.log('Status updates requested');
    });
  }
}
