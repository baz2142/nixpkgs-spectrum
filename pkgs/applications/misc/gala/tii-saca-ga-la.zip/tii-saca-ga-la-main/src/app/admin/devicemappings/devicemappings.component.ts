import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { ColumnState, GridApi, GridOptions } from 'ag-grid-community';
import { BtnCellRenderer } from '../../common/btn-cell-renderer.component';
import { DropDownEditor } from '../../common/dropdown/dropdown.editor';
import {
  ContainerService,
  DeviceInstance,
  DeviceInstanceResponse,
  RequestStatus,
} from '../../container.service';
import { SacaUsersService } from '../../sacausers.service';
import { UserInfo, UserService } from '../../user.service';

@Component({
  selector: 'app-devicemappings',
  templateUrl: 'devicemappings.component.html',
  styleUrls: ['devicemappings.component.scss'],
})
export class DeviceMappingsComponent implements OnInit {
  public deviceList: DeviceInstance[] = null;
  public gridOptions: GridOptions;
  public gridApi: GridApi;
  public columnDefs = [];
  public defaultSortState: ColumnState[];
  public frameworkComponents = {
    btnCellRenderer: BtnCellRenderer,
    dropdownEditor: DropDownEditor,
  };

  private userList: UserInfo[] = [];

  constructor(
    private toastController: ToastController,
    private containerService: ContainerService,
    private userService: UserService,
    private sacaUsersService: SacaUsersService
  ) {
    this.defaultSortState = [
      { colId: 'VmHostName', sort: 'desc', sortIndex: 0 },
      { colId: 'CvdControlPort', sort: 'asc', sortIndex: 1 },
    ] as ColumnState[];
  }

  ngOnInit() {
    this.userService.whenAuthenticated().then((authenticated) => {
      console.log('Authenticated: ' + authenticated);
      if (authenticated) {
        this.sacaUsersService.fetchUsers(false);
        this.sacaUsersService.sacaUsers$.subscribe((users) => {
          if (users) {
            this.userList = users;
            if (this.gridApi) {
              this.gridApi.refreshCells({ force: true });
              this.gridApi.hideOverlay();
            }
            this.listDevices();
          }
        });
      }
    });

    this.gridOptions = {
      onGridReady: (param) => {
        this.gridApi = param.api;
        param.api.sizeColumnsToFit();
        this.sortGrid(param, this.defaultSortState);
      },

      onCellDoubleClicked: (param) => {
        param.api.sizeColumnsToFit();
      },

      onRowDataChanged: (param) => {
        param.api.sizeColumnsToFit();
        this.sortGrid(param, this.defaultSortState);
      },
      onGridSizeChanged: (param) => {
        param.api.sizeColumnsToFit();
      },
      defaultColDef: {
        resizable: true,
        sortable: true,
        editable: false,
        filter: true,
      },
      enableCellTextSelection: true,
    } as GridOptions;

    this.columnDefs = [
      {
        headerName: 'Host name',
        field: 'VmHostName',
        minWidth: 140,
      },
      {
        headerName: 'Port',
        field: 'CvdControlPort',
        maxWidth: 140,
      },
      {
        headerName: 'Cvd ID',
        field: 'CvdId',
      },
      {
        headerName: 'Customer',
        field: 'CustomerId',
        valueFormatter: (params) => {
          return this.getCustomerName(params.value);
        },
      },
      {
        headerName: 'Binaries',
        field: 'Binaries',
        maxWidth: 150,
      },
      {
        headerName: 'Images',
        field: 'Images',
        maxWidth: 150,
      },
      {
        headerName: 'Cuttlefish',
        field: 'Cuttlefish',
        maxWidth: 150,
      },
      {
        headerName: 'Emulator',
        field: 'Emulator',
        maxWidth: 150,
      },
      {
        headerName: 'Delete',
        headerClass: 'center-label',
        field: 'Id',
        cellStyle: { display: 'flex', justifyContent: 'center' },
        cellRenderer: 'btnCellRenderer',
        cellRendererParams: {
          clicked: (Id: string) => {
            this.removeContainer(Id);
          },
          icon: 'trash-outline',
        },
        minWidth: 90,
        maxWidth: 90,
        resizable: false,
        sortable: false,
        editable: false,
        filter: false,
      },
    ];
  }

  getCustomerName(customerId: string): string {
    if (customerId) {
      return (
        this.userList
          .filter((user) => {
            return user.UID === customerId;
          })
          .pop()?.DisplayName || '<Resolving name..>'
      );
    } else {
      return null;
    }
  }

  sortDevicesBy(prop: string, prop2: string) {
    return this.deviceList.sort((a, b) =>
      a[prop] > b[prop]
        ? 1
        : a[prop] === b[prop]
        ? a[prop2] > b[prop2]
          ? 1
          : a[prop2] === b[prop2]
          ? 0
          : -1
        : -1
    );
  }

  listDevices() {
    this.gridApi?.showLoadingOverlay();
    this.containerService
      .listDevices()
      .subscribe((result: DeviceInstanceResponse) => {
        console.log('List devices result', result);
        this.gridApi?.hideOverlay();
        if (result.Status) {
          this.deviceList = result.Instances;
        }
      });
  }

  removeContainer(deviceId: string) {
    this.containerService
      .removeContainer(deviceId)
      .subscribe((result: RequestStatus) => {
        console.log('Delete container result', result);
        this.listDevices();
      });
  }

  public onModelUpdated() {
    this.gridApi.sizeColumnsToFit();
  }

  public sortGrid(param, state) {
    param.columnApi.applyColumnState({
      state,
    });
  }

  async presentToast(deviceName: string, message: string) {
    const toast = await this.toastController.create({
      message: deviceName + ': ' + message,
      duration: 2000,
    });
    toast.present();
  }
}
