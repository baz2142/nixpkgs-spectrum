import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { webSocket } from 'rxjs/webSocket';
import { InputAutomator } from './input.automator';
import { UserService } from './user.service';

const HOST = '34.76.151.50'; // Demo server as default
const PROTOCOL = 'ws';
const PORT = '8443';

const A_CNXN = 0x4e584e43;
const A_OPEN = 0x4e45504f;
const A_WRTE = 0x45545257;
const A_OKAY = 0x59414b4f;
const kLocalChannelId = 666;

@Injectable({
  providedIn: 'root',
})
export class DeviceService implements OnDestroy {
  private counter: number;
  public deviceIds: string[];
  public currentHardware: any;
  public currentDisplay: any;
  public videoStream: MediaStream;
  public audioStream: MediaStream;
  public deviceConnection: any;
  public displayLabel: string;
  public hostAddress: string;
  public deviceVersionStr: string;

  private adbWs;
  private fcmToken;
  private utf8Encoder = new TextEncoder();
  private utf8Decoder = new TextDecoder();
  private array = new Uint8Array();
  private cameraTrack: MediaStreamTrack;
  private cameraCapturer: ImageCapture;
  private inputAutomator = new InputAutomator();

  // TODO: Maybe combine these at some point
  public isConnected$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public connectionState$: BehaviorSubject<any> = new BehaviorSubject(null);

  private connecting = false;

  constructor(private userService: UserService, private http: HttpClient) {
    this.counter = 0;
    this.deviceIds = [];
    this.hostAddress = HOST;

    setInterval(() => {
      if (this.deviceConnection) {
        // console.log(this.deviceConnection.getState());
      }
    }, 500);
  }

  ngOnDestroy() {
    this.disconnectFromDevice();
  }

  fullUrl(): string {
    // return PROTOCOL + '://' + this.hostAddress + ':' + PORT;
    return this.hostAddress;
  }

  setEndPoint(endpoint: string) {
    this.hostAddress = endpoint;
  }

  public fetchCvdId(endpoint: string): Observable<any> {
    const url = endpoint + '/devices' + '?token=' + this.userService.getToken();

    if (endpoint.includes('ws:') || endpoint.includes('wss:')) {
      const wsock = webSocket(url);
      this.deviceIds = [];
      wsock.next({ message: 'give me those device ids' });

      return wsock.asObservable();
    } else {
      return this.http.get(url);
    }
  }

  public fetchTicket(endpoint: string): Observable<any> {
    const url = endpoint + '/ticket';
    const headerDict = {
      Accept: 'application/json',
      Authorization: 'Bearer ' + this.userService.getToken(),
      'Access-Control-Allow-Headers': 'Authorization',
    };
    let httpHeaders = new HttpHeaders(headerDict);
    const requestOptions = {
      headers: httpHeaders,
    };

    return this.http.get(url, requestOptions);
  }

  public setToken(token: string) {
    if (token !== this.fcmToken) {
      this.fcmToken = token;
      this.registerForNotifications();
    }
  }

  public enableCamera(enable: boolean): Promise<boolean> {
    return this.deviceConnection.useCamera(enable);
  }

  public cameraEnabled(): boolean {
    return this.deviceConnection && this.deviceConnection.cameraEnabled;
  }

  public isInputPlaying(): boolean {
    return this.inputAutomator.isPlaying();
  }

  public isInputRecording(): boolean {
    return this.inputAutomator.isRecording();
  }

  public isInputStopped(): boolean {
    return this.inputAutomator.isStopped();
  }

  public replayInput(stoppedCallback: Function) {
    this.inputAutomator.play((event) => this.deviceConnection.sendMultiTouch(event), stoppedCallback);
  }

  public repeatInput() {
    this.inputAutomator.repeat((event) => this.deviceConnection.sendMultiTouch(event));
  }

  public stopInputAutomator() {
    this.inputAutomator.stop();
  }

  public recordInput() {
    this.inputAutomator.startRecord();
  }

  public getInputDescription(): string {
    return this.inputAutomator.inputDescription;
  }

  public exportInput(): Promise<any> {
    return this.inputAutomator.export();
  }

  public importInput(source: string, description: string) {
    this.inputAutomator.import(source, description);
  }

  public sendControlCommand(commandText: string, stateType: string) {
    console.log('SendControlCommand', commandText, stateType);
    this.deviceConnection.sendControlMessage(
      JSON.stringify({
        command: commandText,
        button_state: stateType,
      })
    );
  }

  public setActiveCvdId(cvdId: string) {
    localStorage.setItem('activecvd', cvdId);
  }

  public getActiveCvdId() {
    return localStorage.getItem('activecvd');
  }

  public setActiveEndpoint(endpoint: string) {
    localStorage.setItem('activeendpoint', endpoint);
  }

  public getActiveEndpoint() {
    return localStorage.getItem('activeendpoint');
  }

  public setActiveDeviceId(deviceId: string) {
    localStorage.setItem('activedevice', deviceId);
  }

  public getActiveDeviceId() {
    return localStorage.getItem('activedevice');
  }

  public clearActiveDevice() {
    localStorage.removeItem('activecvd');
    localStorage.removeItem('activedevice');
    localStorage.removeItem('activeendpoint');
  }

  isActiveDevice(): boolean {
    return this.getActiveCvdId() !== null && this.getActiveDeviceId() !== null;
  }

  isConnecting(): boolean {
    return this.connecting;
  }

  isConnected(): boolean {
    return this.deviceConnection && this.deviceConnection.isConnected();
  }

  public disconnectFromDevice() {
    if (this.deviceConnection && !this.deviceConnection.isClosed()) {
      console.log('DISCONNECT', this.deviceConnection, this.audioStream);
      this.deviceConnection.stopTrack('audio');
      this.deviceConnection.stopTrack('video');
      // this.deviceConnection.useMic(false);
      // this.deviceConnection.useCamera(false);
      this.deviceConnection.disconnect();
      this.completeConnectionInit(false);
    }
  }

  public get whenConnected(): BehaviorSubject<boolean> {
    return this.isConnected$;
  }

  private completeConnectionInit(connected: boolean) {
    console.log('Connection init completed', connected);
    this.isConnected$.next(connected);
  }

  public connectToDevice(
    deviceId: string,
    videoCallback: any,
    endpoint: string,
    useTicket: boolean = true
  ): Promise<any> {
    this.currentHardware = {};
    this.currentDisplay = {};
    this.deviceVersionStr = '';
    let url = this.fullUrl();
    if (endpoint && endpoint.length) {
      url = endpoint;
    }
    return new Promise((resolve, reject) => {
      if (this.isConnected() && this.deviceConnection.controlChannelOpen()) {
        // resolve early since we are already connected
        console.log('Already connected - request frames');
        this.deviceConnection.sendControlMessage(
          JSON.stringify({
            command: 'request_frames',
          })
        );
        videoCallback();
        resolve(true);
        return;
      }
      let httpEndpoint = endpoint.replace('wss:', 'https:').replace('ws:', 'http:');

      const ticket = this.fetchTicket(httpEndpoint)
        .toPromise()
        .then((response) => {
          this.connectToDeviceWithTicket(deviceId, useTicket ? response.ticket : null, videoCallback, endpoint)
            .then(() => {
              resolve(true);
            })
            .catch((error) => {
              console.log('Device service -- connection failed', error);
              reject(error);
            });
        });
    });
  }

  // TODO: Check other way than callback
  public connectToDeviceWithTicket(
    deviceId: string,
    ticket: string,
    videoCallback: any,
    endpoint: string
  ): Promise<any> {
    this.currentHardware = {};
    this.currentDisplay = {};
    this.deviceVersionStr = '';
    let url = this.fullUrl();
    if (endpoint && endpoint.length) {
      url = endpoint;
    }

    const promise = new Promise((resolve, reject) => {
      import('./cf_webrtc.js')
        .then((webrtcModule) => {
          const options = {
            wsUrl: url + '/connect_client' + '?ticket=' + ticket,
          };
          return webrtcModule.Connect(deviceId, options);
        })
        .then((devConn) => {
          console.log(deviceId + '/t' + 'DEVICE CONNECTION ESTABLISHED');
          //this.connecting = false;
          this.deviceConnection = devConn;
          this.deviceConnection.connectionChangeCallback = (reason) => {
            console.log('connectionChangeCallback:', reason);
            //this.conne$.next(result.Users);
            this.connectionState$.next(reason);
          };
          this.completeConnectionInit(true);
          // TODO(b/143667633): get multiple display configuration from the
          // description object
          console.log(this.deviceConnection.description);
          this.currentHardware = this.deviceConnection.description.hardware;
          this.currentDisplay = this.deviceConnection.description.displays[0];
          if (this.deviceConnection.description.version_str) {
            const full_version = this.deviceConnection.description.version_str;
            const max_version_length = 7;
            if (full_version.length > max_version_length) {
              this.deviceVersionStr = full_version.substr(0, max_version_length);
            } else {
              this.deviceVersionStr = full_version;
            }
          }
          const stream_id = 'display_0';
          devConn
            .onStream(stream_id)
            .then((stream) => {
              this.videoStream = stream;
              this.displayLabel = stream_id;
              console.log(deviceId + '/t' + 'VideoStream', this.videoStream, stream_id);
              if (videoCallback) {
                videoCallback(this.videoStream);
              }
            })
            .catch((e) => console.error(deviceId + '/t' + 'Unable to get display stream: ', e));
          for (const audio_desc of devConn.description.audio_streams) {
            let stream_id = audio_desc.stream_id;
            devConn
              .onStream(stream_id)
              .then((stream) => {
                this.audioStream = stream;
              })
              .catch((e) => console.error(deviceId + '/t' + 'Unable to get audio stream: ', e));
          }

          this.deviceConnection.onControlMessage((msg) => this.onControlMessage(msg));
          this.registerForNotifications();
          resolve(true);
        })
        .catch((reason) => {
          console.log(deviceId + '/t' + 'Connection FAILED with reason', reason);
          this.connecting = false;
          reject(reason);
        });
    });

    return promise;
  }

  public sendMousePosition(x: any, y: any, downValue: boolean) {
    const label = this.displayLabel;
    if (this.deviceConnection) {
      console.log('sending mouse position', x, y, downValue, label);
      this.deviceConnection.sendMousePosition({
        x: Math.trunc(x),
        y: Math.trunc(y),
        down: downValue,
        display_label: label,
      });
    }
  }

  public sendMultiTouch(id: any[], x: any[], y: any[], downValue: boolean, slot: any[]) {
    const label = this.displayLabel;
    const event = {
      idArr: id,
      xArr: x,
      yArr: y,
      down: downValue ? 1 : 0,
      slotArr: slot,
      display_label: label,
    };
    if (this.inputAutomator.isRecording()) {
      this.inputAutomator.addRecord(event);
    }
    if (this.deviceConnection) {
      this.deviceConnection.sendMultiTouch(event);
    }
  }

  private onStreamChange(stream) {
    let stream_id = stream.id;
    if (stream_id.startsWith('display_')) {
      this.updateDeviceDisplays();
    }
  }

  private updateDeviceDisplays() {
    // Only single display supported now
    const stream_id = 'display_0';
    const stream = this.deviceConnection.getStream(stream_id);
    this.videoStream = stream;
    this.displayLabel = stream_id;
    console.log('update device displays:', this.videoStream, stream_id);
  }

  private onControlMessage(message: any) {
    const messageData = JSON.parse(message.data);
    const metadata = messageData.metadata;
    console.log(messageData.event + ':' + metadata);
    if (messageData.event === 'VIRTUAL_DEVICE_BOOT_STARTED') {
      // Start the adb connection after receiving the BOOT_STARTED message.
      // (This is after the adbd start message. Attempting to connect
      // immediately after adbd starts causes issues.)
      this.initAdb(this.deviceConnection);
    }
    if (messageData.event === 'VIRTUAL_DEVICE_BOOT_COMPLETED') {
      this.registerForNotifications();
    }
    if (messageData.event === 'VIRTUAL_DEVICE_START_CAMERA_SESSION') {
      this.deviceConnection.enableTrack(true, 'video');
    }
    if (messageData.event === 'VIRTUAL_DEVICE_STOP_CAMERA_SESSION') {
      this.deviceConnection.enableTrack(false, 'video');
    }
    if (messageData.event === 'VIRTUAL_DEVICE_CAPTURE_IMAGE') {
      if (this.deviceConnection.cameraEnabled) {
        this.takePhoto();
      }
    }
    if (messageData.event === 'VIRTUAL_DEVICE_CONTROL_CAMERA') {
      this.controlCamera(metadata);
    }
    /*if (messageData.event==='VIRTUAL_DEVICE_SCREEN_CHANGED') {
          if (metadata.rotation===rotation) {
            // Screen resized.
            // Set height and width directly to provided pixel values.
            screenHasBeenResized = true;
            deviceScreen.style.width = rotation===0 ? metadata.width : metadata.height;
            deviceScreen.style.height = rotation===0 ? metadata.height : metadata.width;
          } else {
            // Screen rotated.
            rotation = metadata.rotation;
          }
          resizeDeviceView();
          updateDeviceDisplayDetails({
            dpi: metadata.dpi,
            x_res: metadata.width,
            y_res: metadata.height
          });
        }*/
  }

  private takePhoto() {
    const imageCapture = this.deviceConnection.imageCapture;
    if (imageCapture) {
      this.deviceConnection
        .photoResolution(imageCapture, true)
        .then((resolution) => {
          const photoSettings = {
            imageWidth: resolution.width,
            imageHeight: resolution.height,
          };
          console.log(`Request ${resolution.width}x${resolution.height} photo`);
          return imageCapture.takePhoto(photoSettings);
        })
        .then((blob) => blob.arrayBuffer())
        .then((buffer) => this.deviceConnection.sendOrQueueCameraData(buffer))
        .catch((error) => console.error(error));
    } else {
      this.takePhotoFallback();
    }
  }

  private takePhotoFallback() {
    const resolution = this.deviceConnection.landscapeStreamResolution;
    if (!resolution) {
      console.error('Cannot get stream resolution - take photo failed');
      return;
    }
    let tempLocalVideo = document.createElement('video');
    let canvas = document.createElement('canvas');
    canvas.width = resolution.width;
    canvas.height = resolution.height;
    let ctx = canvas.getContext('2d');
    tempLocalVideo.autoplay = true;
    tempLocalVideo.playsInline = true;
    console.log(`Fallback ${resolution.width}x${resolution.height} photo`);
    tempLocalVideo.onloadeddata = (_) => {
      ctx.drawImage(tempLocalVideo, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => {
        blob
          .arrayBuffer()
          .then((buffer) => this.deviceConnection.sendOrQueueCameraData(buffer))
          .catch((error) => console.error(error));
      }, 'image/jpeg');
    };
    tempLocalVideo.srcObject = this.deviceConnection.cameraStream;
  }

  private controlCamera(controlStr: string) {
    var args = controlStr.split(' ', 4);
    var cmd = args[0];
    switch (cmd) {
      case 'enable':
        this.deviceConnection.enableTrack(true, 'video');
        break;
      case 'disable':
        this.deviceConnection.enableTrack(false, 'video');
        break;
      case 'user':
      case 'environment':
        var width = parseInt(args[1]);
        var height = parseInt(args[2]);
        this.setCameraFacing(cmd, width, height);
        break;
      case 'snapshot':
        var x_res = parseInt(args[1]);
        var y_res = parseInt(args[2]);
        var flash_mode = args[3];
        this.takeSnapshot(x_res, y_res, flash_mode);
        break;
      default:
        console.error('Unknown command: ', cmd);
    }
  }

  private setCameraFacing(facing: string, w: number, h: number) {
    this.deviceConnection.stopTrack('video');
    // TODO: Use width and height but currently too high resolutions give
    // DOMException: Could not start video source
    const constraints = {
      video: { facingMode: facing },
    };
    navigator.mediaDevices
      .getUserMedia(constraints)
      .then((stream) => {
        var videoTrack = stream.getTracks().find((track) => {
          return track.kind === 'video';
        });
        if (videoTrack) {
          videoTrack.enabled = true;
          this.cameraTrack = videoTrack;
          this.cameraCapturer = new ImageCapture(videoTrack);
          this.deviceConnection.replaceTrack(videoTrack);
        } else {
          console.error('No video tracks in stream');
        }
      })
      .catch((e) => console.error('Unable to set camera facing: ', e.message));
  }

  private takeSnapshot(x_res: number, y_res: number, flash_mode) {
    if (!this.cameraTrack || !this.cameraTrack.enabled) {
      console.error('No camera track for snapshot');
      return;
    }

    this.cameraCapturer
      .getPhotoCapabilities()
      .then((photoCapabilities) => {
        let width = x_res;
        if (width > photoCapabilities.imageWidth.max) {
          console.log(
            'Requested width %d exceeds %d - fall back to highest supported',
            width,
            photoCapabilities.imageWidth.max
          );
          width = photoCapabilities.imageWidth.max;
        }
        let height = y_res;
        if (height > photoCapabilities.imageHeight.max) {
          console.log(
            'Requested height %d exceeds %d - fall back to highest supported',
            height,
            photoCapabilities.imageHeight.max
          );
          height = photoCapabilities.imageHeight.max;
        }

        const flash_supported =
          photoCapabilities.fillLightMode && photoCapabilities.fillLightMode.find((element) => element === flash_mode);
        const photoSettings = flash_supported
          ? {
              imageWidth: width,
              imageHeight: height,
              fillLightMode: flash_mode,
            }
          : { imageWidth: width, imageHeight: height };

        return photoSettings;
      })
      .then((photoSettings) => this.cameraCapturer.takePhoto(photoSettings))
      .then((blob) => blob.arrayBuffer())
      .then((buffer) => this.deviceConnection.sendOrQueueCameraData(buffer))
      .catch((error) => console.error('takePhoto failed:', error.message));
  }

  private registerForNotifications(pkgName: string = 'com.whatsapp') {
    if (!this.deviceConnection || this.deviceConnection.isClosed()) {
      console.error('Cannot register for notifications without connection');
      return;
    }
    let cmd = this.buildFcmRegistrationCmd(pkgName);
    if (cmd) {
      this.sendControlCommand('cf_service_cmd', cmd);
    }
  }

  private buildFcmRegistrationCmd(pkgName: string) {
    if (!this.fcmToken) {
      console.log('Cannot build Fcm registration without token');
      return '';
    }
    let cmd = `token?${this.fcmToken};pkg?${pkgName};`;
    return cmd;
  }
  // TODO: Move ADB stuff from here!!

  private setU32LE(array, offset, x) {
    array[offset] = x & 0xff;
    array[offset + 1] = (x >> 8) & 0xff;
    array[offset + 2] = (x >> 16) & 0xff;
    array[offset + 3] = x >> 24;
  }
  private getU32LE(array, offset) {
    let x = array[offset] | (array[offset + 1] << 8) | (array[offset + 2] << 16) | (array[offset + 3] << 24);
    return x >>> 0; // convert signed to unsigned if necessary.
  }
  private computeChecksum(array) {
    let sum = 0;
    let i;
    for (i = 0; i < array.length; ++i) {
      sum = ((sum + array[i]) & 0xffffffff) >>> 0;
    }
    return sum;
  }
  private createAdbMessage(command, arg0, arg1, payload) {
    let arrayBuffer = new ArrayBuffer(24 + payload.length);
    let array = new Uint8Array(arrayBuffer);
    this.setU32LE(array, 0, command);
    this.setU32LE(array, 4, arg0);
    this.setU32LE(array, 8, arg1);
    this.setU32LE(array, 12, payload.length);
    this.setU32LE(array, 16, this.computeChecksum(payload));
    this.setU32LE(array, 20, command ^ 0xffffffff);
    array.set(payload, 24);
    return arrayBuffer;
  }
  private adbOpenConnection() {
    let systemIdentity = this.utf8Encoder.encode('Cray_II:1234:whatever');
    let arrayBuffer = this.createAdbMessage(A_CNXN, 0x1000000, 256 * 1024, systemIdentity);
    console.log('Open adb connection', arrayBuffer);
    this.adbWs.send(arrayBuffer);
  }
  public adbShell(command) {
    let destination = this.utf8Encoder.encode('shell:' + command);
    let arrayBuffer = this.createAdbMessage(A_OPEN, kLocalChannelId, 0, destination);
    this.adbWs.send(arrayBuffer);
  }

  private adbSendOkay(remoteId) {
    let payload = new Uint8Array(0);
    let arrayBuffer = this.createAdbMessage(A_OKAY, kLocalChannelId, remoteId, payload);
    this.adbWs.send(arrayBuffer);
  }
  private JoinArrays(arr1, arr2) {
    let arr = new Uint8Array(arr1.length + arr2.length);
    arr.set(arr1, 0);
    arr.set(arr2, arr1.length);
    return arr;
  }
  private adbOnMessage(arrayBuffer) {
    console.log('adb_ws: onmessage (' + arrayBuffer.byteLength + ' bytes)');
    this.array = this.JoinArrays(this.array, new Uint8Array(arrayBuffer));
    while (this.array.length > 0) {
      if (this.array.length < 24) {
        // Incomplete package, must wait for more data.
        return;
      }
      let command = this.getU32LE(this.array, 0);
      let magic = this.getU32LE(this.array, 20);
      if (command !== (magic ^ 0xffffffff) >>> 0) {
        console.log('command = ' + command + ', magic = ' + magic);
        console.log('adb message command vs magic failed.');
        return;
      }
      let payloadLength = this.getU32LE(this.array, 12);
      if (this.array.length < 24 + payloadLength) {
        // Incomplete package, must wait for more data.
        return;
      }
      let payloadChecksum = this.getU32LE(this.array, 16);
      let checksum = this.computeChecksum(this.array.slice(24));
      if (payloadChecksum !== checksum) {
        console.log('adb message checksum mismatch.');
        // This can happen if a shell command executes while another
        // channel is receiving data.
      }
      switch (command) {
        case A_CNXN: {
          console.log('WebRTC adb connected.');
          break;
        }
        case A_OKAY: {
          let remoteId = this.getU32LE(this.array, 4);
          console.log('WebRTC adb channel created w/ remoteId ' + remoteId);
          break;
        }
        case A_WRTE: {
          let remoteId = this.getU32LE(this.array, 4);
          this.adbSendOkay(remoteId);
          break;
        }
      }
      this.array = this.array.subarray(24 + payloadLength, this.array.length);
    }
  }
  private initAdb(devConn) {
    if (this.adbWs) {
      return;
    }
    this.adbWs = {
      send: function (buffer) {
        devConn.sendAdbMessage(buffer);
      },
    };
    devConn.onAdbMessage((msg) => this.adbOnMessage(msg));
    this.adbOpenConnection();
  }
}
