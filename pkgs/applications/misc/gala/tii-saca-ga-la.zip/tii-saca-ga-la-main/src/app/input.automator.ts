type InputRecord = {
  deltaTime: number;
  input: any;
};

enum State {
  Stopped,
  Playing,
  Recording,
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function promptDescription(): string {
  const max = 80;
  let desc = prompt(`Describe use case (truncated to ${max} chars)`);
  if (!desc) {
    const now = new Date();
    desc = 'something at ' + now.getHours() + '.' + now.getMinutes();
  } else if (desc.length > max) {
    desc = desc.substring(0, max);
  }
  return desc;
}

export class InputAutomator {
  private recordedInput: InputRecord[] = new Array();
  private state: State = State.Stopped;
  private prevTimestamp: number = 0;
  private description: string = '';

  get inputDescription(): string {
    return this.description;
  }

  isStopped(): boolean {
    return this.state === State.Stopped;
  }

  isRecording(): boolean {
    return this.state === State.Recording;
  }

  isPlaying(): boolean {
    return this.state === State.Playing;
  }

  startRecord() {
    if (this.state !== State.Stopped) {
      console.error('Cannot start record - not stopped');
      return;
    }
    this.description = '';
    this.recordedInput = [];
    this.prevTimestamp = 0;
    this.state = State.Recording;
  }

  addRecord(jsonInput: any) {
    if (this.state !== State.Recording) {
      return;
    }
    const now = Date.now();
    const diff = this.prevTimestamp > 0 ? now - this.prevTimestamp : 0;
    const newRecord: InputRecord = {
      deltaTime: diff,
      input: jsonInput,
    };
    this.recordedInput.push(newRecord);
    this.prevTimestamp = now;
  }

  async repeat(playbackSink: (jsonInput: any) => void) {
    if (this.recordedInput.length === 0) {
      console.error('Cannot repeat - no input events');
      return;
    } else if (this.state !== State.Stopped) {
      console.error('Cannot repeat - not stopped');
      return;
    }
    this.state = State.Playing;
    while (this.state === State.Playing) {
      await sleep(500);
      await this.playOnce(playbackSink);
    }
    this.state = State.Stopped;
  }

  async play(playbackSink: (jsonInput: any) => void, endCallback?: Function) {
    if (this.recordedInput.length === 0) {
      console.error('Cannot play - no input events');
      return;
    } else if (this.state !== State.Stopped) {
      console.error('Cannot play - not stopped');
      return;
    }
    this.state = State.Playing;
    await this.playOnce(playbackSink);
    this.state = State.Stopped;
    if (endCallback) {
      endCallback();
    }
  }

  async playOnce(playbackSink: (jsonInput: any) => void) {
    for (const input of this.recordedInput) {
      if (this.state !== State.Playing) {
        return;
      }
      await sleep(input.deltaTime);
      playbackSink(input.input);
    }
  }

  stop() {
    if (this.state === State.Recording) {
      this.description = promptDescription();
    }
    this.state = State.Stopped;
  }

  // import input events from external source
  import(source: string, description: string) {
    const json = JSON.parse(source);
    this.recordedInput = [];
    json.forEach((item) => {
      this.recordedInput.push({
        deltaTime: item.deltaTime,
        input: item.input,
      });
    });
    this.description = description;
  }

  // export array to data blob
  export(): Promise<any> {
    return new Promise((resolve, reject) => {
      if (this.recordedInput.length === 0 || !this.description) {
        reject(new Error('No data - Record the use case first'));
      }
      const json = JSON.stringify(this.recordedInput);
      const blob = new Blob([json], { type: 'application/json' });
      const downloadURL = window.URL.createObjectURL(blob);
      resolve({ url: downloadURL, name: this.description });
    });
  }
}
