# SACA GA Look-alike

## Overview

SACA GA look-alike application is a cross-platform application developed with Ionic/Cordova combination. [Ionic Framework](https://ionicframework.com/) is a cross-platform development framework supporting Angular, React and Vue and runs on top of [Cordova](https://cordova.apache.org/). Cordova provides the webview and HW-related bindings from the webview to the native mobile platform.

Ionic/Cordova support Android and/or iOS platforms as well as development time testing with desktop browser.

## Environment setup

Cross-platform environment setup can be divided into two major steps:
1. Common environment setup (in Ionic/Cordova case this enables browser development/testing)
2. Platform-specific setup (in Ionic/Cordova case this enables Android and/or iOS development/testing)

### Ionic/Cordova installation (see: https://ionicframework.com/docs)

1. Install Node and NPM. Preferred way is to use Node Version Manager (NVM) (e.g. https://github.com/nvm-sh/nvm)
2. Install Ionic (this is for Ionic v5): npm install -g @ionic/cli
3. Install Cordova: npm install -g cordova
4. Install the IDE of your choice (e.g. Visual Studio Code is nice for web development)

Now you should have development environment up & running for browser testing. You can try that out:

- ionic start myApp tabs
- cd myApp 
- ionic serve

Now browser should be automatically opened to the locahost with the correct port to show the myApp.

### How-to run GA Look-alike in browser

GA look-alike has been created with Ionic CLI toolset, so the CLI tools work out of the box. 

- Change directory to the root of the project
- Run `npm install` to install the required dependencies
- Run `ionic serve` to start up the GA Look-alike app in the local browser
  - Note: Running "ionic serve" will utilize the localhost backend instance. To specify a cloud backend environment, use Angular's environment selection
  - Dev env: `ionic serve --configuration=development`
  - Test env: `ionic serve --configuration=test`

Changes done to the codebase (web assets) are automatically refreshed within the browser.


### Android platform installation

GA Look-alike does already contain Android platform added to it. To be able to develop Android code and run/test GA Look-alike application in Android HW/emulator, you need to have Android development environment set up.

Follow the instructions in https://developer.android.com/studio/intro to install Android Studio. 

After the IDE installation, you need to have Android SDK(s) and possibly emulator(s) installed/configured to be able to run GA Look-alike

If you have either emulator instance up & running or real HW attached to the computer, then `ionic cordova run android` -command should build and launch the application in the emulator/HW.


### iOS platform installation
To be able to develop and run application in iOS emulator or on a real device, you need to have XCode 4.5 installed.

#### Building for emulator:
* `sudo gem install cocoapods`
* `npm install -g cordova`
* `ionic cordova platform add ios@latest --save`
* `cd platforms/ios && pod install`
* Get Firebase configuration from https://console.firebase.google.com/u/1/project/ivam-dev/settings/general/ios:dev.scpp.gala (iOS tab) and store the `GoogleService-Info.plist` to the root project folder (next to config.xml)
* (optional) in xCode, add the file under GALA project
* `ionic cordova build ios --emulator --verbose`
* `cordova run ios --list` (pick wanted simulator target name)
* `ionic cordova build ios --emulator --verbose --target "iPad-Pro-12-9-inch-5th-generation"`

#### Building for device
* check avaiable ios devices `cordova run ios --list`
* `ionic cordova build ios --device -target iPhone --developmentTeam="My name (Personal Team)"`
Note: with personal certificate push notifications are not permitted, so building from command line will fail. To workaround this, we need to open project in XCode, and in "Signing and Capabilities" tab remove "Push notifications" line. After that building succeeds and it is possible to run the application on device.

#### Running on device
This can be done either in XCode (open workspace at tii-saca-ga-la/platforms/ios/) or with `ionic cordova build ios --device -target iPhone --developmentTeam="My name (Personal Team)"`


#### iOS platform troubleshooting
1) Build fails:
* `rm package-lock.json`
* `npm update --force`
* `ionic cordova platform rm ios --save`
* `ionic cordova platform add ios@latest --save`

2) Message on device: "your device management settings do not allow using apps from developer". 

    Enterprise and other certificates have to be manually trusted on iOS 9 when they didn't have to on iOS 8 and earlier.
* open the Settings app
* open General
* open Profiles (you won’t see this until after the first profile is installed on an iOS device)
* choose the affected profile and trust it
