const BACKEND = require('./backends.js').TEST_BACKEND;
const TEST_PROXY_CONFIG = require('./proxy.conf.js');

TEST_PROXY_CONFIG['/saca-api/*'].target = BACKEND.PROTOCOL + BACKEND.ADDRESS + BACKEND.PORT;

module.exports = TEST_PROXY_CONFIG;
