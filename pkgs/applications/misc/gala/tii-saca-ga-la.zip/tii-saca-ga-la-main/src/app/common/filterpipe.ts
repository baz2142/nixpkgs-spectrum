import { PipeTransform, Pipe, Injectable } from '@angular/core';

@Pipe({
  name: 'sacafilter',
})
@Injectable()
export class FilterPipe implements PipeTransform {
  transform(items: any[], callback: (item: any) => boolean): any {
    if (!items || !callback) {
      return items;
    }

    return items.filter((item) => callback(item));
  }
}
