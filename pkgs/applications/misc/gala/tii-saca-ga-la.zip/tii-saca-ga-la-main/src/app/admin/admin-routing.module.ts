import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminPage } from './admin.page';
import { DeviceGridComponent } from './devicegrid/devicegrid.component';
import { DeviceMappingsComponent } from './devicemappings/devicemappings.component';
import { InstanceGroupsComponent } from './instancegroups/instancegroups.component';
import { InstanceGroupComponent } from './instancegroup/instancegroup.component';
import { InstanceComponent } from './instance/instance.component';
import { InstanceTemplatesComponent } from './instancetemplates/instancetemplates.component';
import { GalaBuildsComponent } from './galabuilds/galabuilds.component';
import { UsersComponent } from './users/users.component';
import { ConfigurationComponent } from './configuration/configuration.component';

const routes: Routes = [
  {
    path: '',
    component: AdminPage,
    children: [
      {
        path: 'instancegroups',
        component: InstanceGroupsComponent,
      },
      {
        path: 'instancegroups/:groupid',
        component: InstanceGroupComponent,
      },
      {
        path: 'instancegroups/:groupid/:instanceid',
        component: InstanceComponent,
      },
      {
        path: 'instancetemplates',
        component: InstanceTemplatesComponent,
      },
      {
        path: 'devicegrid',
        component: DeviceGridComponent,
      },
      {
        path: 'mappings',
        component: DeviceMappingsComponent,
      },
      {
        path: 'galabuilds',
        component: GalaBuildsComponent,
      },
      {
        path: 'users',
        component: UsersComponent,
      },
      {
        path: 'configuration',
        component: ConfigurationComponent,
      },
      {
        path: '',
        redirectTo: '/tabs/admin/instancegroups',
        pathMatch: 'full',
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminPageRoutingModule {}
