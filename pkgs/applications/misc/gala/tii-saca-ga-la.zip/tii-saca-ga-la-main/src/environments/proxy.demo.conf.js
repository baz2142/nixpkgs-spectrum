const BACKEND = require('./backends.js').DEMO_BACKEND;
const DEMO_PROXY_CONFIG = require('./proxy.conf.js');

DEMO_PROXY_CONFIG['/saca-api/*'].target = BACKEND.PROTOCOL + BACKEND.ADDRESS + BACKEND.PORT;

module.exports = DEMO_PROXY_CONFIG;
