import { Component, Input } from '@angular/core';
import { PopoverController } from '@ionic/angular';
@Component({
  selector: 'app-cvdpopovercomponent',
  templateUrl: './cvdpopover.component.html',
})
export class CvdPopoverComponent {
  @Input() video: MediaStream;

  constructor(private popover: PopoverController) {}

  ClosePopover() {
    this.popover.dismiss();
  }
}
