import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { CustomValidators } from 'src/app/shared/password.validator';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css'],
})
export class ChangePasswordComponent {
  @Output() passwordChanged = new EventEmitter<boolean>();
  public isLoading: boolean;
  public errorMessage: string;
  public passwordPattern: RegExp;
  public changePasswordForm: FormGroup;

  constructor(
    public formBuilder: FormBuilder,
    public userService: UserService,
    public toastController: ToastController
  ) {
    this.isLoading = false;
    this.errorMessage = '';
    this.passwordPattern = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d].+/;
    this.changePasswordForm = this.formBuilder.group(
      {
        password_old: ['', Validators.required],
        password_new: [
          '',
          [Validators.minLength(8), Validators.pattern(this.passwordPattern)],
        ],
        password_verify: [
          '',
          [Validators.minLength(8), Validators.pattern(this.passwordPattern)],
        ],
      },
      { validators: CustomValidators.PasswordsMatchValidator }
    );
  }

  public onSubmit() {
    this.isLoading = true;
    this.errorMessage = '';

    this.userService
      .changeUserPassword(
        this.changePasswordForm.controls.password_old.value,
        this.changePasswordForm.controls.password_new.value
      )
      .then((response) => {
        this.handleSuccess();
      })
      .catch((error) => {
        this.handleError(error);
      });
  }

  private handleSuccess() {
    this.isLoading = false;
    this.changePasswordForm.reset();
    this.passwordChanged.emit(true);
    this.presentToast('User password succesfully changed');
  }

  private handleError(errorMsg: string) {
    this.isLoading = false;
    this.errorMessage = errorMsg;
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
    });
    toast.present();
  }
}
